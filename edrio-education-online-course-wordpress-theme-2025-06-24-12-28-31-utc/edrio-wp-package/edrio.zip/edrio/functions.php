<?php
/**
 * edrio functions and definitions
 *
 * @link https://developer.wordpress.org/themes/basics/theme-functions/
 *
 * @package edrio
 */

define('EDRIO_THEME_DRI', get_template_directory());
define('EDRIO_INC_DRI', get_template_directory() . '/inc/');
define('EDRIO_THEME_URI', get_template_directory_uri());
define('EDRIO_CSS_PATH', EDRIO_THEME_URI . '/assets/css');
define('EDRIO_JS_PATH', EDRIO_THEME_URI . '/assets/js');
define('EDRIO_IMG_PATH', EDRIO_THEME_URI . '/assets/images');
define('Edrio_Admin_DRI', EDRIO_THEME_DRI . '/admin');

/**
 * Sets up theme defaults and registers support for various WordPress features.
 *
 * Note that this function is hooked into the after_setup_theme hook, which
 * runs before the init hook. The init hook is too late for some features, such
 * as indicating support for post thumbnails.
 */
function edrio_setup(){
	/*
	 * Make theme available for translation.
	 * Translations can be filed in the /languages/ directory.
	 * If you're building a theme based on edrio, use a find and replace
	 * to change 'edrio' to the name of your theme in all the template files.
	 */
	load_theme_textdomain('edrio', get_template_directory() . '/languages');

	// Add default posts and comments RSS feed links to head.
	add_theme_support('automatic-feed-links');
	add_image_size('edrio-img-size-1', 400, 265, true);
	add_image_size('edrio-400x235', 400, 235, true);
	add_image_size('edrio-357x220', 357, 220, true);
	/*
	 * Let WordPress manage the document title.
	 * By adding theme support, we declare that this theme does not use a
	 * hard-coded <title> tag in the document head, and expect WordPress to
	 * provide it for us.
	 */
	add_theme_support('title-tag');
	remove_theme_support('widgets-block-editor');
	add_filter( 'big_image_size_threshold', '__return_false' );

	/*
	 * Enable support for Post Thumbnails on posts and pages.
	 *
	 * @link https://developer.wordpress.org/themes/functionality/featured-images-post-thumbnails/
	 */
	add_theme_support('post-thumbnails');

	//Woocommerc
	add_theme_support('woocommerce');
	add_theme_support('wc-product-gallery-lightbox');
	add_theme_support('wc-product-gallery-slider');

	add_theme_support('post-formats', [
		'standard', 'image', 'video', 'gallery'
	]);

	// This theme uses wp_nav_menu() in one location.
	register_nav_menus(
		array(
			'menu-1' => esc_html__('Primary', 'edrio'),
		)
	);

	/*
	 * Switch default core markup for search form, comment form, and comments
	 * to output valid HTML5.
	 */
	add_theme_support(
		'html5',
		array(
			'search-form',
			'comment-form',
			'comment-list',
			'gallery',
			'caption',
			'style',
			'script',
		)
	);

	// Set up the WordPress core custom background feature.
	add_theme_support(
		'custom-background',
		apply_filters(
			'edrio_custom_background_args',
			array(
				'default-color' => 'ffffff',
				'default-image' => '',
			)
		)
	);

	// Add theme support for selective refresh for widgets.
	add_theme_support('customize-selective-refresh-widgets');

	/**
	 * Add support for core custom logo.
	 *
	 * @link https://codex.wordpress.org/Theme_Logo
	 */
	add_theme_support(
		'custom-logo',
		array(
			'height' => 250,
			'width' => 250,
			'flex-width' => true,
			'flex-height' => true,
		)
	);
}
add_action('after_setup_theme', 'edrio_setup');

/**
 * Set the content width in pixels, based on the theme's design and stylesheet.
 *
 * Priority 0 to make it available to lower priority callbacks.
 *
 * @global int $content_width
 */
function edrio_content_width(){
	$GLOBALS['content_width'] = apply_filters('edrio_content_width', 640);
}
add_action('after_setup_theme', 'edrio_content_width', 0);

/**
 * Register widget area.
 *
 * @link https://developer.wordpress.org/themes/functionality/sidebars/#registering-a-sidebar
 */
function edrio_widgets_init(){
	register_sidebar(
		array(
			'name' => esc_html__('Sidebar', 'edrio'),
			'id' => 'sidebar-1',
			'description' => esc_html__('Add widgets here.', 'edrio'),
			'before_widget' => '<div id="%1$s" class="%2$s ed-sidebar-widget ver_2">',
			'after_widget' => '</div>',
			'before_title' => '<h3 class="widget-title">',
			'after_title' => '</h3>',
		)
	);
	register_sidebar(
		array(
			'name' => esc_html__('Shop Siderbar', 'edrio'),
			'id' => 'shop-sidebar-1',
			'description' => esc_html__('Add widgets here.', 'edrio'),
			'before_widget' => '<div id="%1$s" class="widget mt-30 %2$s">',
			'after_widget' => '</div>',
			'before_title' => '<h2 class="widget__title">',
			'after_title' => '</h2>',
		)
	);
}
add_action('widgets_init', 'edrio_widgets_init');



/**
 *Google Font Load 
 */
if (!function_exists('edrio_fonts_url')):

	function edrio_fonts_url(){
		$fonts_url = '';
		$font_families = array();
		$subsets = 'latin';

		if ('off' !== _x('on', 'Urbanist: on or off', 'edrio')) {
			$font_families[] = 'Urbanist:100,100i,200,200i,300,300i,400,400i,500,500i,600,600i,700,700i,800,800i,900,900i';
		}

		if ('off' !== _x('on', 'Inter: on or off', 'edrio')) {
			$font_families[] = 'Inter:100,100i,300,300i,400,400i,500,500i,700,700i,800,800i,900,900i';
		}
		if ('off' !== _x('on', 'Amatic SC: on or off', 'edrio')) {
			$font_families[] = 'Amatic SC:400,700';
		}

		if ('off' !== _x('on', 'Epilogue: on or off', 'edrio')) {
			$font_families[] = 'Epilogue:100,100i,200,200i,300,300i,400,400i,500,500i,600,600i,700,700i,800,800i,900,900i';
		}

		if ('off' !== _x('on', 'Figtree: on or off', 'edrio')) {
			$font_families[] = 'Figtree:300,300i,400,400i,500,500i,600,600i,700,700i,800,800i,900,900i';
		}

		if ('off' !== _x('on', 'Fredoka: on or off', 'edrio')) {
			$font_families[] = 'Fredoka:300,400,500,600,700';
		}
		
		
		if ($font_families) {
			$fonts_url = add_query_arg(
				array(
					'family' => urlencode(implode('|', $font_families)),
					'subset' => urlencode($subsets),
				),
				'https://fonts.googleapis.com/css'
			);
		}

		return esc_url_raw($fonts_url);
	}
endif;


/**
 * Enqueue scripts and styles.
 */
function edrio_scripts(){

	wp_enqueue_style('edrio-google-fonts', edrio_fonts_url(), array(), null);

	wp_enqueue_style('bootstrap', EDRIO_CSS_PATH . '/bootstrap.min.css');
	wp_enqueue_style('e-animations', EDRIO_CSS_PATH . '/animate.css');
	wp_enqueue_style('fontawesome', EDRIO_CSS_PATH . '/fontawesome.css');
	wp_enqueue_style('magnific-popup', EDRIO_CSS_PATH . '/magnific-popup.css');
	wp_enqueue_style('nice-select', EDRIO_CSS_PATH . '/nice-select.css');
	wp_enqueue_style('odometer-theme-default', EDRIO_CSS_PATH . '/odometer-theme-default.css');
	wp_enqueue_style('edrio-swiper', EDRIO_CSS_PATH . '/swiper.min.css');
	wp_enqueue_style('video', EDRIO_CSS_PATH . '/video.min.css');
	wp_enqueue_style('edrio-main', EDRIO_CSS_PATH . '/style.css');

	if (class_exists('WooCommerce')) {
		wp_enqueue_style('woocommerce-style', get_template_directory_uri() . '/woocommerce/woocommerce.css');
	}

	$your_curnt_lang = apply_filters('wpml_current_language', NULL);
	if (is_rtl() && $your_curnt_lang != 'en') {
		wp_enqueue_style('binsro-rtl', EDRIO_CSS_PATH . '/rtl.css');
	}

	wp_enqueue_style('edrio-style', get_stylesheet_uri(), array());

	wp_enqueue_script( 'imagesloaded', ['jquery'], false, true );
    wp_enqueue_script( 'jquery-ui-core', ['jquery'], false, true );
	wp_enqueue_script('bootstrap-bundle', EDRIO_JS_PATH . '/bootstrap.bundle.min.js', array('jquery'), '1.0', true);
	wp_enqueue_script('appear', EDRIO_JS_PATH . '/appear.js', array('jquery'), '1.0', true);
	wp_enqueue_script('gsap', EDRIO_JS_PATH . '/gsap.min.js', array('jquery'), '1.0', true);
	wp_enqueue_script('gsap', EDRIO_JS_PATH . '/gsap.min.js', array('jquery'), '1.0', true);
	wp_enqueue_script('isotope', EDRIO_JS_PATH . '/isotope.pkgd.min.js', array('jquery'), '1.0', true);
	wp_enqueue_script('counterup', EDRIO_JS_PATH . '/jquery.counterup.min.js', array('jquery'), '1.0', true);
	wp_enqueue_script('magnific-popup', EDRIO_JS_PATH . '/jquery.magnific-popup.min.js', array('jquery'), '1.0', true);
	wp_enqueue_script('marquee', EDRIO_JS_PATH . '/jquery.marquee.min.js', array('jquery'), '1.0', true);
	wp_enqueue_script('nice-select', EDRIO_JS_PATH . '/jquery.nice-select.min.js', array('jquery'), '1.0', true);
	wp_enqueue_script('knob', EDRIO_JS_PATH . '/knob.js', array('jquery'), '1.0', true);
	wp_enqueue_script('lenis', EDRIO_JS_PATH . '/lenis.min.js', array('jquery'), '1.0', true);
	wp_enqueue_script('ScrollTrigger', EDRIO_JS_PATH . '/ScrollTrigger.min.js', array('jquery'), '1.0', true);
	wp_enqueue_script('split-type', EDRIO_JS_PATH . '/split-type.min.js', array('jquery'), '1.0', true);
	wp_enqueue_script('SplitText', EDRIO_JS_PATH . '/SplitText.min.js', array('jquery'), '1.0', true);
	wp_enqueue_script('swiper-edrio', EDRIO_JS_PATH . '/swiper-bundle.min.js', array('jquery'), '1.0', true);
	wp_enqueue_script('waypoints', EDRIO_JS_PATH . '/waypoints.min.js', array('jquery'), '1.0', true);
	wp_enqueue_script('wow', EDRIO_JS_PATH . '/wow.min.js', array('jquery'), '1.0', true);
	
	wp_enqueue_script('edrio-script', EDRIO_JS_PATH . '/script.js', array('jquery'), '1.0', true);


	if (is_singular() && comments_open() && get_option('thread_comments')) {
		wp_enqueue_script('comment-reply');
	}
}
add_action('wp_enqueue_scripts', 'edrio_scripts');

/**
 * Implement the Custom Header feature.
 */
require EDRIO_THEME_DRI . '/inc/custom-header.php';

/**
 * Custom template tags for this theme.
 */
require EDRIO_THEME_DRI . '/inc/template-tags.php';

/**
 * Custom template tags for this theme.
 */
require EDRIO_THEME_DRI . '/inc/class-wp-edrio-navwalker.php';

/**
 * Functions which enhance the theme by hooking into WordPress.
 */
require EDRIO_THEME_DRI . '/inc/template-functions.php';

/**
 * Functions which enhance the theme by hooking into WordPress.
 */
require EDRIO_THEME_DRI . '/inc/edrio-functions.php';

/**
 * Cs Fremwork Config
 */
require EDRIO_THEME_DRI . '/inc/cs-framework-functions.php';

/**
 * Dynamic Style
 */
require EDRIO_THEME_DRI . '/inc/dynamic-style.php';

/**
 * edrio Core Functions
 */
require EDRIO_THEME_DRI . '/inc/edrio-helper-class.php';

/**
 * edrio Core Functions
 */
require EDRIO_THEME_DRI . '/inc/admin/class-admin-dashboard.php';

/**
 * edrio Core Functions
 */
require EDRIO_THEME_DRI . '/inc/admin/demo-import/functions.php';

/**
 * Customizer additions.
 */
require EDRIO_THEME_DRI . '/inc/customizer.php';


/**
 * Initial Breadcrumb
 */
require EDRIO_THEME_DRI . '/inc/breadcrumb-init.php';



/**
 * Load Jetpack compatibility file.
 */
if (defined('JETPACK__VERSION')) {
	require EDRIO_THEME_DRI . '/inc/jetpack.php';
}

