<?php

add_action('tgmpa_register', 'edrio_register_required_plugins');

function edrio_register_required_plugins(){

    $plugins = array(
        array(
            'name' => esc_html__('Edrio Plugin', 'edrio'),
            'slug' => 'edrio-plugin',
            'source' => ('https://themexriver.com/wp/edrio/tools/edrio-plugin.zip'),
            'required' => true,
            'force_activation' => false,
            'force_deactivation' => false,
        ),
        array(
            'name' => 'Tutor LMS',
            'slug' => 'tutor',
            'required' => true,
        ),
        array(
            'name' => 'Elementor Website Builder',
            'slug' => 'elementor',
            'required' => true,
        ),
        array(
            'name' => esc_html__('Envato Market', 'edrio'),
            'slug' => 'envato-market',
            'source' => esc_url('https://goo.gl/pkJS33'),
            'external_url' => esc_url('https://goo.gl/pkJS33'),
            'required' => false,
        ),
        
        array(
            'name' => esc_html__('Contact Form 7', 'edrio'),
            'slug' => 'contact-form-7',
            'required' => false,
        ),
       
        array(
            'name' => esc_html__('MC4WP: Mailchimp for WordPress', 'edrio'),
            'slug' => 'mailchimp-for-wp',
            'required' => false,
        ),

        array(
            'name' => esc_html__('One Click Demo Import', 'edrio'),
            'slug' => 'one-click-demo-import',
            'required' => true,
        ),
        array(
            'name' => esc_html__('WooCommerce', 'edrio'),
            'slug' => 'woocommerce',
            'required' => false,
        ),
        array(
            'name' => esc_html__('ShopEngine Elementor WooCommerce Builder Addon – All in One WooCommerce Solution', 'edrio'),
            'slug' => 'shopengine',
            'required' => false,
        )

    );

    $config = array(
        'id' => 'edrio',
        'parent_slug' => 'edrio',
        'menu' => 'tgmpa-install-plugins',
        'dismissable' => true,
        'dismiss_msg' => '',
        'is_automatic' => false,
        'message' => '',
        'default_path' => '',
    );

    tgmpa($plugins, $config);
}
