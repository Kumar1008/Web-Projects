<?php

/**
 * [edrio_breadcrumb description]
 * @return [type] [description]
 */
function edrio_breadcrumb(){

	$wpbreadcrumb_class = '';
	$breadcrumb_show = 1;

	$id = get_the_ID();

	if (is_front_page() && is_home()) {
		$title = get_the_title();
		$wpbreadcrumb_class = 'tx-front-page';
	} elseif (is_front_page()) {
		$title = get_the_title();
		$breadcrumb_show = 0;

	} elseif (is_home()) {
		if (get_option('page_for_posts')) {
			$id = get_option('page_for_posts');
			$title = get_the_title(get_option('page_for_posts'));
		}
	} elseif (is_single() && 'post' == get_post_type()) {
		$title = get_the_title();
	} elseif (is_search()) {
		$title = esc_html__('Search Results for : ', 'edrio') . get_search_query();
	} elseif (is_404()) {
		$title = esc_html__('Page not Found', 'edrio');
	} elseif (function_exists('is_woocommerce') && is_shop()) {
		$title = get_the_title(get_option('woocommerce_shop_page_id'));
	} elseif (function_exists('is_woocommerce') && is_product()) {
		$title = __('Product Details', 'edrio');
	} elseif (function_exists('is_woocommerce') && is_product_tag()) {
		$title = get_the_archive_title();
	} elseif (function_exists('is_woocommerce') && is_product_category()) {
		$title = get_the_archive_title();
	} elseif (is_archive()) {
		$title = get_the_archive_title();
	} else {
		$title = get_the_title();
	}

	// from page meta
	if (get_option('page_for_posts')) {
		$page_for_posts = get_queried_object_id();
		$page_for_posts_meta = get_post_meta($page_for_posts, 'edrio_page_meta', true) ? get_post_meta($page_for_posts, 'edrio_page_meta', true) : [];
	} else {
		$page_meta = get_post_meta($id, 'edrio_page_meta', true) ? get_post_meta($id, 'edrio_page_meta', true) : [];
	}

	if (get_option('page_for_posts')) {
		$enable_page_preadcrumb = array_key_exists('enable_page_preadcrumb', $page_for_posts_meta) ? $page_for_posts_meta['enable_page_preadcrumb'] : true;
	} else {
		$enable_page_preadcrumb = array_key_exists('enable_page_preadcrumb', $page_meta) ? $page_meta['enable_page_preadcrumb'] : true;
	}

	if (get_option('page_for_posts')) {
		$enable_bg_image = array_key_exists('enable_bg_image', $page_for_posts_meta) ? $page_for_posts_meta['enable_bg_image'] : true;
	} else {
		$enable_bg_image = array_key_exists('enable_bg_image', $page_meta) ? $page_meta['enable_bg_image'] : true;
	}

	// ✅ Add condition to exclude Tutor LMS courses
	if ($enable_page_preadcrumb == true && $breadcrumb_show == 1 && !is_singular('courses')) {

		if (get_option('page_for_posts')) {
			$bg_img_from_page = array_key_exists('bg_img_from_page', $page_for_posts_meta) ? $page_for_posts_meta['bg_img_from_page'] : '';
			$enable_custom_title = array_key_exists('enable_custom_title', $page_for_posts_meta) ? $page_for_posts_meta['enable_custom_title'] : false;
			$page_custom_title = array_key_exists('page_custom_title', $page_for_posts_meta) ? $page_for_posts_meta['page_custom_title'] : '';
		} else {
			$bg_img_from_page = array_key_exists('bg_img_from_page', $page_meta) ? $page_meta['bg_img_from_page'] : '';
			$enable_custom_title = array_key_exists('enable_custom_title', $page_meta) ? $page_meta['enable_custom_title'] : false;
			$page_custom_title = array_key_exists('page_custom_title', $page_meta) ? $page_meta['page_custom_title'] : '';
		}

		$breadcrumb_bg = cs_get_option('breadcrumb_bg_img');
		$bg_img = !empty($breadcrumb_bg) ? $breadcrumb_bg['url'] : '';

		if ($enable_bg_image == false) {
			$bg_img = $bg_img;
		} else {
			$bg_img = !empty($bg_img_from_page['url']) ? $bg_img_from_page['url'] : $bg_img;
		}

		$shop_details_breadcrumb = is_single() && 'product' == get_post_type() ? ' no-breadcrumb-ttile' : '';
		$bg_url = !empty($bg_img) ? $bg_img : get_template_directory_uri() . '/assets/img/bread-bg.webp';

		$title = $enable_custom_title == true ? $page_custom_title : $title;

		if (is_front_page()) {
			$title = __('Blog', 'edrio');
		}

		if (has_nav_menu('main-menu')) {
			$no_menu_class = '';
		} else {
			$no_menu_class = ' pt-200';
		}

		?>
		<section id="ed-breadcrumb" class="ed-breadcrumb-sec" data-background="<?php echo esc_url($bg_url); ?>">
			<div class="container">
				<div class="ed-breadcrumb-content">
					<div class="ed-breadcrumb-text text-center headline ul-li">
						<h2 class="bread_title"><?php echo wp_kses_post($title); ?></h2>
						<?php echo edrio_breadcrumb_callback(); ?>
					</div>
				</div>
			</div>
		</section>
		<?php
	}
}
add_action('edrio_before_main_content', 'edrio_breadcrumb');


function edrio_breadcrumb_callback()
{
	global $wp_query;
	$queried_object = get_queried_object();
	$breadcrumb = '';
	$delimiter = '';
	$before = '';
	$after = '';

	if (!is_front_page()) {
		$breadcrumb .= '<ul class="edrio-breadcrumb">';

		// Home link
		$breadcrumb .= '<li><a href="' . home_url('/') . '">' . esc_html__('Home', 'edrio') . '</a></li>';

		if (is_category()) {
			$cat_obj = $wp_query->get_queried_object();
			$this_category = get_category($cat_obj->term_id);
			if ($this_category->parent != 0) {
				$parent_category = get_category($this_category->parent);
				$breadcrumb .= '<li>' . get_category_parents($parent_category, true, '</li><li>') . '</li>';
			}
			$breadcrumb .= '<li><a href="' . get_category_link(get_query_var('cat')) . '">' . single_cat_title('', false) . '</a></li>';

		} elseif ($wp_query->is_posts_page) {
			$breadcrumb .= '<li>' . $queried_object->post_title . '</li>';

		} elseif (is_tax()) {
			$breadcrumb .= '<li><a href="' . get_term_link($queried_object) . '">' . $queried_object->name . '</a></li>';

		} elseif (is_page()) {
			global $post;
			if ($post->post_parent) {
				$anc = get_post_ancestors($post->ID);
				foreach ($anc as $ancestor) {
					$breadcrumb .= '<li><a href="' . get_permalink($ancestor) . '">' . get_the_title($ancestor) . '</a></li>';
				}
			}
			$breadcrumb .= '<li>' . get_the_title($post->ID) . '</li>';

		} elseif (is_singular()) {
			if ($category = wp_get_object_terms(get_the_ID(), array('category', 'location', 'tax_feature'))) {
				if (!is_wp_error($category)) {
					$breadcrumb .= '<li><a href="' . get_term_link($category[0]) . '">' . $category[0]->name . '</a></li>';
				}
			}
			$breadcrumb .= '<li>' . get_the_title() . '</li>';

		} elseif (is_tag()) {
			$breadcrumb .= '<li><a href="' . get_term_link($queried_object) . '">' . single_tag_title('', false) . '</a></li>';

		} elseif (is_day()) {
			$breadcrumb .= '<li>' . esc_html__('Archive for ', 'edrio') . get_the_time('F jS, Y') . '</li>';

		} elseif (is_month()) {
			$breadcrumb .= '<li><a href="' . get_month_link(get_the_time('Y'), get_the_time('m')) . '">' . __('Archive for ', 'edrio') . get_the_time('F, Y') . '</a></li>';

		} elseif (is_year()) {
			$breadcrumb .= '<li><a href="' . get_year_link(get_the_time('Y')) . '">' . __('Archive for ', 'edrio') . get_the_time('Y') . '</a></li>';

		} elseif (is_author()) {
			$breadcrumb .= '<li><a href="' . esc_url(get_author_posts_url(get_the_author_meta("ID"))) . '">' . __('Archive for ', 'edrio') . get_the_author() . '</a></li>';

		} elseif (is_search()) {
			$breadcrumb .= '<li>' . esc_html__('Search Results for ', 'edrio') . get_search_query() . '</li>';

		} elseif (is_404()) {
			$breadcrumb .= '<li>' . esc_html__('404 - Not Found', 'edrio') . '</li>';

		} elseif (is_post_type_archive('product')) {
			$shop_page_id = wc_get_page_id('shop');
			if (get_option('page_on_front') !== $shop_page_id) {
				$shop_page = get_post($shop_page_id);
				$_name = wc_get_page_id('shop') ? get_the_title(wc_get_page_id('shop')) : '';
				if (!$_name) {
					$product_post_type = get_post_type_object('product');
					$_name = $product_post_type->labels->singular_name;
				}
				if (is_search()) {
					$breadcrumb .= '<li><a href="' . get_post_type_archive_link('product') . '">' . $_name . '</a></li><li>' . esc_html__('Search results for &ldquo;', 'edrio') . get_search_query() . '&rdquo;</li>';
				} elseif (is_paged()) {
					$breadcrumb .= '<li><a href="' . get_post_type_archive_link('product') . '">' . $_name . '</a></li>';
				} else {
					$breadcrumb .= '<li>' . $_name . '</li>';
				}
			}
		}

		$breadcrumb .= '</ul>';
	}

	return $breadcrumb;
}

