<?php

// File Security Check
if (!defined('ABSPATH')) {
    exit;
}

function edrio_theme_options_style()
{

    //
    // Enqueueing StyleSheet file
    //
    wp_enqueue_style('edrio-theme-custom-style', get_template_directory_uri() . '/assets/css/custom-style.css');
    $css_output = '';
    $primery_color  = cs_get_option('theme-color-1');
    $primery_color2 = cs_get_option('theme-color-2');
    $primery_color3 = cs_get_option('theme-color-3');
    $primery_color4 = cs_get_option('theme-color-4');
    

    /**
     * Theme Primery Global Color
     */
    if (!empty($primery_color)) {
        $css_output .= '       
        :root {
            --kd-clr-pr-1: ' . esc_attr($primery_color) . '
        }            
        ';
    }
    if (!empty($primery_color2)) {
        $css_output .= '       
        :root {
            --kd-clr-pr-4: ' . esc_attr($primery_color2) . '
        }            
        ';
    }
    if (!empty($primery_color3)) {
        $css_output .= '       
        :root {
            --kd-clr-sd-1: ' . esc_attr($primery_color3) . '
        }            
        ';
    }
    if (!empty($primery_color4)) {
        $css_output .= '       
        :root {
            --kd-clr-sd-4: ' . esc_attr($primery_color4) . '
        }            
        ';
    }

    wp_add_inline_style('edrio-theme-custom-style', $css_output);

}
add_action('wp_enqueue_scripts', 'edrio_theme_options_style');
