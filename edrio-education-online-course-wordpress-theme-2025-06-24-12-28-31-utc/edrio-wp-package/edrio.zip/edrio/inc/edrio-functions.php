<?php


/**
 * Preloader
 *
 * @return  [type]  [return description]
 */
function edrio_preloader(){
    $preloader_enable = cs_get_option('preloader_enable');
    $edrio_custom_preloader = cs_get_option('edrio_custom_preloader');
    $edrio_logo_preloader = cs_get_option('edrio_logo_preloader');

    if ($preloader_enable == true):
     ?>
        <div id="preloader">
            <div class="preloader-wrap ">
                <div class="loader">
                    <div class="dot"></div>
                    <div class="dot"></div>
                    <div class="dot"></div>
                    <div class="dot"></div>
                    <div class="dot"></div>
                </div>
            </div>
        </div>
        <?php
    endif;
}

function edrio_scroll_up_btn(){
    $scroll_up_btn = cs_get_option('scroll_up_btn');

    if ($scroll_up_btn == true):
        ?>
        <div class="ed-up">
  		<a href="#" class="ed-scrollup text-center"><i class="fas fa-chevron-up"></i></a>
  	</div>
        <?php
    endif;
}

/**
 * edrio Post Loop
 *
 * @return  [type]  [return description]
 */
function edrio_post_loop(){
    if (have_posts()):

        /* Start the Loop */
        while (have_posts()):
            the_post();

            /*
             * Include the Post-Type-specific template for the content.
             * If you want to override this in a child theme, then include a file
             * called content-___.php (where ___ is the Post Type name) and that will be used instead.
             */
            get_template_part('template-parts/content', get_post_type());

        endwhile; ?>
        <!-- pagination -->
        <div class="ed-pagination mt-40 text-center ul-li">
            <?php
            edrio_pagination(
                '
                    <i class="fa-solid fa-angles-left feh-pagination-icon"></i>',
                '<i class="fa-solid fa-angles-right feh-pagination-icon"></i>',
                '',
                ['class' => '']
            );
            ?>
        </div>



    <?php else:

        get_template_part('template-parts/content', 'none');

    endif;
}

/**
 * Single Post Loop
 *
 * @return  [type]  [return description]
 */
function edrio_single_post_loop(){
    while (have_posts()):
        the_post();

        get_template_part('template-parts/content', 'single');
    endwhile; // End of the loop.
}

/**
 * Archive Loop
 *
 * @return  [type]  [return description]
 */
function edrio_post_archive_loop(){
    if (have_posts()):
        /* Start the Loop */
        while (have_posts()):
            the_post();

            /*
             * Include the Post-Type-specific template for the content.
             * If you want to override this in a child theme, then include a file
             * called content-___.php (where ___ is the Post Type name) and that will be used instead.
             */
            get_template_part('template-parts/content', get_post_type());

        endwhile; ?>

        <div class="ed-pagination mt-40 text-center ul-li">
        <?php
            edrio_pagination(
                '
                    <i class="fa-solid fa-angles-left feh-pagination-icon"></i>',
                '<i class="fa-solid fa-angles-right feh-pagination-icon"></i>',
                '',
                ['class' => '']
            );
            ?>
        </div>

    <?php else:

        get_template_part('template-parts/content', 'none');

    endif;
}

/**
 * Search Loop
 *
 * @return  [type]  [return description]
 */
function edrio_search_loop(){
    if (have_posts()):

        /* Start the Loop */
        while (have_posts()):
            the_post();

            /**
             * Run the loop for the search to output the results.
             * If you want to overload this in a child theme then include a file
             * called content-search.php and that will be used instead.
             */
            get_template_part('template-parts/content', 'search');

        endwhile; ?>
        <div class="ed-pagination mt-40 text-center ul-li">
            <?php
            edrio_pagination(
                '
                    <i class="fa-solid fa-angles-left feh-pagination-icon"></i>',
                '<i class="fa-solid fa-angles-right feh-pagination-icon"></i>',
                '',
                ['class' => '']
            );
            ?>
        </div>

    <?php else:

        get_template_part('template-parts/content', 'none');

    endif;
}

/**
 * Page Loop
 *
 * @return  [type]  [return description]
 */
function edrio_page_loop(){
    while (have_posts()):
        the_post();

        get_template_part('template-parts/content', 'page');

        // If comments are open or we have at least one comment, load up the comment template.
        if (comments_open() || get_comments_number()):
            comments_template();
        endif;

    endwhile; // End of the loop.
}
