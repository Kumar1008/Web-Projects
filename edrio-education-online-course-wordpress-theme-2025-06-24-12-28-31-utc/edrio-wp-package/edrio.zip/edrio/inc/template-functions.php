<?php
/**
 * Functions which enhance the theme by hooking into WordPress
 *
 * @package edrio
 */
add_filter('wpcf7_form_elements', function ($content) {
	$content = preg_replace('/<(span).*?class="\s*(?:.*\s)?wpcf7-form-control-wrap(?:\s[^"]+)?\s*"[^\>]*>(.*)<\/\1>/i', '\2', $content);

	return $content;
});
/**
 * Adds custom classes to the array of body classes.
 *
 * @param array $classes Classes for the body element.
 * @return array
 */
function edrio_body_classes($classes){
	// Adds a class of hfeed to non-singular pages.
	if (!is_singular()) {
		$classes[] = 'hfeed';
	}

	// Adds a class of no-sidebar when there is no sidebar present.
	if (!is_active_sidebar('sidebar-1')) {
		$classes[] = 'no-sidebar';
	}

	return $classes;
}
add_filter('body_class', 'edrio_body_classes');

/**
 * Add a pingback url auto-discovery header for single posts, pages, or attachments.
 */
function edrio_pingback_header()
{
	if (is_singular() && pings_open()) {
		printf('<link rel="pingback" href="%s">', esc_url(get_bloginfo('pingback_url')));
	}
}
add_action('wp_head', 'edrio_pingback_header');


/**
 * Breadcrumb
 *
 * @return  [type]  [return description]
 */
function edrio_the_breadcrumb()
{
	global $wp_query;
	$queried_object = get_queried_object();
	$breadcrumb = '';
	$delimiter = '';
	$before = '<li class="breadcrumb-item">';
	$after = '</li>';
	if (!is_front_page()) {
		$breadcrumb .= $before . '<a href="' . home_url('/') . '">' . esc_html__('Home', 'edrio') . ' &nbsp;</a>' . $after;
		/** If category or single post */
		if (is_category()) {
			$cat_obj = $wp_query->get_queried_object();
			$this_category = get_category($cat_obj->term_id);
			if ($this_category->parent != 0) {
				$parent_category = get_category($this_category->parent);
				$breadcrumb .= get_category_parents($parent_category, true, $delimiter);
			}
			$breadcrumb .= $before . '<a href="' . get_category_link(get_query_var('cat')) . '">' . single_cat_title('', false) . '</a>' . $after;
		} elseif ($wp_query->is_posts_page) {
			$breadcrumb .= $before . $queried_object->post_title . $after;
		} elseif (is_tax()) {
			$breadcrumb .= $before . '<a href="' . get_term_link($queried_object) . '">' . $queried_object->name . '</a>' . $after;
		} elseif (is_page()) /** If WP pages */{
			global $post;
			if ($post->post_parent) {
				$anc = get_post_ancestors($post->ID);
				foreach ($anc as $ancestor) {
					$breadcrumb .= $before . '<a href="' . get_permalink($ancestor) . '">' . get_the_title($ancestor) . ' &nbsp;</a>' . $after;
				}
				$breadcrumb .= $before . '' . get_the_title($post->ID) . '' . $after;
			} else {
				$breadcrumb .= $before . '' . get_the_title() . '' . $after;
			}
		} elseif (is_singular()) {
			if ($category = wp_get_object_terms(get_the_ID(), array('category', 'location', 'tax_feature'))) {
				if (!is_wp_error($category)) {
					$breadcrumb .= $before . '<a href="' . get_term_link(edrio_set($category, '0')) . '">' . edrio_set(edrio_set($category, '0'), 'name') . '&nbsp;</a>' . $after;
					$breadcrumb .= $before . '' . get_the_title() . '' . $after;
				} else {
					$breadcrumb .= $before . '' . get_the_title() . '' . $after;
				}
			} else {
				$breadcrumb .= $before . '' . get_the_title() . '' . $after;
			}
		} elseif (is_tag()) {
			$breadcrumb .= $before . '<a href="' . get_term_link($queried_object) . '">' . single_tag_title('', false) . '</a>' . $after;
		} /**If tag template*/elseif (is_day()) {
			$breadcrumb .= $before . '<a href="#">' . esc_html__('Archive for ', 'edrio') . get_the_time('F jS, Y') . '</a>' . $after;
		} /** If daily Archives */elseif (is_month()) {
			$breadcrumb .= $before . '<a href="' . get_month_link(get_the_time('Y'), get_the_time('m')) . '">' . __('Archive for ', 'edrio') . get_the_time('F, Y') . '</a>' . $after;
		} /** If montly Archives */elseif (is_year()) {
			$breadcrumb .= $before . '<a href="' . get_year_link(get_the_time('Y')) . '">' . __('Archive for ', 'edrio') . get_the_time('Y') . '</a>' . $after;
		} /** If year Archives */elseif (is_author()) {
			$breadcrumb .= $before . '<a href="' . esc_url(get_author_posts_url(get_the_author_meta("ID"))) . '">' . __('Archive for ', 'edrio') . get_the_author() . '</a>' . $after;
		} /** If author Archives */elseif (is_search()) {
			$breadcrumb .= $before . '' . esc_html__('Search Results for ', 'edrio') . get_search_query() . '' . $after;
		} /** if search template */elseif (is_404()) {
			$breadcrumb .= $before . '' . esc_html__('404 - Not Found', 'edrio') . '' . $after;
			/** if search template */
		} elseif (is_post_type_archive('product')) {
			$shop_page_id = wc_get_page_id('shop');
			if (get_option('page_on_front') !== $shop_page_id) {
				$shop_page = get_post($shop_page_id);
				$_name = wc_get_page_id('shop') ? get_the_title(wc_get_page_id('shop')) : '';
				if (!$_name) {
					$product_post_type = get_post_type_object('product');
					$_name = $product_post_type->labels->singular_name;
				}
				if (is_search()) {
					$breadcrumb .= $before . '<a href="' . get_post_type_archive_link('product') . '">' . $_name . '</a>' . $delimiter . esc_html__('Search results for &ldquo;', 'edrio') . get_search_query() . '&rdquo;' . $after;
				} elseif (is_paged()) {
					$breadcrumb .= $before . '<a href="' . get_post_type_archive_link('product') . '">' . $_name . '</a>' . $after;
				} else {
					$breadcrumb .= $before . $_name . $after;
				}
			}
		} else {
			$breadcrumb .= $before . '<a href="' . get_permalink() . '">' . wp_title() . '</a>' . $after;
		}
		/** Default value */
	}

	return $breadcrumb;
}



function edrio_category_html($links)
{
    // Match the category name and number of posts separately
    $links = preg_replace('/<a href="([^"]+)">([^<]+)<\/a>&nbsp;\((\d+)\)/', 
        '<a href="$1">
            <span class="text">$2</span>
            <span class="number">($3)</span>
            <span class="icon-1">
                <i class="flaticon-left-arrow"></i>
            </span>
        </a>', 
        $links);

    return $links;
}
add_filter('wp_list_categories', 'edrio_category_html');


function edrio_archive_html($links){
	$links = str_replace('</a>&nbsp;(', '<span class="number">', $links);
	$links = str_replace(')', '</span> <span class="icon-1" >
	<i class="flaticon-left-arrow"></i>
</span></a>', $links);
	return $links;
}

add_filter('get_archives_link', 'edrio_archive_html');


/**
 * Comment Link Class
 *
 * @param [type] $class
 * @return void
 */
function wpdocs_comment_reply_link_class($class)
{
	$class = str_replace("class='comment-reply-link", "class='comment-reply-link reply-btn", $class);
	return $class;
}

add_filter('comment_reply_link', 'wpdocs_comment_reply_link_class');

/**
 * Comment List Modification
 */

function edrio_comments($comment, $args, $depth)
{
	$GLOBALS['comment'] = $comment; ?>

	<div <?php comment_class('comments-box-single wow fadeInUp'); ?> id="comment-<?php comment_ID() ?>">
		<?php if (get_avatar($comment)) { ?>
			<div class="person-img">
				<?php echo get_avatar($comment, 80); ?>
			</div>
		<?php } ?>
		<div class="comments-box-author-content">
			<div class="heading-wrap">
				<div class="title-wrap">
					<span class="name">
						<?php comment_author_link() ?>
					</span>
					<span class="date">
						<?php echo esc_html(get_the_time(get_option('date_format'))); ?>
					</span>
				</div>
				<?php comment_reply_link(array_merge($args, array('depth' => $depth, 'max_depth' => $args['max_depth'], 'reply_text' => wp_kses('Reply', true)))); ?>
			</div>
			<div class="comment-text">
				<?php comment_text(); ?>
			</div>
		</div>
	</div>

	<?php
}


/**
 * Comment Message Box
 */
function edrio_comment_reform($arg)
{

	$arg['title_reply'] = esc_html__('Leave a comment', 'edrio');
	$arg['comment_field'] = '<textarea id="comment" class="form_control" name="comment" cols="77" rows="3" placeholder="' . esc_attr__("Comment", "edrio") . '" aria-required="true"></textarea>';

	return $arg;

}
add_filter('comment_form_defaults', 'edrio_comment_reform');


/**
 * Comment Form Field
 */
function edrio_modify_comment_form_fields($fields)
{
	$commenter = wp_get_current_commenter();
	$req = get_option('require_name_email');

	$fields['author'] = '<div class="row"><div class="col-lg-6 col-md-6 col-sm-12 form-group"><input type="text" name="author" id="author" value="' . esc_attr($commenter['comment_author']) . '" placeholder="' . esc_attr__("Name", "edrio") . '" size="22" tabindex="1"' . ($req ? 'aria-required="true"' : '') . ' class="form_control" /></div>';

	$fields['email'] = '<div class="col-lg-6 col-md-6 col-sm-12 form-group"><input type="email" name="email" id="email" value="' . esc_attr($commenter['comment_author_email']) . '" placeholder="' . esc_attr__("Email", "edrio") . '" size="22" tabindex="2"' . ($req ? 'aria-required="true"' : '') . ' class="form_control"  /></div>';

	$fields['url'] = '<div class="col-lg-12 col-md-12 col-sm-12 form-group"><input type="url" name="url" id="url" value="' . esc_attr($commenter['comment_author_url']) . '" placeholder="' . esc_attr__("Website", "edrio") . '" size="22" tabindex="2"' . ($req ? 'aria-required="false"' : '') . ' class="form_control"  /></div></div>';

	return $fields;
}
add_filter('comment_form_default_fields', 'edrio_modify_comment_form_fields');

// comment Move Field
function edrio_move_comment_field_to_bottom($fields)
{
	$comment_field = $fields['comment'];
	unset($fields['comment']);
	$fields['comment'] = $comment_field;
	return $fields;
}
add_filter('comment_form_fields', 'edrio_move_comment_field_to_bottom');



/**
 * Product Per Page Count
 *
 * @param [type] $per_page
 * @return void
 */


/**
 * Authore Avater
 */
function edrio_main_author_avatars($size){
	echo get_avatar(get_the_author_meta('email'), $size);
}

add_action('genesis_entry_header', 'edrio_post_author_avatars');




/**
 * pagination
 */
if (!function_exists('edrio_pagination')) {

	function _edrio_pagi_callback($pagination)
	{
		return $pagination;
	}

	//page navegation
	function edrio_pagination($prev, $next, $pages, $args)
	{
		global $wp_query, $wp_rewrite;
		$menu = '';
		$wp_query->query_vars['paged'] > 1 ? $current = $wp_query->query_vars['paged'] : $current = 1;

		if ($pages == '') {
			global $wp_query;
			$pages = $wp_query->max_num_pages;

			if (!$pages) {
				$pages = 1;
			}

		}

		$pagination = [
			'base' => add_query_arg('paged', '%#%'),
			'format' => '',
			'total' => $pages,
			'current' => $current,
			'prev_text' => $prev,
			'next_text' => $next,
			'type' => 'array',
		];

		//rewrite permalinks
		if ($wp_rewrite->using_permalinks()) {
			$pagination['base'] = user_trailingslashit(trailingslashit(remove_query_arg('s', get_pagenum_link(1))) . 'page/%#%/', 'paged');
		}

		if (!empty($wp_query->query_vars['s'])) {
			$pagination['add_args'] = ['s' => get_query_var('s')];
		}

		$pagi = '';
		if (paginate_links($pagination) != '') {
			$paginations = paginate_links($pagination);
			$pagi .= '<ul class="feh-pagination">';
			foreach ($paginations as $key => $pg) {
				$pagi .= '<li class="feh-pagination-item">' . $pg . '</li>';
			}
			$pagi .= '<ul>';
		}

		print _edrio_pagi_callback($pagi);
	}
}


/**
 * Search Widget
 */
function edrio_search_widgets($form)
{
	$form = '<div class="search-widget"><form  method="get" action="' . home_url('/') . '" >
    <input class="sidebar-search-input" placeholder="' . esc_attr__('Search...', 'edrio') . '" type="text"  value="' . get_search_query() . '" name="s" id="s" />
		<button type="submit" class="sidebar-search-btn"><i class="fa-solid fa-magnifying-glass"></i></button>
    </form></div>';
	return $form;
}
add_filter('get_search_form', 'edrio_search_widgets', 100);


/**
 * Authore
 */
function edrio_authore_info()
{

	global $post;
	if (is_object($post)):

		$theme_author_markup = '';
		// Get author's display name
		$display_name = get_the_author_meta('display_name', $post->post_author);

		// If display name is not available then use nickname as display name
		if (empty($display_name))
			$display_name = get_the_author_meta('nickname', $post->post_author);

		// Get author's biographical information or description
		$user_description = get_the_author_meta('user_description', $post->post_author);

		$user_facebook = get_the_author_meta('facebook', $post->post_author);
		$user_twitter = get_the_author_meta('twitter', $post->post_author);
		$user_linkedin = get_the_author_meta('linkedin', $post->post_author);
		$user_instagram = get_the_author_meta('instagram', $post->post_author);
		$user_pinterest = get_the_author_meta('pinterest', $post->post_author);
		$user_youtube = get_the_author_meta('youtube', $post->post_author);

		// Get link to the author archive page
		$user_posts = get_author_posts_url(get_the_author_meta('ID', $post->post_author));
		if (!empty($display_name))
			// Author avatar - - the number 90 is the px size of the image.
			$theme_author_markup .= '<div class="inner-img">' . get_avatar(get_the_author_meta('ID'), 140) . '</div>';
		$theme_author_markup .= '<div class="inner-text headline pera-content">';
		$theme_author_markup .= '<div class="admin-title-social"><h4>' . $display_name . '</h4></div>';
		$theme_author_markup .= '<p>' . get_the_author_meta('description') . '</p>';
		$theme_author_markup .= '</div>';

		// Pass all this info to post content 
		echo '<div class="art-blog-details-author flex-wrap d-flex flex-wrap align-items-center">' . $theme_author_markup . '</div>';
	endif;
}

function edrio_wp_kses( $val ) {
    return wp_kses( $val, array(

        'p'         => array(
            'class' => array(),
            'style' => array(),
        ),

        'img'    	=> array(
            'src'   => array(),
            'alt'   => array(),
            'class' => array(),
            'style' => array(),
        ),
        'span'   => array(
            'class' => array(),
            'style' => array(),
        ),
        'small'  => array(),
        'div'    => array(
            'style' => array(),
        ),
        'strong' => array(
            'style' => array(),
        ),
        'b'      => array(
            'style' => array(),
        ),
        'br'     => array(),
        'h1'     => array(
            'style' => array(),
        ),
        'i'      => array(
            'class' => array(),
            'style' => array(),
        ),
        'ul'     => array(
            'class' => array(),
            'style' => array(),
        ),
        'ul'     => array(
            'id' => array(),
        ),
        'li'     => array(
            'class' => array(),
            'style' => array(),
        ),
        'li'     => array(
            'id' => array(),
        ),
        'h1'     => array(
            'style' => array(),
        ),
        'h2'     => array(),
        'h3'     => array(
            'style' => array(),
        ),
        'h4'     => array(
            'style' => array(),
        ),
        'h5'     => array(
            'style' => array(),
        ),
        'h6'     => array(
            'style' => array(),
        ),
        'u'     => array(
            'style' => array(),
        ),
        'a'      => array( 
            'href' => array(), 
            'target' => array(),
            'style' => array(),
        ),
        'iframe' => array( 'src' => array(), 'height' => array(), 'width' => array() ),

    ), '' );
}


/**
 * Product Per Page Count
 *
 * @param [type] $per_page
 * @return void
 */ 

 function edrio_product_count( $cols ) {
	$product_count = cs_get_option('product_count');
  	$cols = !empty($product_count) ? $product_count : '12';
  	return $cols;
}
add_filter( 'loop_shop_per_page', 'edrio_product_count', 20 );

/**
 * edrio Single Post Nav
 */
function edrio_single_post_pagination(){
    $edrio_prev_post = get_previous_post();
    $edrio_next_post = get_next_post();
?>
<div class="blog-post-next-btn">
	<a class="next-prv-btn" href="<?php echo esc_url(get_the_permalink($edrio_prev_post));?>"><i class="fal fa-long-arrow-left"></i> <?php esc_html_e('previous post', 'edrio');?></a>
	<a class="next-prv-btn" href="<?php echo esc_url(get_the_permalink($edrio_next_post));?>"><?php esc_html_e('next post', 'edrio');?> <i class="fal fa-long-arrow-right"></i></a>
</div>
<?php
}