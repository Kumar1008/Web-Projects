<?php
/**
 * The main template file
 *
 * This is the most generic template file in a WordPress theme
 * and one of the two required files for a theme (the other being style.css).
 * It is used to display a page when nothing more specific matches a query.
 * E.g., it puts together the home page when no home.php file exists.
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/
 *
 * @package edrio
 */

get_header();
$edrioPostClass = '';
if (is_active_sidebar('sidebar-1')) {
	$edrioPostClass = 'col-lg-8';
} else {
	$edrioPostClass = 'col-lg-10 offset-lg-1';
}
?>
<section id="ag-blog-list" class="ag-blog-list-section pt-100 pb-110">
		<div class="container">
			<div class="row">

			<!-- Content Side -->
			<div class="<?php echo esc_attr($edrioPostClass); ?>">
				<div class="ag-blog-list-item-wrap">
					<?php edrio_post_loop(); ?>
				</div>
			</div>
			<!-- Sidebar Side -->
			<?php get_sidebar(); ?>

		</div>
	</div>
</section>

<?php
get_footer();
