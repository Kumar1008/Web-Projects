<?php
/**
 * The template for displaying all pages
 *
 * This is the template that displays all pages by default.
 * Please note that this is the WordPress construct of pages
 * and that other 'pages' on your WordPress site may use a
 * different template.
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/
 *
 * @package edrio
 */

get_header();
?>
<section class="blog edrio-internal-page pt-120 pb-110">
	<div class="container">
		<div class="row mt-none-30">
			<!-- Content Side -->
			<div class="col-lg-12">
				<div class="blog-page-2-item-wrap mb-50">
					<?php edrio_page_loop(); ?>
				</div>
			</div>
		</div>
	</div>
</section>

<?php
get_footer();
