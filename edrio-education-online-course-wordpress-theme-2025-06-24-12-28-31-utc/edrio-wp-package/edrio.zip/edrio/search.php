<?php
/**
 * The template for displaying search results pages
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/#search-result
 *
 * @package edrio
 */

get_header();
$edrioPostClass = '';
if (is_active_sidebar('sidebar-1')) {
	$edrioPostClass = 'col-xxl-8 col-xl-8 col-lg-8';
} else {
	$edrioPostClass = 'col-lg-10 offset-lg-1';
}
?>
<div class="blog-page-area pt-130 pb-130">
		<div class="container kd-container-1">
			<div class="row">

			<!-- Content Side -->
			<div class="<?php echo esc_attr($edrioPostClass); ?>">
				<div class="blog-page-item-2-wrap">
					<?php edrio_search_loop(); ?>
				</div>
			</div>
			<!-- Sidebar Side -->
			<?php get_sidebar(); ?>

		</div>
	</div>
</div>
<?php
get_footer();
