<?php
/**
 * The template for displaying all single posts
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/#single-post
 *
 * @package edrio
 */

get_header();
$edrioPostClass = '';
if (is_active_sidebar('sidebar-1')) {
	$edrioPostClass = 'col-lg-8';
} else {
	$edrioPostClass = 'col-lg-10 offset-lg-1';
}
?>

<section id="ed-blog-details" class="ed-blog-details-sec pt-80 pb-80">
	<div class="container">
		<div class="ed-blog-details-content">
			<?php edrio_single_post_loop(); ?>
		</div>
	</div>
</section>

<?php
get_footer();
