<?php
/**
 * Template part for displaying page content in career
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/
 *
 * @package edrio
 */

?>
<?php the_content(); ?>