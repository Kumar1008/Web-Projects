<?php
/**
 * Template part for displaying posts
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/
 *
 * @package edrio
 */
$categories = get_the_category();
$blog_btn_text = cs_get_option('blog_btn_text');
$hide_blog_date = cs_get_option('hide_blog_date');
$hide_authore = cs_get_option('hide_authore');
$hide_cmt_date = cs_get_option('hide_cmt_date');
?>

<article id="post-<?php the_ID(); ?>" <?php post_class(''); ?>>
	<div class="blog-page-item-2">
		<?php if (has_post_thumbnail()) { ?>
			<div class="main-img">
				<?php the_post_thumbnail('full') ?>
			</div>
		<?php } ?>
		<div class="item-content">
			<ul class="meta-author">
				<?php if($hide_authore == true):?>
					<li>
						<i class="fa-regular fa-user"></i>
						<?php esc_html_e('By', 'edrio'); ?> <?php the_author();?>
					</li>
				<?php endif;?>
				<?php if($hide_cmt_date == true):?>
					<li>
						<i class="fa-regular fa-comment"></i>
						(<?php echo esc_attr(get_comments_number()); ?>) <?php esc_html_e('comments', 'edrio'); ?>
					</li>
				<?php endif;?>
				<?php if($hide_blog_date == true):?>
					<li>
						<i class="fa-light fa-calendar-days"></i>
						<?php echo date(get_option('date_format')); ?>
					</li>
				<?php endif;?>
			</ul>

			<h3 class="item-title">
				<a href="<?php the_permalink() ?>" aria-label="name"><?php the_title(); ?></a>
			</h3>

			<p class="item-disc"><?php the_excerpt(); ?></p>

			<a href="<?php the_permalink() ?>" class="item-btn" aria-label="name">
				<?php if (!empty($blog_btn_text)) {
					echo esc_html($blog_btn_text);
				} else {
					esc_html_e('Read More', 'edrio');
				} ?>
				<i class="fa-solid fa-arrow-right"></i>
			</a>
		</div>
	</div>
</article><!-- #post-<?php the_ID(); ?> -->