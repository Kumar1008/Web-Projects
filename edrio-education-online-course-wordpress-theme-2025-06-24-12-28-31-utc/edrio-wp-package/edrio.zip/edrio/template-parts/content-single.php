<?php
/**
 * Template part for displaying single posts
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/
 *
 * @package edrio
 */
$categories = get_the_category();
$hide_blog_date = cs_get_option('hide_blog_date');
$hide_authore = cs_get_option('hide_authore');
$hide_cmt_date = cs_get_option('hide_cmt_date');
?>
<div id="post-<?php the_ID(); ?>" <?php post_class('blog-details-content'); ?>>
    <div class="ed-blog-details-text headline pera-content ul-li-block">
        <?php if (has_post_thumbnail()) { ?>
            <div class="main-img">
                <?php the_post_thumbnail('full') ?>
            </div>
		<?php } ?>
        <ul class="meta-author">
            <?php if($hide_authore == true):?>
                <li>
                    <i class="fa-regular fa-user"></i>
                    <?php esc_html_e('By', 'edrio'); ?> <?php the_author();?>
                </li>
            <?php endif;?>
            <?php if($hide_cmt_date == true):?>
                <li>
                    <i class="fa-regular fa-comment"></i>
                    (<?php echo esc_attr(get_comments_number()); ?>) <?php esc_html_e('comments', 'edrio'); ?>
                </li>
            <?php endif;?>
            <?php if($hide_blog_date == true):?>
                <li>
                    <i class="fa-light fa-calendar-days"></i>
                    <?php echo date(get_option('date_format')); ?>
                </li>
            <?php endif;?>
        </ul>
        <h3 class="blog-title wow" data-splitting="">
            <?php the_title();?>
        </h3>
        <div class="blog-disc">
            <?php
                the_content(
                    sprintf(
                        wp_kses(
                            /* translators: %s: Name of current post. Only visible to screen readers */
                            __('Continue reading<span class="screen-reader-text"> "%s"</span>', 'edrio'),
                            array(
                                'span' => array(
                                    'class' => array(),
                                ),
                            )
                        ),
                        wp_kses_post(get_the_title())
                    )
                );

                wp_link_pages(
                    array(
                        'before' => '<div class="page-links">' . esc_html__('Pages:', 'edrio'),
                        'after' => '</div>',
                    )
                );
            ?>
        </div>

        <div class="art-blog-share-tag pt-30 pb-30 flex-wrap d-flex justify-content-between">
            <div class="art-blog-tag">
                <span class="title wow" data-splitting="">
                    <?php esc_html_e('Tags:', 'edrio'); ?>
                </span>
                <?php edrio_entry_footer();?>
            </div>
            <?php if(function_exists('edrio_post_share')):?>
                <div class="blog-share">
                    <?php edrio_post_share();?>
                </div>
            <?php endif;?>
        </div>


        <?php edrio_authore_info();?>


        <!-- comments- -->
        <?php 
            if ( comments_open() || get_comments_number() ) :
                comments_template();
            endif; 
        ?>

    </div>
</div>