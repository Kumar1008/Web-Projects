<?php
/**
 * Template part for displaying page content in template
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/
 *
 * @package edrio
 */

?>
<?php the_content(); ?>