<?php
/**
 * Template part for displaying posts
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/
 *
 * @package edrio
 */
$categories = get_the_category();
$blog_btn_text = cs_get_option('blog_btn_text');
$hide_blog_date = cs_get_option('hide_blog_date');
$hide_authore = cs_get_option('hide_authore');
$hide_cmt_date = cs_get_option('hide_cmt_date');
?>

<article id="post-<?php the_ID(); ?>" <?php post_class(''); ?>>
	<div class="ag-blog-list-feed">
		<div class="item-img position-relative">
			<?php get_template_part('template-parts/post-formats/content'); ?>
		</div>
		<div class="blog-item-meta">
			<a href="#"><i class="fas fa-user-circle"></i> <?php the_author();?></a>
			<a href="#"><i class="fas fa-comments"></i> <?php esc_html_e( 'comments', 'edrio' )?> (<?php echo esc_attr(get_comments_number());?>)</a>
			<a href="#"><i class="fas fa-calendar-alt"></i> <?php echo get_the_date();?></a>
		</div>
		<div class="item-text headline pera-content">
			<h3 class="blog_title href-underline"><a href="<?php the_permalink()?>"><?php the_title();?></a></h3>
			<p><?php the_excerpt();?></p>
			<a class="read_more text-uppercase" href="<?php the_permalink()?>"><span><?php if(!empty($blog_btn_text)){echo esc_html($blog_btn_text);}else{esc_html_e( 'Read More', 'edrio' );}?><i class="fa-solid fa-arrow-right-long"></i></span></a>
		</div>
	</div>
</article><!-- #post-<?php the_ID(); ?> -->