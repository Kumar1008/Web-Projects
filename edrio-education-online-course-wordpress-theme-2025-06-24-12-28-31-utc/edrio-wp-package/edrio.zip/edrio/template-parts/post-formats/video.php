<?php
   
   if(get_post_meta(get_the_ID(), 'edrio_post_format_meta', true)) {
        $post_video_meta = get_post_meta(get_the_ID(), 'edrio_post_format_meta', true);
    } else {
        $post_video_meta = array();
    }

    if( array_key_exists( 'video_link', $post_video_meta )) {
        $video_link = $post_video_meta['video_link'];
    } else {
        $video_link = '';
    } 

?>
<div class="inner-img">
    <?php the_post_thumbnail( 'full', ['class' => 'img-fluid'] );?>
</div>
<div class="ed-vd5-play">
    <div class="video-play-btn">
        <a class="agt_play_btn video_box" href="<?php echo esc_url($video_link);?>">
            <i class="fa-solid fa-play"></i>
            <span class="video_btn_border border_wrap-1"></span>
            <span class="video_btn_border border_wrap-2"></span>
            <span class="video_btn_border border_wrap-3"></span>
        </a>
    </div>
</div>