<?php
$course_id = get_query_var('course_id');
if($course_id) {
    // Use the value directly, no need to reassign
} elseif(isset($args['course_id'])) {
    $course_id = $args['course_id'];
} else {
    $course_id = get_the_ID();
}

if(empty($course_id)) {
    $course_id = isset($args[0]) ? $args[0] : null;
}

// Initialize variables
$course_price = '';
$regular_price = '';
$sale_price = '';
$currency_symbol = '$';
$is_free = true;

if(function_exists('tutor')) {
    // Tutor LMS handling
    if(tutor_utils()->is_course_purchasable($course_id)) {
        $is_free = false;
        $course_attributes = get_post_meta($course_id);
        $course_product_id = isset($course_attributes['_tutor_course_product_id'][0]) ? $course_attributes['_tutor_course_product_id'][0] : null;
        
        // Get price from tutor functions
        $price = tutor_utils()->get_course_price($course_id);
        
        // Check if WooCommerce is active and product exists
        if(class_exists('WooCommerce') && $course_product_id) {
            $product = wc_get_product($course_product_id);
            if($product && false !== $product) {
                $course_price = $product->get_price();
                $sale_price = $product->get_sale_price();
                $regular_price = !empty($sale_price) ? $product->get_regular_price() : '';
                $currency_symbol = get_woocommerce_currency_symbol();
            }
        }
    }
} elseif(class_exists('LearnPress')) {
    // LearnPress handling
    $course = LP_Course::get_course($course_id);
    if($course) {
        $currency_symbol = learn_press_get_currency_symbol();
        if(!$course->is_free()) {
            $is_free = false;
            $course_price = !empty($course->get_sale_price()) ? $course->get_sale_price() : $course->get_price();
            $regular_price = $course->get_regular_price();
        }
    }
}
?>

<?php if(function_exists('tutor')): ?>
    <span class="item-price d-flex justify-content-center align-items-center">
        <?php if(!$is_free && tutor_utils()->is_course_purchasable($course_id)): ?>
            <?php echo wp_kses_post(tutor_utils()->get_course_price($course_id)); ?>
        <?php else: ?>
            <?php echo esc_html__('Free', 'edrio'); ?>
        <?php endif; ?>
    </span>
<?php elseif(class_exists('LearnPress')): ?>
    <span class="item-price d-flex justify-content-center align-items-center">
        <?php if(!$is_free): ?>
            <?php echo esc_html($currency_symbol . $course_price); ?>
        <?php else: ?>
            <?php echo esc_html__('Free', 'edrio'); ?>
        <?php endif; ?>
    </span>
<?php endif; ?>