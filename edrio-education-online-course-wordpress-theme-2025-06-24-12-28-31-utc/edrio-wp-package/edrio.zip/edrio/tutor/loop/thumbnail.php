<?php
/**
 * Display loop thumbnail
 *
 * @package Tutor\Templates
 * @subpackage CourseLoopPart
 * @author Themeum <support@themeum.com>
 * @link https://themeum.com
 * @since 1.4.3
 */

$tutor_course_img = get_tutor_course_thumbnail_src();
?>
<div class="item-img-cate position-relative">
	<a href="<?php the_permalink(); ?>" class="tutor-d-block">
		<div class="inner-img">
			<img class="tutor-card-image-top" src="<?php echo esc_url( $tutor_course_img ); ?>" alt="<?php the_title(); ?>" loading="lazy">
		</div>
		<div class="inner-cate">
		<?php 
                            // Get course categories
                            $course_categories = get_the_terms(get_the_ID(), 'course-category');
                            if (!empty($course_categories) && !is_wp_error($course_categories)) {
                                // Display the first category name
                                echo esc_html($course_categories[0]->name);
                            } else {
                                // Fallback if no categories are found
                                echo 'Uncategorized';
                            }
                            ?>
								</div>
	</a>
	<?php do_action( 'tutor_after_course_loop_thumbnail_link', get_the_ID() ); ?>
</div>
