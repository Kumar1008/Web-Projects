<?php
/*
Plugin Name: Edrio Plugin
Plugin URI: https://themeforest.net/user/themexriver
Description: After install the edrio WordPress Theme, you must need to install this "edrio-plugin" first to get all functions of edrio WP Theme.
Author: Raziul Islam
Author URI: http://themexriver.com/
Version: 1.0
Text Domain: edrio-plugin
*/
if ( !defined( 'ABSPATH' ) ) {
    exit; // Exit if accessed directly.
}

/**
 * Define Core Path
 */
define( 'EDRIO_VERSION', '1.0.0' );
define( 'EDRIO_DIR_PATH',plugin_dir_path(__FILE__) );
define( 'EDRIO_DIR_URL',plugin_dir_url(__FILE__) );
define( 'EDRIO_INC_PATH', EDRIO_DIR_PATH . '/inc' );
define( 'EDRIO_PLUGIN_IMG_PATH', EDRIO_DIR_URL . '/assets/img' );

function edrio_plugin_load_textdomain() {
    load_plugin_textdomain('edrio-plugin', false, dirname(plugin_basename(__FILE__)) . '/languages');
}
add_action('init', 'edrio_plugin_load_textdomain');

/**
 * Css Framework Load
 */
if ( file_exists(EDRIO_DIR_PATH.'/lib/codestar-framework/codestar-framework.php') ) {
    require_once  EDRIO_DIR_PATH.'/lib/codestar-framework/codestar-framework.php';
}


/**
 * Megamenu
 */
if (!class_exists('Rs_MegaMenu_Register')) {
    require_once EDRIO_DIR_PATH . '/mega-menu/class-megamenu.php';
    Rs_MegaMenu_Register::get_instance();
}


/**
 *  Elementor - Remove Font Awesome
 */
add_action( 'elementor/frontend/after_register_styles',function() {
    foreach( [ 'solid', 'regular', 'brands' ] as $style ) {
      wp_deregister_style( 'elementor-icons-fa-' . $style );
    }
  }, 20 );


/**
 * Register Custom Widget
 *
 * @return void
 */
function edrio_cw_wisget(){
    register_widget( 'edrio_Recent_Posts' );
}
add_action('widgets_init', 'edrio_cw_wisget');


/**
 * Deregister Elementor Animation
 *
 * @return void
 */
function edrio_de_reg() {
    wp_deregister_style( 'e-animations' );
}
add_action( 'wp_enqueue_scripts', 'edrio_de_reg' );

/**
 * Enqueue Admin Style
 *
 * @return void
 */
function edrio_enqueue_admin_customstyle() {
    wp_enqueue_style( 'admin-style', EDRIO_DIR_URL . 'assets/css/admin-style.css', false, '1.0.0' );

    wp_enqueue_style('flaticon_multipurpose_agency', get_template_directory_uri() . '/assets/css/flaticon_multipurpose_agency.css');
}
add_action( 'admin_enqueue_scripts', 'edrio_enqueue_admin_customstyle' );

/**
 * Enqueue Admin Style
 *
 * @return void
 */
function edrio_enqueue_customstyle() {
    wp_enqueue_style('flaticon_multipurpose_agency', EDRIO_DIR_URL . '/assets/css/flaticon_multipurpose_agency.css');
    wp_enqueue_script( 'edrio-addon-core', EDRIO_DIR_URL . '/assets/js/core.js', array('jquery'), '1.0', true );
}
add_action( 'wp_enqueue_scripts', 'edrio_enqueue_customstyle' );

/**
 * Dequeue Elemenotr Swiper Slider
 *
 * @return  [type]  [return description]
 */
function dequeue_wpml_styles(){
    wp_dequeue_style( 'swiper' );
    wp_deregister_style( 'swiper' );

    wp_dequeue_script( 'swiper' );
    wp_deregister_script( 'swiper' );
}
add_action( 'wp_enqueue_scripts', 'dequeue_wpml_styles', 20 );


/**
 * Script Remove
 *
 * @return  [type]  [return description]
 */
function remove_jquery_sticky() {
		wp_dequeue_script( 'swiper' );
		wp_deregister_script( 'swiper' );
}
add_action( 'elementor/frontend/after_register_scripts', 'remove_jquery_sticky' );


/**
 * Custom Widget
 */
include_once EDRIO_INC_PATH . "/custom-font.php";

/**
 * Custom Widget
 */
include_once EDRIO_INC_PATH . "/custom-widget/recent-post.php";

/**
 * Themeoption
 */
include_once EDRIO_INC_PATH . "/edrio-plugin-helper.php";

function edrio_load_theme_files() {
    /**
     * Custom Metabox
     */
    include_once EDRIO_INC_PATH . "/options/theme-metabox.php";

    /**
     * Theme Option
     */
    include_once EDRIO_INC_PATH . "/options/theme-option.php";
}
add_action('after_setup_theme', 'edrio_load_theme_files');




/**
 * Helper Function
 */
include_once EDRIO_INC_PATH . "/helper.php";

/**
 * Elementor Custom Icon
 */

include_once EDRIO_INC_PATH . "/constim-icon.php";

/**
 * Custom Template CPT
 */
include_once EDRIO_INC_PATH . "/post-type/template.php";
include_once EDRIO_INC_PATH . "/csf-custom-icon.php";

/**
 * Custom Template CPT
 */
include_once EDRIO_INC_PATH . "/post-type/listing_taxnomy.php";


/**
 * Elementor Configuration
 */
include_once EDRIO_DIR_PATH . "/elementor/elementor-init.php";

/**
 * Contact Form 7 Autop Remove
 */
add_filter('wpcf7_autop_or_not', '__return_false');


function tutor_template_load($template_location, $template){
    $location = __DIR__ . "/tutor/{$template}.php";
    if (file_exists($location)) {
        return $location;
    } else {
        return $template_location;
    }
    var_dump($location);
} 
add_filter('tutor_get_template_path', 'tutor_template_load', 10, 2);
