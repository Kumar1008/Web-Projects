<?php 
    $this->add_render_attribute( 'title', 'class', 'elementor-gt-heading sec_title ed-sec-tt-anim ed-has-anim' );
?>
<section id="ed-about-2" class="ab-about-sec-2  pt-160 pb-130">
    <div class="container">
        <div class="ed-about-content-2 position-relative d-flex">
            <?php if(!empty($settings['about_img']['url'])):?>
                <span class="ed-about-shape rotate_view position-absolute">
                    <img class="ed-img-rvl_1" src="<?php echo esc_url($settings['about_img']['url']);?>" alt="<?php if(!empty($settings['about_img']['alt'])){ echo esc_attr($settings['about_img']['alt']);}else{esc_attr_e('About Image', 'edrio-plugin');}?>">
                </span>
            <?php endif;?>
            <div class="ed-ab-img-wrap-2">
                <?php if(!empty($settings['about_img2']['url'])):?>
                    <div class="item-img-1 mb-25">
                        <div class="inner-img ed-image-appear1">
                            <img class="ed-img-rvl_2" src="<?php echo esc_url($settings['about_img2']['url']);?>" alt="<?php if(!empty($settings['about_img2']['alt'])){ echo esc_attr($settings['about_img2']['alt']);}else{esc_attr_e('About Image', 'edrio-plugin');}?>">
                        </div>
                    </div>
                <?php endif;?>
                <?php if(!empty($settings['about_img3']['url'])):?>
                    <div class="item-img-2">
                        <div class="inner-img ed-image-appear2">
                            <img class="ed-img-rvl_2" src="<?php echo esc_url($settings['about_img3']['url']);?>" alt="<?php if(!empty($settings['about_img3']['alt'])){ echo esc_attr($settings['about_img3']['alt']);}else{esc_attr_e('About Image', 'edrio-plugin');}?>">
                        </div>
                    </div>
                <?php endif;?>
            </div>
            <div class="ed-ab-text-wrap-2 pt-20">
                <div class="ed-sec-title-2 headline-2">
                    <?php if(!empty($settings['subtitle'])):?>
                        <div class="subtitle wow fadeInRight" data-wow-delay="100ms" data-wow-duration="1000ms">
                            <?php echo edrio_wp_kses($settings['subtitle']);?>
                        </div>
                    <?php endif;?>
                    <?php 
                        printf('<%1$s %2$s>%3$s</%1$s>',
                            tag_escape($settings['title_tag']),
                            $this->get_render_attribute_string('title'),
                            nl2br(edrio_wp_kses($settings['title']))
                        ); 
                    ?>
                </div>
                <div class="ed-ab-desc-wrap mt-50 d-flex">
                    <div class="ab-desc-img">
                        <?php if(!empty($settings['about_img4']['url'])):?>
                            <div class="item-img ed-image-appear3 mb-30">
                                <img class="ed-img-rvl_3" src="<?php echo esc_url($settings['about_img4']['url']);?>" alt="<?php if(!empty($settings['about_img3']['alt'])){ echo esc_attr($settings['about_img4']['alt']);}else{esc_attr_e('About Image', 'edrio-plugin');}?>">
                            </div>
                        <?php endif;?>
                        <div class="item-client d-flex align-items-center ul-li">
                            <ul>
                            <?php if(!empty($settings['autores'])):?>
                                    <?php foreach($settings['autores'] as $item):?>
                                    <li><img src="<?php echo esc_url($item['url']);?>" alt=""></li>
                                    <?php endforeach;?>
                            </ul>
                            <?php endif;?>
                            <?php if(!empty($settings['quote_text'])):?>
                                <span> <?php echo edrio_wp_kses($settings['quote_text']);?> </span>
                            <?php endif;?>
                        </div>
                    </div>
                    <div class="ab-desc-text pera-content">
                        <?php if(!empty($settings['description'])):?>
                            <p>
                                <?php echo edrio_wp_kses(wpautop($settings['description']));?>
                            </p>
                        <?php endif;?>
                        <div class="ab-desc-ft d-flex mt-35 mb-45 align-items-center">
                            <div class="desc-ft-thumb text-center">
                                <?php if(!empty($settings['counter_img']['url'])):?>
                                    <div class="item-icon">
                                        <img src="<?php echo esc_url($settings['counter_img']['url']);?>" alt="<?php if(!empty($settings['counter_img']['alt'])){ echo esc_attr($settings['counter_img']['alt']);}else{esc_attr_e('About Image', 'edrio-plugin');}?>">
                                    </div>
                                <?php endif;?>
                                <div class="item-text headline-2 pera-content">
                                    <h3>
                                        <span class="counter">
                                            <?php if(!empty($settings['counter'])){ echo esc_html($settings['counter']);}?>
                                        </span>
                                        <?php if(!empty($settings['prefix'])){ echo esc_html($settings['prefix']);}?>
                                    </h3>
                                    <p>
                                        <?php if(!empty($settings['c_title'])):?>
                                            <?php echo edrio_wp_kses($settings['c_title']);?>
                                        <?php endif;?>
                                    </p>
                                </div>
                            </div>
                            <?php if(!empty($settings['features'])):?>
                            <div class="ab-desc-ft-area">
                                <?php foreach($settings['features'] as $item):?>
                                <div class="ab-desc-ft-item d-flex align-items-center">
                                    <div class="item-icon">
                                        <?php if ($item['type'] === 'image' && ($item['icon_img']['url'])) :?>
                                            <img src="<?php echo esc_url($item['icon_img']['url']);?>" alt="<?php if(!empty($item['icon_img']['alt'])){ echo esc_attr($item['icon_img']['alt']);}else{esc_attr_e('List', 'agenriver-plugin');}?>">
                                        <?php else:?>
                                            <?php \Elementor\Icons_Manager::render_icon( $item['icon'], [ 'aria-hidden' => 'true' ] ); ?>
                                        <?php endif;?>
                                    </div>
                                    <div class="item-text headline-2 pera-content">
                                        <?php if(!empty($item['title'])):?>
                                            <h3>
                                                <?php echo edrio_wp_kses($item['title']);?>
                                            </h3>
                                        <?php endif;?>
                                        <?php if(!empty($item['description'])):?>
                                            <p>
                                                <?php echo edrio_wp_kses($item['description']);?>
                                            </p>
                                        <?php endif;?>
                                    </div>
                                </div>                                    
                                <?php endforeach;?>
                            </div>
                            <?php endif;?>
                        </div>
                        <?php if(!empty($settings['btn_label'])):?>
                            <div class="ed-btn-2 mt-30">
                                <a <?php echo $this->get_render_attribute_string( 'btn_link' ); ?>>
                                <?php echo edrio_wp_kses($settings['btn_label']);?> <i class="fa-solid fa-right-long"></i></a>
                            </div>
                        <?php endif;?>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>