<?php 
    $this->add_render_attribute( 'title', 'class', 'elementor-gt-heading sec_title ed-sec-tt-anim ed-has-anim' );
?>
<section id="ed-why-choose" class="ed-why-choose-sec pt-120 pb-120 position-relative">
<?php if(!empty($settings['about_img']['url'])):?>
    <div class="ed-wc-bg img-parallax position-absolute">
        <img class="ed-img-rvl_1" src="<?php echo esc_url($settings['about_img']['url']);?>" alt="<?php if(!empty($settings['about_img']['alt'])){ echo esc_attr($settings['about_img']['alt']);}else{esc_attr_e('About Image', 'edrio-plugin');}?>">
    </div>
<?php endif;?>
    <div class="container">
        <div class="ed-why-choose-content">
            <div class="ed-why-choose-text">
                <div class="ed-sec-title-2  pt-25 headline-2">
                    <?php if(!empty($settings['subtitle'])):?>
                        <div class="subtitle  wow fadeInRight" data-wow-delay="100ms" data-wow-duration="1000ms">
                            <?php echo edrio_wp_kses($settings['subtitle']);?>
                        </div>
                    <?php endif;?>
                    <?php 
                        printf('<%1$s %2$s>%3$s</%1$s>',
                            tag_escape($settings['title_tag']),
                            $this->get_render_attribute_string('title'),
                            nl2br(edrio_wp_kses($settings['title']))
                        ); 
                    ?>
                </div>
                <div class="ed-wc-img mt-40 mb-25">
                <?php if(!empty($settings['about_img2']['url'])):?>
                    <div class="item-img ed-image-appear3">
                        <img class="ed-img-rvl_3" src="<?php echo esc_url($settings['about_img2']['url']);?>" alt="<?php if(!empty($settings['about_img2']['alt'])){ echo esc_attr($settings['about_img2']['alt']);}else{esc_attr_e('About Image', 'edrio-plugin');}?>">
                    </div>
                <?php endif;?>
                </div>
                <?php if(!empty($settings['description'])):?>
                    <div class="ed-wc-desc ed-text pera-content">
                        <p><?php echo edrio_wp_kses(wpautop($settings['description']));?></p>
                    </div>
                <?php endif;?>
            </div>
            <div class="ed-why-choose-img">
                <div class="ed-wc-img mt-40 mb-40">
                <?php if(!empty($settings['about_img3']['url'])):?>
                    <div class="item-img ed-image-appear1">
                        <img class="ed-img-rvl_1" src="<?php echo esc_url($settings['about_img3']['url']);?>" alt="<?php if(!empty($settings['about_img3']['alt'])){ echo esc_attr($settings['about_img3']['alt']);}else{esc_attr_e('About Image', 'edrio-plugin');}?>">

                    </div>
                <?php endif;?>
                </div>
                <?php if(!empty($settings['counters'])):?>
                    <div class="ed-wc-count-wrap d-flex flex-wrap justify-content-between">
                        <?php foreach($settings['counters'] as $item):?>
                            <div class="ed-wc-count-item headline-2 pera-content">
                                <h3><span class="counter"><?php echo edrio_wp_kses($item['count'])?></span><?php if(!empty($item['prefix'])){ echo esc_attr($item['prefix']);}?></h3>
                                <p><?php echo edrio_wp_kses($item['title'])?></p>
                            </div>
                        <?php endforeach;?>
                    </div>
                <?php endif;?>
                <?php if(!empty($settings['btn_label'])):?>
                    <div class="ed-btn-2 mt-35">
                        <a <?php echo $this->get_render_attribute_string( 'btn_link' ); ?>><?php echo edrio_wp_kses($settings['btn_label']);?> <i class="fa-solid fa-right-long"></i></a>
                    </div>
                <?php endif;?>
            </div>
        </div>
    </div>
</section>