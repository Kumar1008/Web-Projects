<?php 
    $this->add_render_attribute( 'title', 'class', 'elementor-gt-heading sec_title ed-sec-tt-anim ed-has-anim' );

    if ( ! empty( $settings['btn_link']['url'] ) ) {
        $this->add_link_attributes( 'btn_link', $settings['btn_link'] );
    }
?>
<div class="ed-about5-text  position-relative">
    <div class="ed-ab5-title-text d-flex align-items-end justify-content-between">
        <div class="ed-sec-title-5 headline-5 pera-content">
        <?php if(!empty($settings['subtitle'])):?>
            <div class="subtitle wow fadeInRight" data-wow-delay="300ms" data-wow-duration="1500ms">
                <?php echo edrio_wp_kses($settings['subtitle']);?>
            </div>
        <?php endif;?>
        <?php 
            printf('<%1$s %2$s>%3$s</%1$s>',
                tag_escape($settings['title_tag']),
                $this->get_render_attribute_string('title'),
                nl2br(edrio_wp_kses($settings['title']))
            ); 
        ?>
        </div>
        <?php if(!empty($settings['description'])):?>
            <div class="ed-ab5-text-decs pera-content ed-text">
                <?php echo edrio_wp_kses(wpautop($settings['description']) ) ?>
            </div>
        <?php endif;?>
    </div>
    <div class="ed-ab5-client-ft d-flex justify-content-between headline-5">
        <div class="ed-ab5-client mt-50 ul-li">
            <?php if(!empty($settings['authores'])):?>
                <ul>
                    <?php foreach($settings['authores'] as $item):?>
                        <li>
                            <img src="<?php echo esc_url($item['url']);?>" alt="<?php if(!empty($item['alt'])){ echo esc_attr($item['alt']);}else{esc_attr_e('About Image', 'edrio-plugin');}?>">
                        </li>
                    <?php endforeach;?>
                </ul>
            <?php endif;?>
            <?php if(!empty($settings['authore_text'])):?>
                <div class="ed-ab5-cl-text  pera-content d-flex align-items-center">
                    <h3>
                        <?php if(!empty($settings['exp'])):?>
                            <span class="counter"><?php echo esc_html($settings['exp']);?></span>+</h3>
                        <?php endif;?>
                        <p>
                            <?php echo esc_html($settings['authore_text']);?>
                        </p>
                </div>
            <?php endif;?>
            <?php if(!empty($settings['btn_label'])):?>
            <div class="ed-btn-5  mt-45">
                <a <?php echo $this->get_render_attribute_string( 'btn_link' ); ?>>
                    <div class="ed_btn_text d-flex align-items-center">
                        <span class="b-text">
                            <?php echo edrio_wp_kses($settings['btn_label'])?>
                        </span>
                        <span class="b-icon">
                            <svg width="10" height="10" viewBox="0 0 10 10" fill="none" xmlns="http://www.w3.org/2000/svg">
                                <path d="M1.66619 0.833333C1.66619 0.61232 1.75399 0.400358 1.91027 0.244078C2.06655 0.0877975 2.27851 0 2.49953 0H9.16619C9.38721 0 9.59917 0.0877975 9.75545 0.244078C9.91173 0.400358 9.99953 0.61232 9.99953 0.833333V7.5C9.99953 7.72101 9.91173 7.93297 9.75545 8.08926C9.59917 8.24554 9.38721 8.33333 9.16619 8.33333C8.94518 8.33333 8.73322 8.24554 8.57694 8.08926C8.42066 7.93297 8.33286 7.72101 8.33286 7.5V2.845L1.42203 9.75583C1.26486 9.90763 1.05436 9.99163 0.835858 9.98973C0.617361 9.98783 0.40835 9.90019 0.253844 9.74568C0.0993368 9.59118 0.0116958 9.38216 0.00979713 9.16367C0.00789844 8.94517 0.0918941 8.73467 0.243692 8.5775L7.15453 1.66667H2.49953C2.27851 1.66667 2.06655 1.57887 1.91027 1.42259C1.75399 1.26631 1.66619 1.05435 1.66619 0.833333Z" fill="#FF9960"></path>
                            </svg>
                        </span>
                    </div>
                </a>
            </div>
            <?php endif;?>
        </div>
        <div class="ed-ab5-ft-wrap mt-40">
            <?php foreach($settings['features'] as $item):?>
                <div class="ed-ab5-ft-item d-flex">
                    <div class="item-icon d-flex align-items-center justify-content-center">
                        <?php if ($item['type'] === 'image' && ($item['icon_img']['url'])) :?>
                            <img src="<?php echo esc_url($item['icon_img']['url']);?>" alt="<?php if(!empty($item['icon_img']['alt'])){ echo esc_attr($item['icon_img']['alt']);}else{esc_attr_e('List', 'edrio-plugin');}?>">
                        <?php else:?>
                            <?php \Elementor\Icons_Manager::render_icon( $item['icon'], [ 'aria-hidden' => 'true' ] ); ?>
                        <?php endif;?>
                    </div>
                    <div class="item-text headline pera-content">
                        <h3><?php echo edrio_wp_kses($item['title']);?></h3>
                        <?php if(!empty($item['description'])):?>
                            <p><?php echo edrio_wp_kses($item['description']);?></p>
                        <?php endif;?>
                    </div>
                </div>
            <?php endforeach;?>
        </div>
    </div>
    <?php if(!empty($settings['counters'])):?>
    <div class="ed-ab5-counter-wrap mt-90 d-flex justify-content-between flex-wrap">
        <?php foreach($settings['counters'] as $item):?>
            <div class="ed-ab5-count-item headline-5 pera-content align-items-end">
                <h3><span class="counter"><?php echo edrio_wp_kses($item['count'])?></span><?php if(!empty($item['prefix'])){ echo esc_attr($item['prefix']);}?></h3>
                <p><?php echo edrio_wp_kses($item['title'])?></p>
            </div>
        <?php endforeach;?>
    </div>
    <?php endif;?>
</div>