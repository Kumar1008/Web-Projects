<?php 
    $this->add_render_attribute( 'title', 'class', 'elementor-gt-heading sec_title ed-sec-tt-anim ed-has-anim' );

    if ( ! empty( $settings['btn_link']['url'] ) ) {
        $this->add_link_attributes( 'btn_link', $settings['btn_link'] );
    }
?>
<section id="ed-ab6" class="ed-ab6-sec ed-trigger-sec pt-160 pb-65 position-relative">
    <?php if(!empty($settings['about_img']['url'])):?>
        <span class="ed-ab6-shape upper_view position-absolute">
            <img src="<?php echo esc_url($settings['about_img']['url']);?>" alt="<?php if(!empty($settings['about_img']['alt'])){ echo esc_attr($settings['about_img']['alt']);}else{esc_attr_e('About Image', 'edrio-plugin');}?>">
        </span>
    <?php endif;?>
  	<div class="ed-ab6-img-wrap">
        <?php if(!empty($settings['about_img2']['url'])):?>
            <div class="item-img3 ed_img_ani_3">
                <img src="<?php echo esc_url($settings['about_img2']['url']);?>" alt="<?php if(!empty($settings['about_img2']['alt'])){ echo esc_attr($settings['about_img2']['alt']);}else{esc_attr_e('About Image', 'edrio-plugin');}?>">
            </div>
        <?php endif;?>
  		<div class="item-img1 position-relative ed_img_ani">
            <?php if(!empty($settings['about_img3']['url'])):?>
                <img src="<?php echo esc_url($settings['about_img3']['url']);?>" alt="<?php if(!empty($settings['about_img3']['alt'])){ echo esc_attr($settings['about_img3']['alt']);}else{esc_attr_e('About Image', 'edrio-plugin');}?>">
            <?php endif;?>
  			<span>
  				<svg width="761" height="708" viewBox="0 0 761 708" fill="none" xmlns="http://www.w3.org/2000/svg">
  					<g filter="url(#filter0_d_261_358)">
  						<path d="M50.6092 249.63L36.6523 247.513L32 339.392L61.1826 427.461L117.01 509.178L188.064 613.759L202.867 631.119V648.902L211.748 641.704L219.784 648.902C273.92 654.66 295.349 669.367 299.296 676L314.522 671.766L332.285 659.487L341.167 665.838L386.421 651.019L426.6 617.147L444.363 626.885L463.396 606.985L483.274 613.759C485.388 608.255 495.539 596.738 519.223 594.706C542.908 592.674 558.133 604.303 562.786 610.372L576.743 579.464L586.47 586.661H598.735L607.617 559.14L612.269 564.221L624.535 546.438L627.918 550.672L638.914 538.393L654.986 519.34L667.251 492.242L683.746 476.576L695.588 452.018H729L701.932 308.907C697.562 299.875 687.806 278.93 683.746 267.414C679.686 255.897 662.881 229.872 654.986 218.298L618.191 149.707L569.553 83.6555L564.478 65.8725H550.944C539.101 58.2512 514.402 45.6337 510.342 56.1341C506.281 66.6346 496.808 67.0015 492.578 65.8725C471.431 65.0256 461.704 41.7383 458.743 38.3511C456.375 35.6413 444.223 36.0929 438.442 36.6575L433.79 40.8915L414.335 32L413.066 35.3872L402.493 37.9277L405.453 54.8639L389.805 68.4129C381.769 80.2682 375.425 112.447 375.425 117.528C375.425 121.593 370.349 121.762 367.812 121.339L359.353 112.447L330.171 144.626L318.751 135.734L313.676 140.815L304.371 138.275L295.913 149.707H274.766L257.002 156.905L253.619 147.59L246.852 146.743L237.124 162.409H234.164L232.472 169.607L215.978 178.922L212.171 177.652L209.211 181.462L197.791 156.905L190.601 163.256L186.372 162.409L169.032 181.462C168.017 186.204 162.406 191.342 159.727 193.318L147.462 194.164H140.695L136.042 189.083C135.704 181.293 130.826 177.087 128.43 175.958L127.584 168.76L119.971 182.732L110.666 175.535L109.82 177.652L107.706 175.958L101.785 175.535L103.476 172.147L98.824 171.724L93.3258 167.913C92.621 169.748 89.9424 173.163 84.8671 172.147C79.7919 171.13 70.0643 175.11 65.835 177.227H59.4909L53.5698 174.687L50.6092 180.615L53.5698 187.389C52.8649 195.011 51.878 211.015 53.5698 214.064C55.2615 217.112 54.2747 230.012 53.5698 236.081H50.6092L51.4551 238.621L49.7633 241.162L50.6092 249.63Z" fill="black" fill-opacity="0.2" shape-rendering="crispEdges"/>
  					</g>
  					<defs>
  						<filter id="filter0_d_261_358" x="0" y="0" width="761" height="708" filterUnits="userSpaceOnUse" color-interpolation-filters="sRGB">
  							<feFlood flood-opacity="0" result="BackgroundImageFix"/>
  							<feColorMatrix in="SourceAlpha" type="matrix" values="0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 127 0" result="hardAlpha"/>
  							<feOffset/>
  							<feGaussianBlur stdDeviation="16"/>
  							<feComposite in2="hardAlpha" operator="out"/>
  							<feColorMatrix type="matrix" values="0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0.4 0"/>
  							<feBlend mode="normal" in2="BackgroundImageFix" result="effect1_dropShadow_261_358"/>
  							<feBlend mode="normal" in="SourceGraphic" in2="effect1_dropShadow_261_358" result="shape"/>
  						</filter>
  					</defs>
  				</svg>

  			</span>
  		</div>
  		<div class="item-img2 ed_img_ani_2">
            <?php if(!empty($settings['about_img4']['url'])):?>
                <img src="<?php echo esc_url($settings['about_img4']['url']);?>" alt="<?php if(!empty($settings['about_img4']['alt'])){ echo esc_attr($settings['about_img4']['alt']);}else{esc_attr_e('About Image', 'edrio-plugin');}?>">
              <?php endif;?>
  			<span>
  				<svg width="511" height="608" viewBox="0 0 511 608" fill="none" xmlns="http://www.w3.org/2000/svg">
  					<g filter="url(#filter0_d_261_220)">
  						<path d="M46.7228 423.909L32 407.102L34.8628 403.413H42.2242L36.4986 398.493L42.2242 385.785L52.0393 372.257L63.8994 366.927L65.5352 354.219C66.2168 358.182 70.361 364.468 81.4849 357.908C92.6088 351.349 90.7548 339.324 88.4373 334.131L92.118 311.584L95.3898 300.516L100.706 308.305L105.205 311.584H109.295V306.255H112.157L113.793 300.516L115.429 292.727L113.793 280.838V269.36L122.79 266.49L125.653 255.012L136.286 241.893V231.645L142.421 226.725V219.346L152.236 217.296L153.872 181.221H162.46V175.892L148.146 136.947L149.782 121.369L142.421 113.58L144.466 105.791L149.782 97.5916H156.244C156.393 96.9129 156.859 95.0848 157.962 91.0325C159.925 83.8174 168.049 80.6471 171.866 79.9639L189.043 81.6037L200.903 71.355C200.358 70.2618 199.022 67.6654 198.04 66.0257C197.059 64.3859 199.54 58.7832 200.903 56.1869L206.629 48.3979L225.441 39.789L232.802 32H236.074L239.755 37.3293L300.282 46.7581H307.234L314.596 50.4476H319.094H324.002L328.5 54.1372H332.999L340.36 58.2366L344.45 63.566L359.173 68.0754H375.941L381.666 74.2246L424.199 94.722L426.243 99.6414L452.826 120.959L479 142.276V151.295L473.274 157.034L465.095 163.183V169.742V178.761L469.185 184.501L466.731 187.78L470.412 195.159L466.731 204.178V210.327C466.731 211.639 471.093 221.259 473.274 225.905L469.185 233.694L472.048 250.912L474.91 261.161H470.412L472.048 277.558C470.957 277.831 468.367 278.214 466.731 277.558C465.095 276.902 470.412 288.49 473.274 294.366L474.91 299.695L470.412 303.385V306.254L465.095 303.385L461.823 308.714V311.584V318.963L466.731 326.752C467.276 330.715 467.713 339.296 465.095 341.92C462.478 344.544 457.188 342.193 454.871 340.69V343.15L450.372 341.92L448.328 345.199C446.828 346.429 442.52 349.709 437.285 352.988C432.051 356.268 429.924 366.653 429.515 371.436L431.151 385.374L422.563 389.474L417.246 396.853V414.481L408.658 417.35L404.568 420.22L401.705 429.239L399.252 463.264C396.307 462.281 391.209 470.234 389.027 474.333L387.392 486.631L386.165 496.47C382.239 501.062 379.076 499.476 377.985 498.11L374.305 506.719L373.078 523.937H370.215L368.17 530.496H359.173L352.629 533.775L323.593 558.372V561.652L319.503 560.012L318.276 563.292H313.369L309.688 567.391L308.052 576L301.1 563.292L298.646 567.391H292.511L286.377 563.292L266.338 560.012L206.629 548.124H184.135L149.782 539.925L110.93 517.378L95.7987 507.949L91.7091 506.719L54.9021 459.985V453.016L62.6725 446.867L57.7649 439.487V437.028L50.4035 425.139L46.7228 423.909Z" fill="black" fill-opacity="0.2" shape-rendering="crispEdges"/>
  					</g>
  					<defs>
  						<filter id="filter0_d_261_220" x="0" y="0" width="511" height="608" filterUnits="userSpaceOnUse" color-interpolation-filters="sRGB">
  							<feFlood flood-opacity="0" result="BackgroundImageFix"/>
  							<feColorMatrix in="SourceAlpha" type="matrix" values="0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 127 0" result="hardAlpha"/>
  							<feOffset/>
  							<feGaussianBlur stdDeviation="16"/>
  							<feComposite in2="hardAlpha" operator="out"/>
  							<feColorMatrix type="matrix" values="0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0.4 0"/>
  							<feBlend mode="normal" in2="BackgroundImageFix" result="effect1_dropShadow_261_220"/>
  							<feBlend mode="normal" in="SourceGraphic" in2="effect1_dropShadow_261_220" result="shape"/>
  						</filter>
  					</defs>
  				</svg>
  			</span>
  		</div>
  	</div>
  	<div class="container">
  		<div class="ed-ab6-text-wrap d-flex justify-content-end">
  			<div class="ed-ab6-text">
  				<div class="ed-sec-title-6 headline-6 ed-text pera-content">
                    <?php 
                        printf('<%1$s %2$s>%3$s</%1$s>',
                            tag_escape($settings['title_tag']),
                            $this->get_render_attribute_string('title'),
                            nl2br(edrio_wp_kses($settings['title']))
                        ); 
                    ?>
  					<?php if(!empty($settings['description'])):?>
                        <p>
                            <?php echo edrio_wp_kses(wpautop($settings['description']));?>
                        </p>
                    <?php endif;?>
  				</div>
  				<div class="ed-ab6-desc mt-35">
  					<div class="ed-ab6-client d-flex">
  						<div class="ed-ab5-client mt-20 ul-li">
                          <?php if(!empty($settings['authores'])):?>
  							<ul>
                              <?php foreach($settings['authores'] as $item):?>
                                    <li>
                                        <img src="<?php echo esc_url($item['url']);?>" alt="<?php if(!empty($item['alt'])){ echo esc_attr($item['alt']);}else{esc_attr_e('About Image', 'edrio-plugin');}?>">
                                    </li>
                                <?php endforeach;?>
  							</ul>
                            <?php endif;?>
                            <?php if(!empty($settings['authore_text'])):?>
                                <div class="ed-ab5-cl-text headline-6 pera-content d-flex align-items-center">
                                    <h3>
                                        <?php if(!empty($settings['exp'])):?>
                                            <span class="counter"><?php echo esc_html($settings['exp']);?></span>+</h3>
                                        <?php endif;?>
                                    </h3>
                                    <?php if(!empty($settings['authore_text'])):?>
                                        <p><?php echo esc_html($settings['authore_text']);?></p>
                                    <?php endif;?>
                                </div>
                            <?php endif;?>
  						</div>
                          <?php if(!empty($settings['about_img5']['url'])):?>
  						<div class="ed-ab5-cl-img">
  							<div class="item-img">
                                <img src="<?php echo esc_url($settings['about_img5']['url']);?>" alt="<?php if(!empty($settings['about_img5']['alt'])){ echo esc_attr($settings['about_img5']['alt']);}else{esc_attr_e('About Image', 'edrio-plugin');}?>">
  							</div>
  						</div>
                            <?php endif;?>
  					</div>
  					<div class="ed-ab6-ft-wrap mt-40 pt-30 pb-25 d-flex justify-content-between position-relative">
                        <?php foreach($settings['features'] as $item):?>
                            <div class="ed-ab6-ft-item headline-6 pera-content">
                                <div class="icon-title d-flex align-items-center">
                                    <div class="item-icon d-flex align-items-center justify-content-center">
                                        <?php if ($item['type'] === 'image' && ($item['icon_img']['url'])) :?>
                                            <img src="<?php echo esc_url($item['icon_img']['url']);?>" alt="<?php if(!empty($item['icon_img']['alt'])){ echo esc_attr($item['icon_img']['alt']);}else{esc_attr_e('List', 'edrio-plugin');}?>">
                                        <?php else:?>
                                            <?php \Elementor\Icons_Manager::render_icon( $item['icon'], [ 'aria-hidden' => 'true' ] ); ?>
                                        <?php endif;?>
                                    </div>
                                    <h3><?php echo edrio_wp_kses($item['title']);?></h3>
                                </div>
                                <?php if(!empty($item['description'])):?>
                                    <p><?php echo edrio_wp_kses($item['description']);?></p>
                                <?php endif;?>
                            </div>
                        <?php endforeach;?>
  					</div>
                      <?php if(!empty($settings['btn_label'])):?>
                        <div class="ed-btn-6 mt-40   wow fadeInUp" data-wow-delay="100ms" data-wow-duration="1000ms">
                            <a <?php echo $this->get_render_attribute_string( 'btn_link' ); ?>>
                                <span><?php echo edrio_wp_kses($settings['btn_label'])?></span>
                                <svg width="18" height="14" viewBox="0 0 18 14" fill="none" xmlns="http://www.w3.org/2000/svg">
                                    <path opacity="0.4" d="M16.5013 7.83244H1.5013C1.28029 7.83244 1.06833 7.74464 0.912046 7.58836C0.755766 7.43208 0.667969 7.22012 0.667969 6.9991C0.667969 6.77809 0.755766 6.56613 0.912046 6.40985C1.06833 6.25357 1.28029 6.16577 1.5013 6.16577H16.5013C16.7223 6.16577 16.9343 6.25357 17.0906 6.40985C17.2468 6.56613 17.3346 6.77809 17.3346 6.9991C17.3346 7.22012 17.2468 7.43208 17.0906 7.58836C16.9343 7.74464 16.7223 7.83244 16.5013 7.83244Z" fill="white"></path>
                                    <path d="M10.6691 13.6666C10.5043 13.6666 10.3432 13.6177 10.2062 13.5261C10.0692 13.4345 9.96242 13.3044 9.89936 13.1521C9.8363 12.9999 9.8198 12.8324 9.85194 12.6707C9.88408 12.5091 9.96342 12.3606 10.0799 12.2441L15.3241 6.99993L10.0799 1.75577C9.92813 1.5986 9.84413 1.3881 9.84603 1.1696C9.84793 0.951101 9.93557 0.742091 10.0901 0.587584C10.2446 0.433077 10.4536 0.345436 10.6721 0.343537C10.8906 0.341639 11.1011 0.425634 11.2583 0.577433L17.0916 6.41077C17.2478 6.56704 17.3356 6.77896 17.3356 6.99993C17.3356 7.2209 17.2478 7.43283 17.0916 7.5891L11.2583 13.4224C11.102 13.5787 10.8901 13.6666 10.6691 13.6666Z" fill="white"></path>
                                </svg>
                            </a>
                        </div>
                    <?php endif;?>
  				</div>
  			</div>
  		</div>
  	</div>
  </section>  