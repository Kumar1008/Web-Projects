<div class="ed-about5-img position-relative">
    <div class="ed-deco-1 position-absolute">
        <?php \Elementor\Icons_Manager::render_icon( $settings['icon'], [ 'aria-hidden' => 'true' ] ); ?>
    </div>
    <div class="ed-deco-2 position-absolute">
        <?php \Elementor\Icons_Manager::render_icon( $settings['icon2'], [ 'aria-hidden' => 'true' ] ); ?>
    </div>
    <?php if(!empty($settings['img_1']['url'])):?>
        <div class="item-img">
            <img src="<?php echo esc_url($settings['img_1']['url']);?>" alt="<?php if(!empty($settings['img_1']['alt'])){ echo esc_attr($settings['img_1']['alt']);}else{esc_attr_e('About Image', 'edrio-plugin');}?>">
        </div>
    <?php endif;?>
</div>