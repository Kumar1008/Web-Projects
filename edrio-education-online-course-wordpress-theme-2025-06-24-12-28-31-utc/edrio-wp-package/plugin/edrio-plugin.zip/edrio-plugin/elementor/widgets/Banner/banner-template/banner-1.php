<?php 
    $this->add_render_attribute( 'title', 'class', 'elementor-gt-heading sec_title ed-sec-tt-anim ed-has-anim' );

    if ( ! empty( $settings['btn_link']['url'] ) ) {
        $this->add_link_attributes( 'btn_link', $settings['btn_link'] );
    }
?>
<section id="ed-top-rate" class="ed-top-rate-sec position-relative" <?php if(!empty($settings['hero_bg']['url'])):?> data-background="<?php echo esc_url($settings['hero_bg']['url']);?>" <?php endif;?>>
    <?php if(!empty($settings['shape1']['url'])):?>
        <span class="ed-tr-shape1">
            <img src="<?php echo esc_url($settings['shape1']['url']);?>" alt="<?php if(!empty($settings['shape1']['alt'])){ echo esc_attr($settings['shape1']['alt']);}else{esc_attr_e('About Image', 'edrio-plugin');}?>">
        </span>
    <?php endif;?>
    <?php if(!empty($settings['shape2']['url'])):?>
        <span class="ed-tr-shape2">
            <img src="<?php echo esc_url($settings['shape2']['url']);?>" alt="<?php if(!empty($settings['shape2']['alt'])){ echo esc_attr($settings['shape2']['alt']);}else{esc_attr_e('About Image', 'edrio-plugin');}?>">
        </span>
    <?php endif;?>
    <div class="container">
        <div class="ed-top-rate-content position-relative">
            <div class="ed-top-rate-img position-absolute">
            <?php if(!empty($settings['shape3']['url'])):?>
                <div class="item-img1 ed_top_img_2 position-absolute">
                    <img src="<?php echo esc_url($settings['shape3']['url']);?>" alt="<?php if(!empty($settings['shape3']['alt'])){ echo esc_attr($settings['shape3']['alt']);}else{esc_attr_e('About Image', 'edrio-plugin');}?>">
                </div>
            <?php endif;?>
                <?php if(!empty($settings['shape4']['url'])):?>
                <div class="item-img2 ed_top_img">
                    <img src="<?php echo esc_url($settings['shape4']['url']);?>" alt="<?php if(!empty($settings['shape4']['alt'])){ echo esc_attr($settings['shape4']['alt']);}else{esc_attr_e('About Image', 'edrio-plugin');}?>">
                </div>
                <?php endif;?>
            </div>
            <div class="ed-top-rate-text position-relative">
                <div class="ed-top-rate-shape">
                    <?php if(!empty($settings['shape5']['url'])):?>
                        <div class="item-shape1">
                            <img src="<?php echo esc_url($settings['shape5']['url']);?>" alt="<?php if(!empty($settings['shape5']['alt'])){ echo esc_attr($settings['shape5']['alt']);}else{esc_attr_e('About Image', 'edrio-plugin');}?>">
                        </div>
                    <?php endif;?>
                    <?php if(!empty($settings['shape6']['url'])):?>
                        <div class="item-shape2">
                            <img src="<?php echo esc_url($settings['shape6']['url']);?>" alt="<?php if(!empty($settings['shape6']['alt'])){ echo esc_attr($settings['shape6']['alt']);}else{esc_attr_e('About Image', 'edrio-plugin');}?>">
                        </div>
                    <?php endif;?>
                    <?php if(!empty($settings['offer_price']) || !empty($settings['offer_title'])):?>
                    <div class="item-percent">
                        <?php if(!empty($settings['offer_title'])):?>
                            <span>
                                <?php echo edrio_wp_kses($settings['offer_title']);?>
                            </span>
                        <?php endif;?>
                        <?php if(!empty($settings['offer_price'])):?>
                            <h3><?php echo edrio_wp_kses($settings['offer_price']);?></h3>
                        <?php endif;?>
                    </div>
                    <?php endif;?>
                </div>
                <div class="ed-sec-title headline pera-content">
                <?php if(!empty($settings['sub_title'])):?>
                    <div class="subtitle wow fadeInRight" data-wow-delay="100ms" data-wow-duration="1000ms"><?php echo edrio_wp_kses($settings['sub_title']);?></div>
                <?php endif;?>
                    <?php 
                        printf('<%1$s %2$s>%3$s</%1$s>',
                            tag_escape($settings['title_tag']),
                            $this->get_render_attribute_string('title'),
                            nl2br(edrio_wp_kses($settings['title']))
                        ); 
                    ?>
                </div>
                <div class="ed-top-rate-ft d-flex align-items-center flex-wrap">
                    <?php foreach($settings['features'] as $item):?>
                        <div class="top-rate-ft-item d-flex align-items-center">
                            <div class="item-icon d-flex justify-content-center align-items-center">
                                <?php if ($item['type'] === 'image' && ($item['icon_img']['url'])) :?>
                                    <img src="<?php echo esc_url($item['icon_img']['url']);?>" alt="<?php if(!empty($item['icon_img']['alt'])){ echo esc_attr($item['icon_img']['alt']);}else{esc_attr_e('List', 'agenriver-plugin');}?>">
                                <?php else:?>
                                    <?php \Elementor\Icons_Manager::render_icon( $item['icon'], [ 'aria-hidden' => 'true' ] ); ?>
                                <?php endif;?>
                            </div>
                            <div class="item-text headline pera-content">
                            <?php if(!empty($item['title'])):?>
                                <h3><?php echo edrio_wp_kses($item['title']);?></h3>
                            <?php endif;?>
                            <?php if(!empty($item['description'])):?>
                                <span><?php echo edrio_wp_kses($item['description']);?></span>
                            <?php endif;?>
                            </div>
                        </div>
                    <?php endforeach;?>

                </div>
                <?php if(!empty($settings['btn_label'])):?>
                    <div class="ed-btn-1 btn-spin">
                        <a <?php echo $this->get_render_attribute_string( 'btn_link' ); ?>><?php echo edrio_wp_kses($settings['btn_label']);?></a>
                    </div>
                <?php endif;?>
            </div>
        </div>
    </div>
</section>