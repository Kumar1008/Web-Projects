<div class="ed-blog-content-2 mt-40">
    <div class="row justify-content-center">
        <?php
            if ( $query->have_posts() ) {
            $i = 0;
            while ( $query->have_posts() ) {
            $query->the_post();
                $tags = get_the_tags(get_the_ID());
                $categories = get_the_terms( get_the_ID(), 'category' );
                $i++;
        ?>
        <div class="col-lg-6 wow fadeInUp" data-wow-delay="300ms" data-wow-duration="1000ms">
            <div class="ed-blog-item-2 d-flex">
                <?php if(has_post_thumbnail()):?>
                    <div class="item-img">
                        <?php 
                            the_post_thumbnail( 'full' );
                        ?>
                    </div>
                <?php endif;?>
                <div class="item-text headline-2 pera-content">
                    <span class="blog_cate text-uppercase"><a href="#"><?php echo get_the_date();?></a></span>
                    <h3 class="blog_title href-underline"><a href="<?php the_permalink();?>"><?php echo wp_trim_words(get_the_title(), $settings['title_length'], '')  ;?></a></h3>
                    <p><?php echo wp_trim_words(get_the_title(), $settings['excerpt_length'], '')  ;?></p>
                    <?php if(!empty($settings['button_label'])):?>
                        <a class="blog_more" href="<?php the_permalink();?>"><span><?php echo edrio_wp_kses($settings['button_label']);?></span> <i class="fa-solid fa-right-long"></i></a>
                    <?php endif;?>
                </div>
            </div>
        </div>
        <?php } wp_reset_query(); } ?>
        
    </div>
</div>