<div class="ed-blog-content-3">
    <div class="row justify-content-center">
        <?php
            if ( $query->have_posts() ) {
            $i = 0;
            while ( $query->have_posts() ) {
            $query->the_post();
                $tags = get_the_tags(get_the_ID());
                $categories = get_the_terms( get_the_ID(), 'category' );
                $i++;
        ?>
        <div class="col-lg-4 col-md-6">
            <div class="ed-blog-item-3">
                <div class="item-img position-relative">
                    <?php if(has_post_thumbnail()):?>
                        <div class="inner-img">
                            <?php 
                                the_post_thumbnail( 'full' );
                            ?>
                        </div>
                    <?php endif;?>
                    <span><?php echo get_the_date('d/m/Y');?></span>
                </div>
                <div class="item-text headline-3">
                    <h3 class="blog_title href-underline"><a href="<?php the_permalink();?>"><?php echo wp_trim_words(get_the_title(), $settings['title_length'], '')  ;?></a></h3>
                    <div class="inner-bottom d-flex justify-content-between align-items-center">
                        <span><?php the_author();?></span>
                        <?php if(!empty($settings['button_label'])):?>
                            <a href="<?php the_permalink();?>"><?php echo edrio_wp_kses($settings['button_label']);?></a>
                        <?php endif;?>
                    </div>
                </div>
            </div>
        </div>
        <?php } wp_reset_query(); } ?>
    </div>
</div>