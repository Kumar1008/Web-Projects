<div class="ed-blog5-content">
    <div class="row justify-content-center">
        <?php
            if ( $query->have_posts() ) {
            $i = 0;
            while ( $query->have_posts() ) {
            $query->the_post();
                $tags = get_the_tags(get_the_ID());
                $i++;
                $categories = get_the_terms(get_the_ID(), 'category');
                $author_name = get_the_author();
                $author_url = get_author_posts_url(get_the_author_meta('ID'));
        ?>
        <div class="col-lg-4 col-md-6">
            <div class="ed-blog5-item">
                <div class="item-img position-relative">
                    <?php if(has_post_thumbnail()):?>
                        <div class="inner-img">
                            <?php 
                                the_post_thumbnail( 'full' );
                            ?>
                        </div>
                    <?php endif;?>
                    <div class="item-meta">
                        <span class="ed-date"><?php echo get_the_date('d');?></span>
                        <span class="ed-month"><?php echo get_the_date('M Y');?></span>
                    </div>
                    <div class="item-cate">
                        <?php if (!empty($categories) && !is_wp_error($categories)) : ?>
                            <?php foreach ($categories as $category) : ?>
                                <a href="<?php echo esc_url(get_category_link($category->term_id)); ?>">
                                    <?php echo esc_html($category->name); ?>
                                </a>
                            <?php endforeach; ?>
                        <?php endif; ?>

                        <a href="<?php echo esc_url($author_url); ?>">
                            <?php esc_html_e('By', 'edrio-plugin') ?> <?php echo esc_html($author_name); ?>
                        </a>
                    </div>
                </div>
                <div class="item-text headline-5">
                    <h3 class="blog_title href-underline"><a href="<?php the_permalink();?>"><?php echo wp_trim_words(get_the_title(), $settings['title_length'], '')  ;?></a></h3>
                </div>
            </div>
        </div>
        <?php } wp_reset_query(); } ?>

    </div>
</div>