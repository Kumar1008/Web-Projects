<?php

/**
 * Elementor Single Widget
 * @package edrio Tools
 * @since 1.0.0
 */

namespace Elementor;

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly.

class Edrio_Blog_Post extends Widget_Base {



	/**
	 * Get widget name.
	 *
	 * Retrieve Elementor widget name.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget name.
	 */
	public function get_name() {
		return 'edrio-blog-1';
	}

	/**
	 * Get widget title.
	 *
	 * Retrieve Elementor widget title.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget title.
	 */
	public function get_title() {
		return esc_html__( 'Edrio Blog', 'edrio-plugin' );
	}

	/**
	 * Get widget icon.
	 *
	 * Retrieve Elementor widget icon.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget icon.
	 */
	public function get_icon() {
		return 'edrio-custom-icon';
	}

	/**
	 * Get widget categories.
	 *
	 * Retrieve the list of categories the Elementor widget belongs to.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return array Widget categories.
	 */
	public function get_categories() {
		return [ 'edrio_widgets' ];
	}

	
	protected function register_controls() {

        $this->start_controls_section(
			'int_widget_opt',
			[
				'label' => esc_html__( 'Heading Style Select', 'edrio-plugin' ),
				'tab'   => Controls_Manager::TAB_CONTENT,
			]
		);
        $this->add_control(
			'style',
			[
				'label' => esc_html__( 'Style', 'edrio-plugin' ),
				'type' => \Elementor\Controls_Manager::SELECT,
				'default' => '1',
				'options' => [
					'1'  => esc_html__( 'Style 1', 'edrio-plugin' ),
					'2'  => esc_html__( 'Style 2', 'edrio-plugin' ),
					'3'  => esc_html__( 'Style 3', 'edrio-plugin' ),
					'4'  => esc_html__( 'Style 4', 'edrio-plugin' )
				]
			]
		);
        $this->end_controls_section();
		
        $this->start_controls_section(
			'post_sec_h_option',
			[
				'label' => esc_html__( 'Blog Option', 'edrio-plugin' ),
				'tab'   => Controls_Manager::TAB_CONTENT,
			]
		);

		$this->add_control(
			'post_order',
			[
				'label'     => esc_html__( 'Post Order', 'edrio-plugin' ),
				'type'      => Controls_Manager::SELECT,
				'default'   => 'ASC',
				'options'   => [
					'ASC'  => esc_html__( 'Ascending', 'edrio-plugin' ),
					'DESC' => esc_html__( 'Descending', 'edrio-plugin' ),
				],
			]
		);
		
		$this->add_control(
			'post_per_page',
			[
				'label'   => __( 'Posts Per Page', 'edrio-plugin' ),
				'type'    => Controls_Manager::NUMBER,
				'min'     => 1,
				'default' => 5,
			]
		);
        $this->add_control(
			'post_categories',
			[
				'type'        => Controls_Manager::SELECT2,
				'label'       => esc_html__( 'Select Categories', 'edrio-plugin' ),
				'options'     => edrio_blog_category(),
				'label_block' => true,
				'multiple'    => true,
			]
		);
		$this->add_control(
			'title_length',
			[
				'label'     => __( 'Title Length', 'edrio-tools' ),
				'type'      => Controls_Manager::NUMBER,
				'step'      => 1,
				'default'   => 20,
			]
		);
		$this->add_control(
			'excerpt_length',
			[
				'label'     => __( 'Excerpt Length', 'edrio-tools' ),
				'type'      => Controls_Manager::NUMBER,
				'step'      => 1,
				'default'   => 20,
			]
		);
        $this->add_control(
			'button_label', [
				'label' => esc_html__( 'Readmore Button', 'edrio-plugin' ),
				'default' => esc_html__( 'Read more', 'edrio-plugin' ),
				'type' => Controls_Manager::TEXT,
			]
		);
        
		$this->end_controls_section();

        $this->start_controls_section(
			'blog_boxc_style',
			[
				'label' => esc_html__( 'Blog Box Style', 'edrio-plugin' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_control(
			'box_bg_color',
			[
				'label' => esc_html__( 'Box BG Color', 'edrio-plugin' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .agn-blog-1-item' => 'background: {{VALUE}}',
					'{{WRAPPER}} .agn-blog-3-item .content' => 'background: {{VALUE}}',
					'{{WRAPPER}} .agn-blog-1-item' => 'background: {{VALUE}}',
					'{{WRAPPER}} .agn-blog-9-item' => 'background: {{VALUE}}',
					'{{WRAPPER}} .agt-blg-item-6' => 'background: {{VALUE}}'
				],
			]
		);
		$this->add_control(
			'box_date_color',
			[
				'label' => esc_html__( 'Date BG Color', 'edrio-plugin' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .agn-blog-9-item .item-date' => 'background: {{VALUE}}'
				],
			]
		);
		$this->add_control(
			'box_border_color',
			[
				'label' => esc_html__( 'Box Border Color', 'edrio-plugin' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .arv-blog-1-card::after' => 'border-color: {{VALUE}}'
				],
				'condition' => [
					'style' => ['1']
				]
				
			]
		);
		$this->add_responsive_control(
			'box_paddint',
			[
				'label' => esc_html__( 'Box Padding', 'edrio-plugin' ),
				'type' => \Elementor\Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em', 'rem', 'custom' ],
				'selectors' => [
					'{{WRAPPER}} .agn-blog-1-item' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->end_controls_section();
		$this->start_controls_section(
			'blog_btn_style',
			[
				'label' => esc_html__( 'Blog Buton Style', 'edrio-plugin' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_control(
			'post_btn_bg_color',
			[
				'label' => esc_html__( 'Post Button BG Color', 'edrio-plugin' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .agn-blog-1-item .blog-btn::after' => 'background: {{VALUE}}'
				],
			]
		);
		$this->add_control(
			'post_btn_icon_color',
			[
				'label' => esc_html__( 'Post Button Icon Color', 'edrio-plugin' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .agn-blog-1-item .blog-btn i' => 'color: {{VALUE}}'
				],
			]
		);
		$this->end_controls_section();

        $this->start_controls_section(
			'blog_style',
			[
				'label' => esc_html__( 'Blog Style', 'edrio-plugin' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);
        
        $this->add_control(
			'post_title',
			[
				'label' => esc_html__( 'Post Title Style', 'edrio-plugin' ),
				'type' => \Elementor\Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);
        $this->add_control(
			'post_list_title_color',
			[
				'label' => esc_html__( 'Post Title Color', 'edrio-plugin' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .title' => 'color: {{VALUE}}',
					'{{WRAPPER}} .blog_title' => 'color: {{VALUE}}'
				],
			]
		);
        $this->add_control(
			'post_hover_title_color',
			[
				'label' => esc_html__( 'Post Title Hover Color', 'edrio-plugin' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .title:hover' => 'color: {{VALUE}}',
					'{{WRAPPER}} .agn-blog-1-item .blog-title:hover' => 'color: {{VALUE}}'
				],
			]
		);
       
        $this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'post_title_typography',
				'selector' => '
					{{WRAPPER}} .title
				',
			]
		);
        
        $this->add_control(
			'post_date_title',
			[
				'label' => esc_html__( 'Post Date Style', 'edrio-plugin' ),
				'type' => \Elementor\Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);
        
        $this->add_control(
			'post_date_bg_color',
			[
				'label' => esc_html__( 'Post Date BG Color', 'edrio-plugin' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .agn-blog-1-item .item-date' => 'background: {{VALUE}}',
					'{{WRAPPER}} .agn-blog-1-item .blog-date' => 'background: {{VALUE}}'
				],
			]
		);
        $this->add_control(
			'post_date_color',
			[
				'label' => esc_html__( 'Post Date Color', 'edrio-plugin' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .agn-blog-1-item .item-date' => 'color: {{VALUE}}',
					'{{WRAPPER}} .agn-blog-1-item .blog-date' => 'color: {{VALUE}}'
				],
			]
		);
        $this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'post_date_typography',
				'selector' => '
					{{WRAPPER}} .agn-blog-1-item .item-date
				',
			]
		);
		
        $this->add_control(
			'post_cate_title',
			[
				'label' => esc_html__( 'Post Category Style', 'edrio-plugin' ),
				'type' => \Elementor\Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);
        $this->add_control(
			'categor_color',
			[
				'label' => esc_html__( 'Post Category Color', 'edrio-plugin' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .agn-blog-1-item .item-subtitle' => 'color: {{VALUE}}',
					'{{WRAPPER}} .agn-blog-1-item .item-subtitle' => 'border-color: {{VALUE}}',
					'{{WRAPPER}} .arv-blog-1-card .card-content .meta .read-time' => 'color: {{VALUE}}',
					'{{WRAPPER}} .arv-blog-1-card .card-content .meta .author .name' => 'color: {{VALUE}}'
				],
			]
		);
        
        $this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'post_cate_typography',
				'selector' => '
				{{WRAPPER}} .agn-blog-1-item .item-subtitle
				',
			]
		);
		
		$this->end_controls_section();
	}


	protected function render() {
		$settings = $this->get_settings_for_display();	

        $args = array(
			'post_type'           => 'post',
			'posts_per_page'      => !empty( $settings['post_per_page'] ) ? $settings['post_per_page'] : 1,
			'post_status'         => 'publish',
			'ignore_sticky_posts' => 1,
			'order'               => $settings['post_order'],
		);
		if( ! empty($settings['post_categories'] ) ){
			$args['category_name'] = implode(',', $settings['post_categories']);
		}
		
		$query = new \WP_Query( $args );
        require __DIR__ . '/blog-template/blog-' . $settings['style'] . '.php';
    }
    protected function edrio_category_name(){
        $catgorys = get_the_category();
    
        // Shuffle the array of categories
        shuffle($catgorys);
    
        // Select a random category
        $random_category = array_rand($catgorys, 1);
        $category = $catgorys[$random_category];
    
        $meta = get_term_meta($category->term_id, 'barfii_cate_meta', true);
        $catemeta = !empty( $meta['cate-color'] )? $meta['cate-color'] : '#3b60fe';
        ?>
        <a href="<?php echo esc_url(get_category_link($category->term_id)); ?>">
            <span><?php echo esc_html($category->cat_name); ?></span> 
        </a>
    <?php
    }
		
	
}


Plugin::instance()->widgets_manager->register( new Edrio_Blog_Post() );