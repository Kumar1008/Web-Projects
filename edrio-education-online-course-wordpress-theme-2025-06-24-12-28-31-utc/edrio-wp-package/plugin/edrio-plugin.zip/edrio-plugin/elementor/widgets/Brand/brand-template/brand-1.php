<div class="ed-collaborate-content">
    <?php foreach($settings['brands'] as $item):?>
    <div class="ed-coll-item">
        <div class="item-img">
            <img src="<?php echo esc_url($item['url']);?>" alt="<?php if(!empty($item['alt'])){ echo esc_attr($item['alt']);}else{esc_attr_e('List', 'edrio-plugin');}?>">
        </div>
    </div>
    <?php endforeach;?>
</div>