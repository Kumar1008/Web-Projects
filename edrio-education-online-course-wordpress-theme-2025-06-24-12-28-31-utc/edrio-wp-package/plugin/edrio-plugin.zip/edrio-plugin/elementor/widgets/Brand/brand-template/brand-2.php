<div class="ed-client4-sec pt-60 pera-content text-center">
    <?php if(!empty($settings['title'])):?>
        <p>
            <?php echo edrio_wp_kses($settings['title']);?>
        </p>
    <?php endif;?>
    <div class="ed-client-marquee marquee-left">
        <?php foreach($settings['brands'] as $item):?>
            <div class="item-client">
                <div class="inner-img">
                    <img src="<?php echo esc_url($item['url']);?>" alt="<?php if(!empty($item['alt'])){ echo esc_attr($item['alt']);}else{esc_attr_e('List', 'edrio-plugin');}?>">
                </div>
            </div>
        <?php endforeach;?>
    </div>
</div>