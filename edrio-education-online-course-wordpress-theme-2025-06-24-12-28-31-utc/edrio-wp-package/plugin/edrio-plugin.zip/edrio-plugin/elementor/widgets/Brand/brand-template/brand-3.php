<div class="ed-sponsor5-content pera-content">
<?php if(!empty($settings['title'])):?>
    <div class="ed-sponsor5-title d-flex align-items-center text-uppercase"><i class="line_1"></i><p><?php echo edrio_wp_kses($settings['title']);?></p><i class="line_2"></i></div>
<?php endif;?>
    <div class="ed-sponsor5-marquee marquee-left">
        <?php foreach($settings['brands'] as $item):?>
            <div class="ed-sp5-img">
                <div class="item-img">
                    <img src="<?php echo esc_url($item['url']);?>" alt="<?php if(!empty($item['alt'])){ echo esc_attr($item['alt']);}else{esc_attr_e('List', 'edrio-plugin');}?>">
                </div>
            </div>
        <?php endforeach;?>
    </div>
    
    <?php if(!empty($settings['text'])):?>
    <div class="ed-sponsor5-title d-flex align-items-center text-uppercase"><i class="line_2"></i><p><?php echo edrio_wp_kses($settings['text']);?></p><i class="line_1"></i></div>
    <?php endif;?>
</div>