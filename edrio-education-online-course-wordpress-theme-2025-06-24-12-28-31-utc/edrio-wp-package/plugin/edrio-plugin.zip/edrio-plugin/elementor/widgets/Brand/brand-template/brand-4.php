<div class="ed-spn6-content">
    <div class="ed-spn6-top-item left_view d-flex">
    <?php foreach($settings['brands'] as $item):?>
        <div class="ed-spn6-item">
            <div class="item-img">
                <img src="<?php echo esc_url($item['url']);?>" alt="<?php if(!empty($item['alt'])){ echo esc_attr($item['alt']);}else{esc_attr_e('List', 'edrio-plugin');}?>">
            </div>
        </div>
    <?php endforeach;?>
    </div>
    <div class="ed-spn6-bottom-item right_view d-flex justify-content-end">
        <?php foreach($settings['brands2'] as $item):?>
            <div class="ed-spn6-item">
                <div class="item-img">
                    <img src="<?php echo esc_url($item['url']);?>" alt="<?php if(!empty($item['alt'])){ echo esc_attr($item['alt']);}else{esc_attr_e('List', 'edrio-plugin');}?>">
                </div>
            </div>
        <?php endforeach;?>
    </div>
</div>