<?php 
    if ( ! empty( $settings['btn_link']['url'] ) ) {
        $this->add_link_attributes( 'btn_link', $settings['btn_link'] );
    }
?>
<div class="prthalign">
    <div class="ed-btn-3">
        <a <?php echo $this->get_render_attribute_string( 'btn_link' ); ?>><span data-back="<?php echo edrio_wp_kses($settings['btn_label']);?>" data-front="<?php echo edrio_wp_kses($settings['btn_label']);?>"></span> 
            <?php if(!empty($settings['btn_shape']['url'])):?>
                <img src="<?php echo esc_url( $settings['btn_shape']['url'] ); ?>" alt="<?php echo !empty( $settings['btn_shape']['alt'] ) ? esc_attr( $settings['btn_shape']['alt'] ) : ''; ?>">            
            <?php endif;?>
        </a>
    </div>
</div>