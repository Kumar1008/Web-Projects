<div id="ed-cp-form" class="ed-cp-form-sec position-relative">
    <?php if(!empty($settings['shape']['url'])):?>
    <span class="ed-cp-bg position-absolute">
        <img src="<?php echo esc_url($settings['shape']['url']);?>" alt="<?php if(!empty($settings['shape']['alt'])){ echo esc_attr($settings['shape']['alt']);}else{esc_attr_e('About Image', 'edrio-plugin');}?>">
    </span>
    <?php endif;?>
    <div class="container">
        <div class="ed-cp-form-content  pb-155 position-relative d-flex justify-content-end">
            <?php if(!empty($settings['shape2']['url'])):?>
            <span class="cp-img-2">
                <img src="<?php echo esc_url($settings['shape2']['url']);?>" alt="<?php if(!empty($settings['shape2']['alt'])){ echo esc_attr($settings['shape2']['alt']);}else{esc_attr_e('About Image', 'edrio-plugin');}?>">
            </span>
            <?php endif;?>
            <div class="ed-cp-form position-relative">
                <?php if(!empty($settings['shape3']['url'])):?>
                <span class="cp-img-1">
                    <img src="<?php echo esc_url($settings['shape3']['url']);?>" alt="<?php if(!empty($settings['shape3']['alt'])){ echo esc_attr($settings['shape3']['alt']);}else{esc_attr_e('About Image', 'edrio-plugin');}?>">
                </span>
                <?php endif;?>
                <div class="gt-client-review-form cp_ver mt-40">
                    <?php if(!empty($settings['title'])):?>
                        <h3>
                            <?php echo edrio_wp_kses($settings['title']);?>
                        </h3>
                    <?php endif;?>
                    <?php 
                        if(!empty($settings['shortcode'])){
                            echo do_shortcode($settings['shortcode']);
                        }
                    ?>
                </div>
            </div>
        </div>
    </div>
</div>