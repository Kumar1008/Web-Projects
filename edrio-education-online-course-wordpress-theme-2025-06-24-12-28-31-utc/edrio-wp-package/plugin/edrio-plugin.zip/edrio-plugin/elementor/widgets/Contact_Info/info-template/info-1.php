<div class="ed-ft-widget-2  headline-2">
    <div class="cta-info-wrap">
        <?php foreach($settings['infos'] as $item):?>
            <div class="cta-info-item d-flex">
                <div class="item-icon d-flex justify-content-center align-items-center">
                    <?php \Elementor\Icons_Manager::render_icon( $item['icon'], [ 'aria-hidden' => 'true' ] ); ?>
                </div>
                <div class="item-text">
                    <?php echo edrio_wp_kses($item['title']);?>
                </div>
            </div>
        <?php endforeach;?>
    </div>
</div>