<div class="ed-cp-cta-content">
    <div class="row justify-content-center">
        <?php foreach($settings['infos'] as $item):?>
            <div class="col-lg-4 col-md-6">
                <div class="ed-cp-cta-item d-flex">
                    <div class="item-icon d-flex align-items-center justify-content-center">
                        <img src="<?php echo esc_url($item['icon_img']['url']);?>" alt="<?php if(!empty($item['icon_img']['alt'])){ echo esc_attr($item['icon_img']['alt']);}else{esc_attr_e('About Image', 'edrio-plugin');}?>">
                    </div>
                    <div class="item-text headline pera-content">
                        <h3><?php echo edrio_wp_kses($item['title']);?></h3>
                        <?php if(!empty($item['description'])):?>
                            <?php echo edrio_wp_kses( wpautop($item['description']) );?>
                        <?php endif;?>
                    </div>
                </div>
            </div>
        <?php endforeach;?>
    </div>
</div>