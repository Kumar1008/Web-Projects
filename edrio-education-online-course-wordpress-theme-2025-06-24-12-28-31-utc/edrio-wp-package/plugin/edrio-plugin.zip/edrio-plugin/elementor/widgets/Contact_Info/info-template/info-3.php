<div class="ed-ftr-widget">
    <div class="logo-widget">
        <div class="logo-cta-info">
        <?php foreach($settings['infos'] as $item):?>
            <div class="info-item d-flex align-items-center">
                <div class="item-icon d-flex justify-content-center align-items-center">
                    <?php \Elementor\Icons_Manager::render_icon( $item['icon'], [ 'aria-hidden' => 'true' ] ); ?>
                </div>
                <div class="item-text">
                <?php echo edrio_wp_kses($item['title']);?>
                </div>
            </div>
        <?php endforeach;?>
        </div>
    </div>
</div>