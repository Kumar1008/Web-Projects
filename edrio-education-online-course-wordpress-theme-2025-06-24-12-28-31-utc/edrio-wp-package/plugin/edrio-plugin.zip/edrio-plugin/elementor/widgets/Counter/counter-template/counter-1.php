<div class="ed-rv-item-count-wrap d-flex">
    <?php foreach($settings['counters'] as $item):?>
        <div class="ed-rv-item-count rel-item text-center headline pera-content ul-li">
            <?php if(!empty($item['sub_title'])):?>
                <div class="count-star text-center">
                    <?php echo edrio_wp_kses($item['sub_title']) ?>
                </div>
            <?php endif;?>
            <?php if(!empty($item['title'])):?>
                <p><?php echo edrio_wp_kses($item['title']) ?></p>
            <?php endif;?>
            <h3>
                <?php if(!empty($item['prefix'])):?>
                    <?php echo edrio_wp_kses($item['prefix']) ?>
                <?php endif;?>
                <?php if(!empty($item['count'])):?>
                    <span class="counter"><?php echo edrio_wp_kses($item['count']) ?></span>
                <?php endif;?>
            </h3>
        </div>
    <?php endforeach;?>

</div>