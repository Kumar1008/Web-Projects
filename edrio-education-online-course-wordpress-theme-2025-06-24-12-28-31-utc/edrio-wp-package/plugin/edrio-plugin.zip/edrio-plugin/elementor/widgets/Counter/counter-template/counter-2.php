<section id="ed-counter-3" class="ed-counter-section-3 position-relative pt-120 pb-60">
    <?php if(!empty($settings['ct_bg']['url'])):?>
    <div class="ed-count-bg img-parallax position-absolute">
        <img src="<?php echo esc_url($settings['ct_bg']['url']); ?>" alt="">
    </div>
    <?php endif;?>
<div class="container">
    <div class="ed-counter-content-3">
        <div class="row justify-content-center">
            <?php foreach($settings['counters'] as $item):?>
                <div class="col-lg-3 col-md-6">
                    <div class="ed-count-item-3 text-center">
                        <?php if(!empty($item['ct_icon']['url'])):?>
                        <div class="item-img">
                            <img src="<?php echo esc_url($item['ct_icon']['url']);?>" alt="<?php if(!empty($item['ct_icon']['alt'])){ echo esc_attr($item['ct_icon']['alt']);}else{esc_attr_e('About Image', 'edrio-plugin');}?>">
                        </div>
                        <?php endif;?>
                        <div class="item-text headline-3 pera-content">
                            <h3>
                            <?php if(!empty($item['count'])):?>
                                <span class="counter"><?php echo edrio_wp_kses($item['count']) ?></span> 
                            <?php endif;?>
                                <?php if(!empty($item['prefix'])):?>
                    <?php echo edrio_wp_kses($item['prefix']) ?>
                <?php endif;?></h3>
                        <?php if(!empty($item['title'])):?>
                            <p><?php echo edrio_wp_kses($item['title']) ?></p>
                        <?php endif;?>
                        </div>
                    </div>
                </div>
            <?php endforeach;?>
            
        </div>
    </div>
</div>
</section>  