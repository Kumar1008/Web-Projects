<div class="ed-counter4-content d-flex">
    <div class="ed-counter4-wrap d-flex">
        <?php foreach($settings['counters'] as $item):?>
            <div class="ed-item-count-4 headline pera-content text-center">
            <?php if(!empty($item['count'])):?>
                <h3>
                    <span class="counter"><?php echo edrio_wp_kses($item['count']) ?></span><?php if(!empty($item['prefix'])):?>
                    <?php echo edrio_wp_kses($item['prefix']) ?>
                <?php endif;?></h3>
            <?php endif;?>
                <?php if(!empty($item['title'])):?>
                    <p class="text-uppercase"><?php echo edrio_wp_kses($item['title']) ?></p>
                <?php endif;?>
            </div>
        <?php endforeach;?>
        
    </div>
    <div class="ed-counter4-author position-relative">
        <?php if(!empty($settings['r_img']['url'])):?>
            <div class="item-img">
                <img src="<?php echo esc_url($settings['r_img']['url']); ?>" alt="<?php echo esc_attr($settings['r_title']); ?>">
            </div>
        <?php endif;?>
        <div class="item-text ul-li text-center pera-content">
        <?php
        $rating = isset($settings['rating']) ? floatval($settings['rating']) : 0;
        $fullStars = floor($rating);
        $halfStar = ($rating - $fullStars) >= 0.5 ? 1 : 0;
        $emptyStars = 5 - $fullStars - $halfStar;
        ?>

        <div class="item-rate d-flex align-items-center">
            <span><?php echo number_format($rating, 1); ?></span>
            <ul class="d-flex">
                <?php for ($i = 0; $i < $fullStars; $i++): ?>
                    <li><i class="fa-solid fa-star"></i></li>
                <?php endfor; ?>

                <?php if ($halfStar): ?>
                    <li><i class="fa-solid fa-star-half-stroke"></i></li>
                <?php endif; ?>

                <?php for ($i = 0; $i < $emptyStars; $i++): ?>
                    <li><i class="fa-regular fa-star"></i></li>
                <?php endfor; ?>
            </ul>
        </div>
        <?php if(!empty($settings['r_title'])):?>
            <p class="text-uppercase">
                <?php echo edrio_wp_kses($settings['r_title']) ?>
            </p>
        <?php endif;?>
        </div>
    </div>
</div>