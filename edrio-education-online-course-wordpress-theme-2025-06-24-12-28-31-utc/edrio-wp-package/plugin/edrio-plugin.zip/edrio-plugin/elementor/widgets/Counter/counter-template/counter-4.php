<?php 
    $this->add_render_attribute( 'title', 'class', 'elementor-gt-heading sec_title ed-sec-tt-anim ed-has-anim' );

	if ( ! empty( $settings['btn_link']['url'] ) ) {
        $this->add_link_attributes( 'btn_link', $settings['btn_link'] );
    }
?>
<div class="ed-cta6-content txt_item_active pt-130 pb-130 position-relative">
	<div class="ed-cta6-wrap  position-relative">
		<?php if(!empty($settings['ct_bg']['url'])):?>
			<div class="ed-cta6-shape">
				<img src="<?php echo esc_url($settings['ct_bg']['url']);?>" alt="<?php if(!empty($settings['ct_bg']['alt'])){ echo esc_attr($settings['ct_bg']['alt']);}else{esc_attr_e('About Image', 'edrio-plugin');}?>">
			</div>
		<?php endif;?>
		<div class="ed-cta6-text text-center">
			<div class="ed-sec-title-6 ed-text headline-6 text-center pera-content">
					<?php 
						printf('<%1$s %2$s>%3$s</%1$s>',
							tag_escape($settings['title_tag']),
							$this->get_render_attribute_string('title'),
							nl2br(edrio_wp_kses($settings['title']))
						); 
					?>
				<div class="elementor-gt-desc">
					<?php 
						if(!empty($settings['description'])):
							echo edrio_wp_kses(wpautop($settings['description']));
						endif;
					?>
				</div>
			</div>
			<?php if(!empty($settings['btn_label'])):?>
			<div class="ed-btn-6 mt-30">
				<a <?php echo $this->get_render_attribute_string( 'btn_link' ); ?>>
					<span><?php echo edrio_wp_kses($settings['btn_label']);?></span>
					<svg width="18" height="14" viewBox="0 0 18 14" fill="none" xmlns="http://www.w3.org/2000/svg">
						<path opacity="0.4" d="M16.5013 7.83244H1.5013C1.28029 7.83244 1.06833 7.74464 0.912046 7.58836C0.755766 7.43208 0.667969 7.22012 0.667969 6.9991C0.667969 6.77809 0.755766 6.56613 0.912046 6.40985C1.06833 6.25357 1.28029 6.16577 1.5013 6.16577H16.5013C16.7223 6.16577 16.9343 6.25357 17.0906 6.40985C17.2468 6.56613 17.3346 6.77809 17.3346 6.9991C17.3346 7.22012 17.2468 7.43208 17.0906 7.58836C16.9343 7.74464 16.7223 7.83244 16.5013 7.83244Z" fill="white"></path>
						<path d="M10.6691 13.6666C10.5043 13.6666 10.3432 13.6177 10.2062 13.5261C10.0692 13.4345 9.96242 13.3044 9.89936 13.1521C9.8363 12.9999 9.8198 12.8324 9.85194 12.6707C9.88408 12.5091 9.96342 12.3606 10.0799 12.2441L15.3241 6.99993L10.0799 1.75577C9.92813 1.5986 9.84413 1.3881 9.84603 1.1696C9.84793 0.951101 9.93557 0.742091 10.0901 0.587584C10.2446 0.433077 10.4536 0.345436 10.6721 0.343537C10.8906 0.341639 11.1011 0.425634 11.2583 0.577433L17.0916 6.41077C17.2478 6.56704 17.3356 6.77896 17.3356 6.99993C17.3356 7.2209 17.2478 7.43283 17.0916 7.5891L11.2583 13.4224C11.102 13.5787 10.8901 13.6666 10.6691 13.6666Z" fill="white"></path>
					</svg>
				</a>
			</div>
			<?php endif;?>
		</div>
		<div class="ed-cta6-count-wrap">
			<?php $i = 0; foreach($settings['counters'] as $item): $i++;?>
				<div class="ed-cta6-count ver_<?php echo esc_attr($i);?> d-flex align-items-center justify-content-center headline-6 pera-content">
				<div class="item-inner">
					<?php if(!empty($item['count'])):?>
					<h3><span class="counter"><?php echo edrio_wp_kses($item['count']) ?></span><?php echo edrio_wp_kses($item['prefix']) ?></h3>
						<?php endif;?>
						<?php if(!empty($item['title'])):?>
						<p><?php echo edrio_wp_kses($item['title']) ?></p>
						<?php endif;?>
				</div>
			</div>
			<?php endforeach;?>
		</div>
		<?php if(!empty($settings['image']['url'])):?>
			<div class="ed-cta6-img text-center">
				<div class="item-img ">
				<img src="<?php echo esc_url($settings['image']['url']);?>" alt="<?php if(!empty($settings['image']['alt'])){ echo esc_attr($settings['image']['alt']);}else{esc_attr_e('About Image', 'edrio-plugin');}?>">
				</div>
			</div>
		<?php endif;?>
	</div>
</div>