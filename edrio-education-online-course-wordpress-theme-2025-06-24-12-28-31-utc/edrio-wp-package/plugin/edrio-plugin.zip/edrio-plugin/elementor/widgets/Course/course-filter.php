<?php

/**
 * Elementor Single Widget
 * @package edrio Tools
 * @since 1.0.0
 */

namespace Elementor;

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly.

class Edrio_Course_Filter extends Widget_Base {

	/**
	 * Get widget name.
	 *
	 * Retrieve Elementor widget name.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget name.
	 */
	public function get_name() {
		return 'go-course-filter';
	}

	/**
	 * Get widget title.
	 *
	 * Retrieve Elementor widget title.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget title.
	 */
	public function get_title() {
		return esc_html__( 'Course Filter', 'edrio-plugin' );
	}

	/**
	 * Get widget icon.
	 *
	 * Retrieve Elementor widget icon.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget icon.
	 */
	public function get_icon() {
		return 'edrio-custom-icon';
	}

	/**
	 * Get widget categories.
	 *
	 * Retrieve the list of categories the Elementor widget belongs to.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return array Widget categories.
	 */
	public function get_categories() {
		return [ 'edrio_widgets' ];
	}

	protected function register_controls() {

		$this->start_controls_section(
			'filter_style_opt',
			[
				'label' => esc_html__( 'Style Select', 'edrio-plugin' ),
				'tab'   => Controls_Manager::TAB_CONTENT,
			]
		);
        $this->add_control(
			'style',
			[
				'label' => esc_html__( 'Style', 'edrio-plugin' ),
				'type' => \Elementor\Controls_Manager::SELECT,
				'default' => '1',
				'options' => [
					'1'  => esc_html__( 'Style 1', 'edrio-plugin' ),
					'2'  => esc_html__( 'Style 2', 'edrio-plugin' )
				]
			]
		);
		
        $this->end_controls_section();

		$this->start_controls_section(
			'int_heading_opt',
			[
				'label' => esc_html__( 'Heading Option', 'edrio-plugin' ),
				'tab'   => Controls_Manager::TAB_CONTENT,
			]
		);
        $this->add_control(
			'title_shape',
			[
				'label' => esc_html__( 'Title Shape Image', 'edrio-plugin' ),
				'type' => \Elementor\Controls_Manager::MEDIA,
			]
		);
        $this->add_control(
			'subtitle', [
				'label' => esc_html__( 'Sub Title', 'edrio-plugin' ),
				'default' => esc_html__( 'Get To Know Us', 'edrio-plugin' ),
				'type' => Controls_Manager::TEXT,
                'label_block' => true,
			]
		);
        
        $this->add_control(
			'title', [
				'label' => esc_html__( 'Title', 'edrio-plugin' ),
				'default' => esc_html__( 'Section Title', 'edrio-plugin' ),
				'type' => Controls_Manager::TEXTAREA,
                'label_block' => true,
			]
		);
		$this->add_control(
            'title_tag',
            [
                'label'   => __( 'Title HTML Tag', 'edrio-plugin' ),
                'type'    => Controls_Manager::CHOOSE,
                'options' => [
                    'h1' => [
                        'title' => __( 'H1', 'edrio-plugin' ),
                        'icon'  => 'eicon-editor-h1',
                    ],
                    'h2' => [
                        'title' => __( 'H2', 'edrio-plugin' ),
                        'icon'  => 'eicon-editor-h2',
                    ],
                    'h3' => [
                        'title' => __( 'H3', 'edrio-plugin' ),
                        'icon'  => 'eicon-editor-h3',
                    ],
                    'h4' => [
                        'title' => __( 'H4', 'edrio-plugin' ),
                        'icon'  => 'eicon-editor-h4',
                    ],
                    'h5' => [
                        'title' => __( 'H5', 'edrio-plugin' ),
                        'icon'  => 'eicon-editor-h5',
                    ],
                    'h6' => [
                        'title' => __( 'H6', 'edrio-plugin' ),
                        'icon'  => 'eicon-editor-h6',
                    ],
                ],
                'default' => 'h1',
                'toggle'  => false,
            ]
        );
		$this->end_controls_section();

        $this->start_controls_section(
			'--tab-option',
			[
				'label' => esc_html__( 'Course Option', 'edrio-plugin' ),
				'tab'   => Controls_Manager::TAB_CONTENT,
			]
		);
		$this->add_control(
			'course_btn_label', [
				'label' => esc_html__( 'Course Button Label', 'edrio-plugin' ),
				'default' => esc_html__( 'Enroll Now', 'edrio-plugin' ),
				'type' => Controls_Manager::TEXT,
                'label_block' => true,
			]
		);
        
        $repeater = new \Elementor\Repeater();
		
		$repeater->add_control(
			'tab_title', [
				'label' => esc_html__( 'Filter Title', 'edrio-plugin' ),
				'type' => Controls_Manager::TEXT,
                'label_block' => true,
				
			]
		);
        $repeater->add_control(
			'post_order',
			[
				'label'     => esc_html__( 'Post Order', 'edrio-plugin' ),
				'type'      => Controls_Manager::SELECT,
				'default'   => 'ASC',
				'options'   => [
					'ASC'  => esc_html__( 'Ascending', 'edrio-plugin' ),
					'DESC' => esc_html__( 'Descending', 'edrio-plugin' ),
				],
			]
		);
		
		$repeater->add_control(
			'post_per_page',
			[
				'label'   => __( 'Posts Per Page', 'edrio-plugin' ),
				'type'    => Controls_Manager::NUMBER,
				'min'     => 1,
				'default' => 5,
			]
		);
        $repeater->add_control(
			'post_categories',
			[
				'type'        => Controls_Manager::SELECT2,
				'label'       => esc_html__( 'Select Course Categories', 'edrio-plugin' ),
				'options'     => edrio_select_cat('course-category'),
				'label_block' => true,
				'multiple'    => true,
			]
		);
        $repeater->add_control(
			'exclude_categories',
			[
				'type'        => Controls_Manager::SELECT2,
				'label'       => esc_html__( 'Exclude Course Categories', 'edrio-plugin' ),
				'options'     => edrio_select_cat('course-category'),
				'label_block' => true,
				'multiple'    => true,
			]
		);
		$repeater->add_control(
			'title_length',
			[
				'label'     => __( 'Title Length', 'edrio-tools' ),
				'type'      => Controls_Manager::NUMBER,
				'step'      => 1,
				'default'   => 20,
			]
		);
		$repeater->add_control(
			'excerpt_length',
			[
				'label'     => __( 'Excerpt Length', 'edrio-tools' ),
				'type'      => Controls_Manager::NUMBER,
				'step'      => 1,
				'default'   => 20,
			]
		);
        $this->add_control(
			'tabs',
			[
				'label' => esc_html__( 'Add Tab Item', 'edrio-plugin' ),
				'type' => \Elementor\Controls_Manager::REPEATER,
				'fields' => $repeater->get_controls(),
                'title_field' => '{{{ name }}}',
				'condition' => [
					'style' => ['1'],
				],
			]
		);
		$this->add_control(
			'exclude_f_categories',
			[
				'type'        => Controls_Manager::SELECT2,
				'label'       => esc_html__( 'Exclude Filter Course Categories', 'edrio-plugin' ),
				'options'     => edrio_select_cat('course-category'),
				'label_block' => true,
				'multiple'    => true,
				'condition' => [
					'style' => ['2'],
				],
			]
		);
		$this->add_control(
			'post_order',
			[
				'label'     => esc_html__( 'Post Order', 'edrio-plugin' ),
				'type'      => Controls_Manager::SELECT,
				'default'   => 'ASC',
				'options'   => [
					'ASC'  => esc_html__( 'Ascending', 'edrio-plugin' ),
					'DESC' => esc_html__( 'Descending', 'edrio-plugin' ),
				],
				'condition' => [
					'style' => ['2'],
				],
			]
		);
		
		$this->add_control(
			'post_per_page',
			[
				'label'   => __( 'Posts Per Page', 'edrio-plugin' ),
				'type'    => Controls_Manager::NUMBER,
				'min'     => 1,
				'default' => 5,
				'condition' => [
					'style' => ['2'],
				],
			]
		);
        $this->add_control(
			'post_categories',
			[
				'type'        => Controls_Manager::SELECT2,
				'label'       => esc_html__( 'Select Course Categories', 'edrio-plugin' ),
				'options'     => edrio_select_cat('course-category'),
				'label_block' => true,
				'multiple'    => true,
				'condition' => [
					'style' => ['2'],
				],
			]
		);
        $this->add_control(
			'exclude_categories',
			[
				'type'        => Controls_Manager::SELECT2,
				'label'       => esc_html__( 'Exclude Course Categories', 'edrio-plugin' ),
				'options'     => edrio_select_cat('course-category'),
				'label_block' => true,
				'multiple'    => true,
				'condition' => [
					'style' => ['2'],
				],
			]
		);
		
		$this->add_control(
			'btn_label', [
				'label' => esc_html__( 'Button Label', 'edrio-plugin' ),
				'default' => esc_html__( 'edrio Button', 'edrio-plugin' ),
				'type' => Controls_Manager::TEXT,
                'label_block' => true,
			]
		);
        
        $this->add_control(
			'btn_link', [
				'label' => esc_html__( 'Button Link', 'edrio-plugin' ),
				'type' => Controls_Manager::URL,
                'default' => [
					'url' => '',
					'is_external' => true,
					'nofollow' => true,
					// 'custom_attributes' => '',
				],
				'label_block' => true,
			]
		);
		
		$this->end_controls_section();

	}


	protected function render() {
		$settings = $this->get_settings_for_display();
		require __DIR__ . '/course-template/course-filter-' . $settings['style'] . '.php';
    }


}


Plugin::instance()->widgets_manager->register( new Edrio_Course_Filter() );