<div class="ed-cc-cate-feed-top d-flex justify-content-between align-items-center flex-wrap">
    <div class="ed-view-btn-wrap ed-view-btns d-flex flex-wrap align-items-center">
        <div class="ed-view-btn d-flex align-items-center">
            <button class="grid-3 active" href="#"><i class="fa-solid fa-border-all"></i>Grid</button>
            <button class="list-view" href="#"><i class="fa-solid fa-list"></i>List</button>
        </div>
        <?php if (!empty($settings['title'])) : ?>
            <span><?php echo edrio_wp_kses($settings['title']) ?></span>
        <?php endif; ?>
    </div>
</div>

<div class="ed-cc1-feed-area mt-50 ul-li">
    <ul class="products clearfix">
        <?php
        $paged = (get_query_var('paged')) ? get_query_var('paged') : 1;

        $args = array(
            'post_type'           => 'courses',
            'posts_per_page'      => !empty($settings['post_per_page']) ? $settings['post_per_page'] : 1,
            'post_status'         => 'publish',
            'ignore_sticky_posts' => 1,
            'order'               => $settings['post_order'],
            'paged'               => $paged,
        );

        if (!empty($settings['post_categories'][0])) {
            $args['tax_query'] = array(
                array(
                    'taxonomy' => 'course-category',
                    'field'    => 'ids',
                    'terms'    => $settings['post_categories'],
                    'operator' => 'IN',
                )
            );
        }

        if (!empty($settings['exclude_categories'][0])) {
            $args['tax_query'] = array(
                array(
                    'taxonomy' => 'course-category',
                    'field'    => 'ids',
                    'terms'    => $settings['exclude_categories'],
                    'operator' => 'NOT IN',
                )
            );
        }

        $query = new WP_Query($args);

        if ($query->have_posts()) :
            while ($query->have_posts()) : $query->the_post();
                $course_id = get_the_ID();
                $author_id = get_post_field('post_author', $course_id);
                $author_image = get_avatar_url($author_id);
                $author_image_alt = get_the_author_meta('description', $author_id);
                $author_name = get_the_author_meta('display_name', $author_id);
                $categories = get_the_terms($course_id, 'course-category');

                $student = function_exists('tutor') ? tutor_utils()->count_enrolled_users_by_course($course_id) : 0;
                $student_count = sprintf(_n('%s Student', '%s Students', $student, 'edrio-plugin'), $student);

                $total_lessons = function_exists('tutor') ? tutor_utils()->get_lesson_count_by_course($course_id) : 0;
                $total_lessons_text = sprintf(_n('%s Lesson', '%s Lessons', $total_lessons, 'edrio-plugin'), $total_lessons);
        ?>
                <li class="product">
                    <div class="ed-course5-item">
                        <div class="item-img-cate position-relative">
                            <?php if (has_post_thumbnail()) : ?>
                                <div class="inner-img">
                                    <?php echo get_the_post_thumbnail($course_id, array(420, 360)); ?>
                                </div>
                            <?php endif; ?>
                            <div class="inner-cate">
                                <?php
                                $course_categories = get_the_terms($course_id, 'course-category');
                                echo (!empty($course_categories) && !is_wp_error($course_categories)) ? esc_html($course_categories[0]->name) : 'Uncategorized';
                                ?>
                            </div>
                        </div>
                        <div class="item-text headline position-relative">
                            <?php get_template_part('template-parts/tutor-lms/course-rating'); ?>
                            <h3 class="href-underline">
                                <a href="<?php echo esc_url(get_permalink($course_id)); ?>"><?php the_title(); ?></a>
                            </h3>
                            <p><?php echo wp_trim_words(get_the_excerpt(), $settings['excerpt_length'], ''); ?></p>
                            <div class="item-meta d-flex align-items-center justify-content-between">
                                <a href="#"><i class="fa-regular fa-circle-play"></i> <span><b><?php echo esc_html($total_lessons); ?>+</b> Lessons</span></a>
                                <a href="#"><i class="fa-solid fa-users"></i> <span><b><?php echo esc_html($student_count); ?></b></span></a>
                            </div>
                            <div class="item-bottom mt-20 d-flex align-items-center justify-content-between">
                                <div class="item-author d-flex align-items-center">
                                    <?php if (!empty($author_image)) : ?>
                                        <div class="author-img">
                                            <img src="<?php echo esc_url($author_image); ?>" alt="<?php echo esc_attr($author_image_alt); ?>">
                                        </div>
                                    <?php endif; ?>
                                    <?php if (!empty($author_name)) : ?>
                                        <div class="author-text"><?php echo esc_html($author_name); ?></div>
                                    <?php endif; ?>
                                </div>
                                <div class="item-price">
                                    <span><?php get_template_part('template-parts/tutor-lms/price/price'); ?></span>
                                </div>
                            </div>
                            <?php if (!empty($settings['course_btn_label'])) : ?>
                                <div class="crs-btn text-center">
                                    <a href="<?php echo esc_url(get_permalink($course_id)); ?>"><?php echo edrio_wp_kses($settings['course_btn_label']); ?></a>
                                </div>
                            <?php endif; ?>
                        </div>
                    </div>
                </li>
        <?php endwhile; wp_reset_postdata(); endif; ?>
    </ul>
</div>

<?php
// Dynamic Pagination
$total_pages = $query->max_num_pages;

if ($total_pages > 1) {
    echo '<div class="ed-pagination mt-40 text-center ul-li">';
    echo paginate_links(array(
        'current' => $paged,
        'total'   => $total_pages,
        'prev_text' => '<i class="fa-solid fa-angles-left"></i>',
        'next_text' => '<i class="fa-solid fa-angles-right"></i>',
        'type'      => 'list',
    ));
    echo '</div>';
}
?>
