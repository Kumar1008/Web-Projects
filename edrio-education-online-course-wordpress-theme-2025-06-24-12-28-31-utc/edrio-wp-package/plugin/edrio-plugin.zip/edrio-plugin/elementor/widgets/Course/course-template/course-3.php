<div class="ed-fun-content mt-40 position-relative">
    <div class="ed-fun-slider swiper-container">
        <div class="swiper-wrapper">
        <?php

            $args = array(
                'post_type'           => 'courses',
                'posts_per_page'      => !empty( $settings['post_per_page'] ) ? $settings['post_per_page'] : 1,
                'post_status'         => 'publish',
                'ignore_sticky_posts' => 1,
                'order'               => $settings['post_order'],
            );

            if(!empty($settings['post_categories'][0])) {
                $args['tax_query'] = array(
                    array(
                        'taxonomy' => 'course-category',
                        'field'    => 'ids',
                        'terms'    => $settings['post_categories'],
                        'operator' => 'IN',
                    )
                );
            }

            if (!empty($settings['exclude_categories'][0])) {
                $args['tax_query'] = array(
                    'taxonomy' => 'course-category',
                    'field'    => 'ids',
                    'terms'    => $settings['exclude_categories'],
                    'operator' => 'NOT IN',
                );
            }

            $query = new \WP_Query( $args );

            if ( $query->have_posts() ) {
            $i = 0;
            while ( $query->have_posts() ) {
            $query->the_post();
                $tags = get_the_tags(get_the_ID());
                $categories = get_the_terms( get_the_ID(), 'category' );
                $i++;
                $course_id          = get_the_ID();

                //Authore Settings
                $author_id              = get_post_field('post_author', $course_id);
                $author_image           = get_avatar_url($author_id);
                $author_image_alt       = get_the_author_meta('description', $author_id);
                $author_name            = get_the_author_meta('display_name', $author_id);
                $categories             = get_the_terms($course_id, 'course-category');

                //couse student setting
                if( function_exists( 'tutor' ) ) {
                    $student = tutor_utils()->count_enrolled_users_by_course( $course_id );
                } else {
                    $student = null; // Or any default value you'd like to use if the function doesn't exist
                }
                
                $student_count    = sprintf( _n( '%s Student', '%s Students', $student, 'edrio-plugin' ), $student );
                
                //Rating
                $course_rating = '';
                if( function_exists( 'tutor' ) ) {
                    $course_rating = tutor_utils()->get_course_rating( $course_id );
                }

                //lession
                if( function_exists( 'tutor' ) ) {
                    $total_lessons = tutor_utils()->get_lesson_count_by_course( $course_id );  
                }
                
            ?>
            <div class="swiper-slide">
                <div class="ed-fun-item">
                    <?php if (has_post_thumbnail()) : ?>
                        <div class="item-img">
                            <?php echo get_the_post_thumbnail($course_id, array(420, 360)); ?>
                        </div>
                    <?php endif; ?>
                    <div class="item-text headline-3 pera-content">
                        <h3 class="fun_title href-underline">
                            <a href="<?php echo esc_url(get_permalink($course_id)); ?>"><?php the_title(); ?></a>
                        </h3>
                        <p><?php echo wp_trim_words(get_the_excerpt(), $settings['excerpt_length'], ''); ?></p>
                        <div class="item-bottom text-uppercase ul-li">
                            <ul>
                                <li>Age: <span>2-4</span></li>
                                <li>Seats: <span><?php echo esc_html($total_lessons); ?></span></li>
                                <li>
                                    <b>
                                        
                                    <?php 
                                        // Initialize variables
                                    $course_price = '';
                                    $regular_price = '';
                                    $sale_price = '';
                                    $currency_symbol = '$';
                                    $is_free = true;

                                    if(function_exists('tutor')) {
                                        // Tutor LMS handling
                                        if(tutor_utils()->is_course_purchasable($course_id)) {
                                            $is_free = false;
                                            $course_attributes = get_post_meta($course_id);
                                            $course_product_id = isset($course_attributes['_tutor_course_product_id'][0]) ? $course_attributes['_tutor_course_product_id'][0] : null;
                                            
                                            // Get price from tutor functions
                                            $price = tutor_utils()->get_course_price($course_id);
                                            
                                            // Check if WooCommerce is active and product exists
                                            if(class_exists('WooCommerce') && $course_product_id) {
                                                $product = wc_get_product($course_product_id);
                                                if($product && false !== $product) {
                                                    $course_price = $product->get_price();
                                                    $sale_price = $product->get_sale_price();
                                                    $regular_price = !empty($sale_price) ? $product->get_regular_price() : '';
                                                    $currency_symbol = get_woocommerce_currency_symbol();
                                                }
                                            }
                                        }
                                    } elseif(class_exists('LearnPress')) {
                                        // LearnPress handling
                                        $course = LP_Course::get_course($course_id);
                                        if($course) {
                                            $currency_symbol = learn_press_get_currency_symbol();
                                            if(!$course->is_free()) {
                                                $is_free = false;
                                                $course_price = !empty($course->get_sale_price()) ? $course->get_sale_price() : $course->get_price();
                                                $regular_price = $course->get_regular_price();
                                            }
                                        }
                                    }
                                    ?>

                                    <?php if(function_exists('tutor')): ?>
                                        <?php if(!$is_free && tutor_utils()->is_course_purchasable($course_id)): ?>
                                            <?php echo wp_kses_post(tutor_utils()->get_course_price($course_id)); ?>
                                        <?php else: ?>
                                            <?php echo esc_html__('Free', 'edrio'); ?>
                                        <?php endif; ?>
                                    <?php elseif(class_exists('LearnPress')): ?>
                                        <?php if(!$is_free): ?>
                                            <?php echo esc_html($currency_symbol . $course_price); ?>
                                        <?php else: ?>
                                            <?php echo esc_html__('Free', 'edrio'); ?>
                                        <?php endif; ?>
                                    <?php endif; ?>
                                    </b>
                                </li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
            <?php } wp_reset_query(); } ?>
        </div>
    </div>
    <div class="ed-fn-nav d-flex">
        <div class="ed-fn-prev arrow-nav d-flex justify-content-center align-items-center">
            <img src="<?php echo esc_url(get_template_directory_uri())?>/assets/img/arrow-4.png" alt="">
        </div>
        <div class="ed-fn-next arrow-nav d-flex justify-content-center align-items-center">
            <img src="<?php echo esc_url(get_template_directory_uri())?>/assets/img/arrow-5.png" alt="">
        </div>
    </div> 
</div>