<?php 
    $this->add_render_attribute( 'title', 'class', 'elementor-gt-heading sec_title ed-sec-tt-anim ed-has-anim' );

    if ( ! empty( $settings['btn_link']['url'] ) ) {
        $this->add_link_attributes( 'btn_link', $settings['btn_link'] );
    }
?>

<section id="ed-course5" class="ed-course5-sec pt-125 pb-95 position-relative">
  	<div class="ed-cs-shape position-absolute right_view">
  		<svg width="176" height="176" viewBox="0 0 176 176" fill="none" xmlns="http://www.w3.org/2000/svg">
  			<path d="M1.52588e-05 176L7.56558e-06 0L176 -7.6932e-06C176 97.2083 97.2083 176 1.52588e-05 176Z" fill="#B0D1F3"/>
  		</svg>
  	</div>
  	<div class="ed-cs-shape2 position-absolute top_view_2">
  		<svg width="257" height="257" viewBox="0 0 257 257" fill="none" xmlns="http://www.w3.org/2000/svg">
  			<path opacity="0.12" d="M257 128.5C257 199.469 199.469 257 128.5 257C57.5314 257 0 199.469 0 128.5C0 57.5314 57.5314 0 128.5 0C199.469 0 257 57.5314 257 128.5ZM31.6031 128.5C31.6031 182.015 74.9853 225.397 128.5 225.397C182.015 225.397 225.397 182.015 225.397 128.5C225.397 74.9853 182.015 31.6031 128.5 31.6031C74.9853 31.6031 31.6031 74.9853 31.6031 128.5Z" fill="#2F584F"/>
  		</svg>
  	</div>
    <?php if(!empty($settings['shape']['url'])):?>
        <div class="ed-cs-book2 position-absolute rotate_view">
            <img src="<?php echo esc_url($settings['shape']['url']);?>" alt="<?php if(!empty($settings['shape']['alt'])){ echo esc_attr($settings['shape']['alt']);}else{esc_attr_e('About Image', 'edrio-plugin');}?>">
        </div>
    <?php endif;?>
  	<div class="ed-cs-shape3 position-absolute right_view">
  		<svg width="128" height="128" viewBox="0 0 128 128" fill="none" xmlns="http://www.w3.org/2000/svg">
  			<path d="M0 127.797L46.5218 127.797C46.5218 82.9134 82.9134 46.5218 127.797 46.5218L127.797 -2.0845e-05C57.2163 -1.77598e-05 -3.08519e-06 57.2163 0 127.797Z" fill="#E59CF0"/>
  		</svg>
  	</div>
  	<div class="ed-cs-shape4 position-absolute ed_top_img">
  		<svg width="257" height="257" viewBox="0 0 257 257" fill="none" xmlns="http://www.w3.org/2000/svg">
  			<svg width="550" height="550" viewBox="0 0 550 550" fill="none" xmlns="http://www.w3.org/2000/svg">
  				<path opacity="0.12" d="M550 275C550 426.878 426.878 550 275 550C123.122 550 0 426.878 0 275C0 123.122 123.122 0 275 0C426.878 0 550 123.122 550 275ZM67.633 275C67.633 389.526 160.474 482.367 275 482.367C389.526 482.367 482.367 389.526 482.367 275C482.367 160.474 389.526 67.633 275 67.633C160.474 67.633 67.633 160.474 67.633 275Z" fill="#2F584F"/>
  			</svg>
  		</svg>
  	</div>
  	<div class="container">
  		<div class="ed-sec-title-5 headline-5 text-center pera-content">
            <?php if(!empty($settings['subtitle'])):?>
  			    <div class="subtitle wow fadeInRight" data-wow-delay="300ms" data-wow-duration="1500ms">
                    <?php echo edrio_wp_kses($settings['subtitle']);?>
                </div>
            <?php endif;?>
              <?php 
                    printf('<%1$s %2$s>%3$s</%1$s>',
                        tag_escape($settings['title_tag']),
                        $this->get_render_attribute_string('title'),
                        nl2br(edrio_wp_kses($settings['title']))
                    ); 
                ?>
              <div class="elementor-gt-desc">
                    <?php 
                        if(!empty($settings['description'])):
                            echo edrio_wp_kses(wpautop($settings['description']));
                        endif;
                    ?>
                </div>
  		</div>
  		<div class="ed-course5-content mt-55">
  			<div class="row justify-content-center">
                
              <?php

                $args = array(
                    'post_type'           => 'courses',
                    'posts_per_page'      => !empty( $settings['post_per_page'] ) ? $settings['post_per_page'] : 1,
                    'post_status'         => 'publish',
                    'ignore_sticky_posts' => 1,
                    'order'               => $settings['post_order'],
                );

                if(!empty($settings['post_categories'][0])) {
                    $args['tax_query'] = array(
                        array(
                            'taxonomy' => 'course-category',
                            'field'    => 'ids',
                            'terms'    => $settings['post_categories'],
                            'operator' => 'IN',
                        )
                    );
                }

                if (!empty($settings['exclude_categories'][0])) {
                    $args['tax_query'] = array(
                        'taxonomy' => 'course-category',
                        'field'    => 'ids',
                        'terms'    => $settings['exclude_categories'],
                        'operator' => 'NOT IN',
                    );
                }

                $query = new \WP_Query( $args );

                if ( $query->have_posts() ) {
                $i = 0;
                while ( $query->have_posts() ) {
                $query->the_post();
                    $tags = get_the_tags(get_the_ID());
                    $categories = get_the_terms( get_the_ID(), 'category' );
                    $i++;
                    $course_id          = get_the_ID();

                    //Authore Settings
                    $author_id              = get_post_field('post_author', $course_id);
                    $author_image           = get_avatar_url($author_id);
                    $author_image_alt       = get_the_author_meta('description', $author_id);
                    $author_name            = get_the_author_meta('display_name', $author_id);
                    $categories             = get_the_terms($course_id, 'course-category');

                    //couse student setting
                    if( function_exists( 'tutor' ) ) {
                        $student = tutor_utils()->count_enrolled_users_by_course( $course_id );
                    } else {
                        $student = null; // Or any default value you'd like to use if the function doesn't exist
                    }
                    
                    $student_count    = sprintf( _n( '%s Student', '%s Students', $student, 'edrio-plugin' ), $student );
                    
                    //Rating
                    $course_rating = '';
                    if( function_exists( 'tutor' ) ) {
                        $course_rating = tutor_utils()->get_course_rating( $course_id );
                    }

                    //lession
                    if( function_exists( 'tutor' ) ) {
                        $total_lessons = tutor_utils()->get_lesson_count_by_course( $course_id );  
                        $total_lessons  = sprintf( _n( '%s Lesson', '%s Lessons', $total_lessons, 'edrio-plugin' ), $total_lessons );
                    }
                    
            ?>
  				<div class="col-lg-4 col-md-6">
  					<div class="ed-course5-item">
  						<div class="item-img-cate position-relative">
                          <?php if (has_post_thumbnail()) { ?>
  							<div class="inner-img">
                              <?php
                                $attachment_id = get_post_thumbnail_id( $course_id );
                                echo wp_get_attachment_image( $attachment_id, array( '420', '360' ) );
                                ?>
  							</div>
                            <?php } ?>
  							<div class="inner-cate">
                              <?php 
                                // Get course categories
                                $course_categories = get_the_terms($course_id, 'course-category');
                                if (!empty($course_categories) && !is_wp_error($course_categories)) {
                                    // Display the first category name
                                    echo esc_html($course_categories[0]->name);
                                } else {
                                    // Fallback if no categories are found
                                    echo 'Uncategorized';
                                }
                                ?>
  							</div>
  						</div>
  						<div class="item-text headline  position-relative">
                          <?php get_template_part('template-parts/tutor-lms/course-rating'); ?>
  							<h3 class="href-underline"><a href="<?php echo esc_url( get_permalink( $course_id ) ); ?>">
                                        <?php the_title(); ?>
                                    </a></h3>
  							<div class="item-meta d-flex align-items-center justify-content-between">
                              <a href="#"><i class="fa-regular fa-circle-play"></i> <span><?php 
                                // Extract just the number from $total_lessons
                                $lessons_num = intval($total_lessons);
                                echo '<b>' . esc_html($lessons_num) . '+</b> Lessons';
                            ?></span></a>
  								<a href="#"><i class="fa-solid fa-users"></i> <span><b><?php echo esc_html($student_count); ?></b> </span></a>
  							</div>
  							<div class="item-bottom mt-20 d-flex align-items-center justify-content-between">
  								<div class="item-author d-flex align-items-center">
                                  <?php if( isset($author_image) && !empty($author_image)) : ?>
  									<div class="author-img">
                                      <img src="<?php echo esc_url($author_image); ?>" alt="<?php echo $author_image_alt ? esc_attr($author_image_alt): ''; ?>">
  									</div>
                                      <?php endif; ?>
                                    <?php if(!empty($author_name)) : ?>
  									<div class="author-text">
                                      <?php echo esc_html($author_name); ?>
  									</div>
                                    <?php endif; ?>
  								</div>
  								<div class="item-price">
  									<span>
                                      <?php get_template_part('template-parts/tutor-lms/price/price'); ?>
                                      </span>
  								</div>
  							</div>
                              <?php if(!empty($settings['course_btn_label'])):?>
                                <div class="crs-btn text-center">
                                    <a href="<?php _e( get_permalink( $course_id ) ); ?>"><?php echo edrio_wp_kses($settings['course_btn_label']); ?></a>
                                </div>
                            <?php endif; ?>
  						</div>
  					</div>
  				</div>
                  <?php } wp_reset_query(); } ?>
  			</div>
            <?php if(!empty($settings['btn_label'])):?>
                <div class="ed-course5-btn text-center">
                    <div class="ed-btn-5 mt-25">
                        <a <?php echo $this->get_render_attribute_string( 'btn_link' ); ?>>
                            <div class="ed_btn_text  d-flex align-items-center">
                                <span class="b-text"><?php echo edrio_wp_kses($settings['btn_label']);?></span>
                                <span class="b-icon">
                                    <svg width="10" height="10" viewBox="0 0 10 10" fill="none" xmlns="http://www.w3.org/2000/svg">
                                        <path d="M1.66619 0.833333C1.66619 0.61232 1.75399 0.400358 1.91027 0.244078C2.06655 0.0877975 2.27851 0 2.49953 0H9.16619C9.38721 0 9.59917 0.0877975 9.75545 0.244078C9.91173 0.400358 9.99953 0.61232 9.99953 0.833333V7.5C9.99953 7.72101 9.91173 7.93297 9.75545 8.08926C9.59917 8.24554 9.38721 8.33333 9.16619 8.33333C8.94518 8.33333 8.73322 8.24554 8.57694 8.08926C8.42066 7.93297 8.33286 7.72101 8.33286 7.5V2.845L1.42203 9.75583C1.26486 9.90763 1.05436 9.99163 0.835858 9.98973C0.617361 9.98783 0.40835 9.90019 0.253844 9.74568C0.0993368 9.59118 0.0116958 9.38216 0.00979713 9.16367C0.00789844 8.94517 0.0918941 8.73467 0.243692 8.5775L7.15453 1.66667H2.49953C2.27851 1.66667 2.06655 1.57887 1.91027 1.42259C1.75399 1.26631 1.66619 1.05435 1.66619 0.833333Z" fill="#FF9960"></path>
                                    </svg>
                                </span>
                            </div>
                        </a>
                    </div>
                </div>
            <?php endif; ?>
  		</div>
  	</div>
  </section>  