<?php 
    $this->add_render_attribute( 'title', 'class', 'elementor-gt-heading sec_title ed-sec-tt-anim ed-has-anim' );
    if ( ! empty( $settings['btn_link']['url'] ) ) {
        $this->add_link_attributes( 'btn_link', $settings['btn_link'] );
    }
?>

<section id="ed-ft-class" class="ed-ft-class-section position-relative">
		<div class="container">
			<div class="ed-ft-class-top-content d-flex align-items-end justify-content-between">
				<div class="ed-sec-title headline pera-content">
                    <?php if(!empty($settings['subtitle'])):?>
					    <div class="subtitle wow fadeInRight" data-wow-delay="100ms" data-wow-duration="1000ms">
                            <?php echo edrio_wp_kses($settings['subtitle']);?>
                        </div>
                    <?php endif;?>
					<?php 
                        printf('<%1$s %2$s>%3$s</%1$s>',
                            tag_escape($settings['title_tag']),
                            $this->get_render_attribute_string('title'),
                            nl2br(edrio_wp_kses($settings['title']))
                        ); 
                    ?>
				</div>
				<div class="ed-ft-class-top-btn tx-tab-btn ul-li">
					<ul class="nav nav-tabs" id="mt-about-tab" role="tablist">
                        <?php
                            foreach( $settings['tabs'] as $id => $item ) :
                            $active = ($id == 0) ? 'active' : '';
                            $aria_selected = ($id == 0) ? 'true' : 'false';
                        ?>
                            <li class="nav-item" role="presentation">
                                <div class="nav-link <?php echo esc_attr($active); ?>" id="ft_tab_<?php echo esc_attr($id); ?>" data-bs-toggle="tab" data-bs-target="#ft_1_<?php echo esc_attr($id); ?>" role="tab">
                                    <?php echo edrio_wp_kses($item['tab_title'])?>
                                </div>
                            </li>
                        <?php endforeach;?>

					</ul>
				</div>
			</div>
		</div>
		<div class="ed-ft-class-content mt-45 position-relative">
			<div class="custom-cursor"></div>
			<div class="ed-ft-class-tab-desc">
				<div class="tab-content" id="myTabContent">
                <?php
                foreach( $settings['tabs'] as $id => $item ){
                    $active = ($id == 0) ? 'show active' : '';

                $args = array(
                    'post_type'           => 'courses',
                    'posts_per_page'      => !empty( $item['post_per_page'] ) ? $item['post_per_page'] : 1,
                    'post_status'         => 'publish',
                    'ignore_sticky_posts' => 1,
                    'order'               => $item['post_order'],
                );

                if(!empty($item['post_categories'][0])) {
                    $args['tax_query'] = array(
                        array(
                            'taxonomy' => 'course-category',
                            'field'    => 'ids',
                            'terms'    => $item['post_categories'],
                            'operator' => 'IN',
                        )
                    );
                }

                if (!empty($item['exclude_categories'][0])) {
                    $args['tax_query'] = array(
                        'taxonomy' => 'course-category',
                        'field'    => 'ids',
                        'terms'    => $item['exclude_categories'],
                        'operator' => 'NOT IN',
                    );
                }

                $query = new \WP_Query( $args );
                ?>
					<div class="tab-pane <?php echo esc_attr($active); ?> animated fadeInUp" id="ft_1_<?php echo esc_attr($id); ?>" role="tabpanel">
						<div class="ed-ft-class-slider swiper-container">
							<div class="swiper-wrapper">
                                <?php
                                    if ( $query->have_posts() ) {
                                    $i = 0;
                                    while ( $query->have_posts() ) {
                                    $query->the_post();
                                        $tags = get_the_tags(get_the_ID());
                                        $categories = get_the_terms( get_the_ID(), 'category' );
                                        $i++;
                                        $course_id          = get_the_ID();

                                        //Authore Settings
                                        $author_id              = get_post_field('post_author', $course_id);
                                        $author_image           = get_avatar_url($author_id);
                                        $author_image_alt       = get_the_author_meta('description', $author_id);
                                        $author_name            = get_the_author_meta('display_name', $author_id);
                                        $categories             = get_the_terms($course_id, 'course-category');

                                        //couse student setting
                                        if( function_exists( 'tutor' ) ) {
                                            $student = tutor_utils()->count_enrolled_users_by_course( $course_id );
                                        } else {
                                            $student = null; // Or any default value you'd like to use if the function doesn't exist
                                        }
                                        
                                        $student_count    = sprintf( _n( '%s Student', '%s Students', $student, 'edrio-plugin' ), $student );
                                        
                                        //Rating
                                        $course_rating = '';
                                        if( function_exists( 'tutor' ) ) {
                                            $course_rating = tutor_utils()->get_course_rating( $course_id );
                                        }

                                        //lession
                                        if( function_exists( 'tutor' ) ) {
                                            $total_lessons = tutor_utils()->get_lesson_count_by_course( $course_id );  
                                            $total_lessons  = sprintf( _n( '%s Lesson', '%s Lessons', $total_lessons, 'edrio-plugin' ), $total_lessons );
                                        }
                                        
                                ?>
								<div class="swiper-slide">
									<div class="ed-ft-class-item">
										<div class="item-img position-relative">
                                        <?php if (has_post_thumbnail()) { ?>
											<div class="inner-img">
                                            <?php
                                                $attachment_id = get_post_thumbnail_id( $course_id );
                                                echo wp_get_attachment_image( $attachment_id, array( '400', '268' ) );
                                                ?>
											</div>
                                            <?php } ?>
                                            <?php 
                                                    if( function_exists( 'tutor' ) ) {?>
											<span class="item-tag">
                                                <i class="fa-solid fa-layer-group"></i>
                                                <?php  echo esc_html($total_lessons);  ?>
                                            </span>
                                            <?php }?>
                                            <?php get_template_part('template-parts/tutor-lms/price/price'); ?>
										</div>
										<div class="item-text headline pera-content">
											<h3 class="href-underline"><a href="<?php echo esc_url( get_permalink( $course_id ) ); ?>">
                                        <?php the_title(); ?>
                                    </a></h3>
                                            <?php if(!empty($author_name)) : ?>
											    <span class="crs-author">
                                                 <?php esc_html_e('By', 'edrio-plugin');?>   <?php echo esc_html($author_name); ?>
                                                </span>
                                            <?php endif; ?>
											<div class="crs-bottom d-flex justify-content-between align-items-center">
                                                <?php if(!empty($settings['course_btn_label'])):?>
												<div class="bottom-btn btn-spin">
													<a href="<?php _e( get_permalink( $course_id ) ); ?>">
                                                        <?php echo edrio_wp_kses($settings['course_btn_label']); ?>
                                                    </a>
												</div>
                                                <?php endif; ?>
												<span class="num-stu"><i class="fa-solid fa-user"></i> (<?php echo esc_html($student_count);?>)</span>
											</div>
										</div>
									</div>
								</div>
                                <?php } wp_reset_query(); } ?>
							</div>
						</div>
					</div>
                    <?php } ?>
				</div>
			</div>
			<div class="ed-ft-nav d-flex">
				<div class="ed-ft-button-prev arrow-nav d-flex justify-content-center align-items-center"><i class="fa-solid fa-arrow-left"></i></div>
				<div class="ed-ft-button-next arrow-nav d-flex justify-content-center align-items-center"><i class="fa-solid fa-arrow-right"></i></div>
			</div>
		</div>
        <?php if(!empty($settings['btn_label'])):?>
            <div class="ed-btn-1 mt-80 btn-spin text-center">
                <a <?php echo $this->get_render_attribute_string( 'btn_link' ); ?>><?php echo edrio_wp_kses($settings['btn_label']);?></a>
            </div>
        <?php endif; ?>
	</section>	