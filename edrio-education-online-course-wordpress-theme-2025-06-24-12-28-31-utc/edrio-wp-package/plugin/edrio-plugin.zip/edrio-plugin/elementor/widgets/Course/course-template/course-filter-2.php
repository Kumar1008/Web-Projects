<?php 
    $this->add_render_attribute( 'title', 'class', 'elementor-gt-heading sec_title ed-sec-tt-anim ed-has-anim' );
    if ( ! empty( $settings['btn_link']['url'] ) ) {
        $this->add_link_attributes( 'btn_link', $settings['btn_link'] );
    }
?>
<section id="ed-online-course" class="ed-oc-section pt-130 pb-95">
    <div class="container">
        <div class="ed-oc-top-content mb-30 d-flex align-items-end justify-content-between flex-wrap">
            <div class="ed-sec-title-4 headline-4">
                <?php if ( ! empty( $settings['subtitle'] ) ) : ?>
                    <div class="subtitle text-uppercas wow fadeInRight" data-wow-delay="300ms" data-wow-duration="1300ms">
                        <?php echo edrio_wp_kses( $settings['subtitle'] ); ?>
                    </div>
                <?php endif; ?>
                <?php 
                    printf('<%1$s %2$s>%3$s</%1$s>',
                        tag_escape( $settings['title_tag'] ),
                        $this->get_render_attribute_string( 'title' ),
                        nl2br( edrio_wp_kses( $settings['title'] ) )
                    ); 
                ?>
            </div>
            <div class="ed-oc-filter-btn">
                <div class="button-group p-filter-btn clearfix">
                    <button class="filter-button is-checked" data-filter="*"><?php esc_html_e( 'All Categories', 'edrio-plugin' ); ?></button>
                    <?php
                    $excludef_categories = isset( $settings['exclude_f_categories'] ) ? $settings['exclude_f_categories'] : array();
                    
                    $terms = get_terms( array(
                        'taxonomy'   => 'course-category',
                        'hide_empty' => true,
                        'exclude'    => $excludef_categories, // This will exclude categories by their term IDs
                    ) );

                    if ( ! empty( $terms ) && ! is_wp_error( $terms ) ) :
                        foreach ( $terms as $term ) :
                ?>
                    <button class="filter-button" data-filter=".<?php echo esc_attr( $term->slug ); ?>">
                        <?php echo esc_html( $term->name ); ?>
                    </button>
                <?php endforeach; endif; ?>
                </div>
            </div>
        </div>

        <div class="filtr-container-area ed-filter-area grid clearfix" data-isotope='{ "itemSelector": ".grid-item", "layoutMode": "masonry" }'>
            <div class="grid-sizer"></div>
            <?php
                $args = array(
                    'post_type'           => 'courses',
                    'posts_per_page'      => ! empty( $settings['post_per_page'] ) ? $settings['post_per_page'] : 6,
                    'post_status'         => 'publish',
                    'ignore_sticky_posts' => true,
                    'order'               => $settings['post_order'],
                );

                if ( ! empty( $settings['post_categories'][0] ) ) {
                    $args['tax_query'][] = array(
                        'taxonomy' => 'course-category',
                        'field'    => 'ids',
                        'terms'    => $settings['post_categories'],
                        'operator' => 'IN',
                    );
                }

                if ( ! empty( $settings['exclude_categories'][0] ) ) {
                    $args['tax_query'][] = array(
                        'taxonomy' => 'course-category',
                        'field'    => 'ids',
                        'terms'    => $settings['exclude_categories'],
                        'operator' => 'NOT IN',
                    );
                }

                $query = new \WP_Query( $args );

                if ( $query->have_posts() ) :
                    while ( $query->have_posts() ) :
                        $query->the_post();
                        $course_id = get_the_ID();
                        $categories = get_the_terms( $course_id, 'course-category' );

                        $cat_classes = '';
                        if ( ! empty( $categories ) && ! is_wp_error( $categories ) ) {
                            foreach ( $categories as $cat ) {
                                $cat_classes .= ' ' . sanitize_html_class( $cat->slug );
                            }
                        }

                        $author_id        = get_post_field( 'post_author', $course_id );
                        $author_name      = get_the_author_meta( 'display_name', $author_id );
                        $author_image     = get_avatar_url( $author_id );
                        $author_desc      = get_the_author_meta( 'description', $author_id );

                        $student = function_exists( 'tutor_utils' ) ? tutor_utils()->count_enrolled_users_by_course( $course_id ) : 0;
                        $student_count = sprintf( _n( '%s Student', '%s Students', $student, 'edrio-plugin' ), $student );

                        $course_rating = tutor_utils()->get_course_rating( $course_id );

                        $total_lessons = function_exists( 'tutor_utils' ) ? tutor_utils()->get_lesson_count_by_course( $course_id ) : 0;
                        $lesson_label = sprintf( _n( '%s Lesson', '%s Lessons', $total_lessons, 'edrio-plugin' ), $total_lessons );

                        $duration = get_post_meta( get_the_ID(), '_tutor_course_duration', true );
                            

            ?>
            <div class="grid-item grid-size-25<?php echo esc_attr( $cat_classes ); ?>" data-category="<?php echo esc_attr( trim( $cat_classes ) ); ?>">
                <div class="ed-oc-item">
                    <div class="item-img position-relative">
                    <?php if (has_post_thumbnail()) { ?>
                        <div class="inner-img">
                        <?php
                            $attachment_id = get_post_thumbnail_id( $course_id );
                            echo wp_get_attachment_image( $attachment_id, array( '400', '268' ) );
                            ?>
                        </div>
                        <?php } ?>
                        <span><?php get_template_part('template-parts/tutor-lms/price/price'); ?></span>
                    </div>
                    <div class="item-text headline-4">
                        <span><?php 
                                // Get course categories
                                $course_categories = get_the_terms($course_id, 'course-category');
                                if (!empty($course_categories) && !is_wp_error($course_categories)) {
                                    // Display the first category name
                                    echo esc_html($course_categories[0]->name);
                                } else {
                                    // Fallback if no categories are found
                                    echo 'Uncategorized';
                                }
                                ?></span>
                        <h3 class="course_title href-underline"><a href="<?php echo esc_url( get_permalink( $course_id ) ); ?>">
                                        <?php the_title(); ?>
                                    </a></h3>
                        <div class="cb-bottom ul-li">
                            <ul>
                                <li><i class="fa-solid fa-user"></i> <?php echo esc_html($student_count);?></li>
                                <li><i class="fa-solid fa-star"></i> 
                                <?php
                                    $course_rating = tutor_utils()->get_course_rating( get_the_ID() );
                                    echo esc_html( number_format( $course_rating->rating_avg, 1 ) );
                                ?>
                                </li>
                                <?php if(!empty($duration)):?>
                                <li><i class="fa-solid fa-clock"></i>  <?php echo esc_html( $duration );?></li>
                                <?php endif;?>
                            </ul>
                        </div>
                        <div class="oc-author d-flex justify-content-between">
                        <?php if(!empty($author_name)) : ?>
                            <a href="#"><?php esc_html_e('By', 'edrio-plugin');?>   <?php echo esc_html($author_name); ?></a>
                            <?php endif;?>
                            <a href="<?php _e( get_permalink( $course_id ) ); ?>">
                                <?php echo edrio_wp_kses($settings['course_btn_label']); ?>
                            </a>
                        </div>
                    </div>
                </div>
            </div>
            <?php endwhile; wp_reset_postdata(); endif; ?>
        </div>
    </div>
</section>
