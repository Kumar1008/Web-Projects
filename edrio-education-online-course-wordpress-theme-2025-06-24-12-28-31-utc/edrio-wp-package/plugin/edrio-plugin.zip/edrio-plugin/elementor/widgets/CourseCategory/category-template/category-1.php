<div class="ed-course-cate-content">
    <div class="row justify-content-center">
        <?php
        foreach ( $settings['edrios_categorys'] as $cate ):
            $course_terms = get_term_by( 'slug', $cate['cate_id'], 'course-category' );
            if ( $course_terms ):
        ?>
        <div class="col-lg-3 col-md-6 wow fadeInUp" <?php if(!empty($cate['anim'])):?> data-wow-delay="<?php echo esc_attr($cate['anim']);?>" data-wow-duration="1000ms" <?php endif;?>>
            <div class="ed-coc-item text-center">
                <?php if ( !empty( $cate['cate_img']['url'] ) ): ?>
                    <div class="item-img">
                        <img src="<?php echo esc_url( $cate['cate_img']['url'] ); ?>" alt="<?php echo !empty( $cate['cate_img']['alt'] ) ? esc_attr( $cate['cate_img']['alt'] ) : ''; ?>">
                    </div>
                <?php endif; ?>

                <div class="item-text headline pera-content">
                    <h3><a href="<?php echo esc_url( get_term_link( $course_terms->term_id ) ); ?>"><?php echo esc_html( $course_terms->name ); ?></a></h3>
                    <?php if(!empty($cate['tag'])):?>
                        <p><?php echo edrio_wp_kses($cate['tag']);?></p>
                    <?php endif;?>
                </div>
            </div>
        </div>
        <?php
            endif;
        endforeach;
        ?>
    </div>
</div>