<div class="ed-course-content-2">
    <div class="ed-course-slider-2 swiper-container">
        <div class="swiper-wrapper">
            <?php
            foreach ( $settings['edrios_categorys'] as $cate ):
                $course_terms = get_term_by( 'slug', $cate['cate_id'], 'course-category' );
                if ( $course_terms ):
            ?>
            <div class="swiper-slide">
                <div class="ed-course-item-2">
                <?php if ( !empty( $cate['cate_img']['url'] ) ): ?>
                    <div class="item-icon">
                        <img src="<?php echo esc_url( $cate['cate_img']['url'] ); ?>" alt="<?php echo !empty( $cate['cate_img']['alt'] ) ? esc_attr( $cate['cate_img']['alt'] ) : ''; ?>">
                    </div>
                <?php endif; ?>
                    <div class="item-text headline-2">
                        <h3 class="href-underline"><a href="<?php echo esc_url( get_term_link( $course_terms->term_id ) ); ?>"><?php echo esc_html( $course_terms->name ); ?></a></h3>
                    </div>
                </div>
            </div>
            <?php
                endif;
            endforeach;
            ?>        
        </div>
    </div>
    <div class="ed-course-pagi text-center"></div>
    <?php if(!empty($settings['description'])):?>
    <div class="ed-course-bottom pera-content mt-30 text-center">
        <p>
            <?php echo edrio_wp_kses( wpautop($settings['description']) );?>
        </p>
    </div>
    <?php endif;?>
</div>