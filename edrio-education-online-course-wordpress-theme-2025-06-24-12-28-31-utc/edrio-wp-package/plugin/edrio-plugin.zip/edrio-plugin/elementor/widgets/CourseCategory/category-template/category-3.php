<div class="ed-category-sec-3">
    <div class="ed-category-content-3 d-flex justify-content-center">
        <?php
        foreach ( $settings['edrios_categorys'] as $cate ):
            $course_terms = get_term_by( 'slug', $cate['cate_id'], 'course-category' );
            if ( $course_terms ):
        ?>
        <div class="ed-category-item-3 text-center">
        <?php if ( !empty( $cate['cate_img']['url'] ) ): ?>
            <div class="item-icon d-flex justify-content-center align-items-center">
                <img src="<?php echo esc_url( $cate['cate_img']['url'] ); ?>" alt="<?php echo !empty( $cate['cate_img']['alt'] ) ? esc_attr( $cate['cate_img']['alt'] ) : ''; ?>">
            </div>
        <?php endif; ?>
            <div class="item-text">
                <h3 class="href-underline"><a href="<?php echo esc_url( get_term_link( $course_terms->term_id ) ); ?>"><?php echo esc_html( $course_terms->name ); ?></a></h3>
            </div>
        </div>
        <?php
            endif;
        endforeach;
        ?> 
    </div>
</div>