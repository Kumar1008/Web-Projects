<div class="ed-course-cate-content-4 marquee-left">
    <?php
        foreach ( $settings['edrios_categorys'] as $cate ):
        $course_terms = get_term_by( 'slug', $cate['cate_id'], 'course-category' );
        if ( $course_terms ):
    ?>
    <div class="ed-cc-item-4">
        <div class="item-inner-wrap  d-flex justify-content-center align-items-center">
            <div class="item-inner">
                <?php if(!empty($cate['cate_img']['url'])):?>
                    <div class="item-img">
                        <img src="<?php echo esc_url( $cate['cate_img']['url'] ); ?>" alt="<?php echo !empty( $cate['cate_img']['alt'] ) ? esc_attr( $cate['cate_img']['alt'] ) : ''; ?>">
                    </div>
                <?php endif; ?>
                <div class="item-text headline-4">
                    <h3 class="href-underline"><a href="<?php echo esc_url( get_term_link( $course_terms->term_id ) ); ?>"><?php echo esc_html( $course_terms->name ); ?></a></h3>
                </div>
            </div>
        </div>
    </div>
    <?php
        endif;
    endforeach;
    ?> 
</div>