<?php 
    $this->add_render_attribute( 'title', 'class', 'elementor-gt-heading sec_title ed-sec-tt-anim ed-has-anim' );

    if ( ! empty( $settings['btn_link']['url'] ) ) {
        $this->add_link_attributes( 'btn_link', $settings['btn_link'] );
    }
?>
<section id="ed-category5" class="ed-category5-sec position-relative">
    <?php if(!empty($settings['shape1']['url'])):?>
  	    <span class="ed-cate-shape1 right_view position-absolute">
          <img src="<?php echo esc_url($settings['shape1']['url']);?>" alt="<?php if(!empty($settings['shape1']['alt'])){ echo esc_attr($settings['shape1']['alt']);}?>">   
        </span>
    <?php endif;?>
    <?php if(!empty($settings['shape2']['url'])):?>
        <span class="ed-cate-shape2 top_view position-absolute">
        <img src="<?php echo esc_url($settings['shape2']['url']);?>" alt="<?php if(!empty($settings['shape2']['alt'])){ echo esc_attr($settings['shape2']['alt']);}?>"> 
        </span>
    <?php endif;?>
  	<div class="container">
  		<div class="ed-category5-content">
  			<div class="ed-category5-text">
  				<div class="ed-sec-title-5 ed-text headline-5 pera-content">
                    <?php if(!empty($settings['subtitle'])):?>
  					    <div class="subtitle wow fadeInRight" data-wow-delay="300ms" data-wow-duration="1500ms"><?php echo edrio_wp_kses($settings['subtitle']);?></div>
                    <?php endif;?>
  					<?php 
                        printf('<%1$s %2$s>%3$s</%1$s>',
                            tag_escape($settings['title_tag']),
                            $this->get_render_attribute_string('title'),
                            nl2br(edrio_wp_kses($settings['title']))
                        ); 
                    ?>
  					<div class="elementor-gt-desc">
                        <?php 
                            if(!empty($settings['descriptions'])):
                                echo edrio_wp_kses(wpautop($settings['descriptions']));
                            endif;
                        ?>
                    </div>
  				</div>
                <?php if(!empty($settings['btn_label'])):?>
  				<div class="ed-btn-5 ver_2 mt-30">
  					<a <?php echo $this->get_render_attribute_string( 'btn_link' ); ?>>
  						<div class="ed_btn_text d-flex align-items-center">
  							<span class="b-text"><?php echo edrio_wp_kses($settings['btn_label']);?></span>
  							<span class="b-icon">
  								<svg width="10" height="10" viewBox="0 0 10 10" fill="none" xmlns="http://www.w3.org/2000/svg">
  									<path d="M1.66619 0.833333C1.66619 0.61232 1.75399 0.400358 1.91027 0.244078C2.06655 0.0877975 2.27851 0 2.49953 0H9.16619C9.38721 0 9.59917 0.0877975 9.75545 0.244078C9.91173 0.400358 9.99953 0.61232 9.99953 0.833333V7.5C9.99953 7.72101 9.91173 7.93297 9.75545 8.08926C9.59917 8.24554 9.38721 8.33333 9.16619 8.33333C8.94518 8.33333 8.73322 8.24554 8.57694 8.08926C8.42066 7.93297 8.33286 7.72101 8.33286 7.5V2.845L1.42203 9.75583C1.26486 9.90763 1.05436 9.99163 0.835858 9.98973C0.617361 9.98783 0.40835 9.90019 0.253844 9.74568C0.0993368 9.59118 0.0116958 9.38216 0.00979713 9.16367C0.00789844 8.94517 0.0918941 8.73467 0.243692 8.5775L7.15453 1.66667H2.49953C2.27851 1.66667 2.06655 1.57887 1.91027 1.42259C1.75399 1.26631 1.66619 1.05435 1.66619 0.833333Z" fill="#FF9960"></path>
  								</svg>
  							</span>
  						</div>
  					</a>
  				</div>
                <?php endif;?>
  			</div>
  			<div class="ed-category5-card-wrap position-relative">
  				<div class="ed-category5-card-slide swiper-container">
  					<div class="swiper-wrapper">
                      <?php
                            foreach ( $settings['edrios_categorys'] as $cate ):
                            $course_terms = get_term_by( 'slug', $cate['cate_id'], 'course-category' );
                            if ( $course_terms ):
                        ?>
  						<div class="swiper-slide">
  							<div class="ed-category5-card">
  								<div class="item-text headline-5">
  									<div class="title-icon d-flex justify-content-between align-items-center">
  										<h3 class="href-underline"><a href="<?php echo esc_url( get_term_link( $course_terms->term_id ) ); ?>"><?php echo esc_html( $course_terms->name ); ?></a></h3>
  										<div class="arrow-icon">
  											<a href="<?php echo esc_url( get_term_link( $course_terms->term_id ) ); ?>">
  												<svg width="40" height="40" viewBox="0 0 40 40" fill="none" xmlns="http://www.w3.org/2000/svg">
  													<g opacity="0.24" clip-path="url(#clip0_137_450)">
  														<path d="M0 35.7656L29.7782 5.98781H10.3345V0H40V29.6655H34.0122V10.2219L4.23438 40L0 35.7656Z" fill="#2F584F"/>
  													</g>
  													<defs>
  														<clipPath id="clip0_137_450">
  															<rect width="40" height="40" fill="white"/>
  														</clipPath>
  													</defs>
  												</svg>
  											</a>
  										</div>
  									</div>
  									<span><b><?php echo esc_html( $course_terms->count ); ?></b> Course</span>
  								</div>
  								<div class="item-icon d-flex justify-content-end align-items-end <?php if(!empty($cate['custom_class'])){ echo esc_attr($cate['custom_class']);} ?>">
  									<div class="ct_icon_1">
                                      <?php \Elementor\Icons_Manager::render_icon( $cate['icon'], [ 'aria-hidden' => 'true' ] ); ?>
  									</div>
  									<div class="ct_icon_2">
                                      <?php \Elementor\Icons_Manager::render_icon( $cate['icon2'], [ 'aria-hidden' => 'true' ] ); ?>
  									</div>
  								</div>
  							</div>
  						</div>
                          <?php
                            endif;
                        endforeach;
                        ?>                  
  					</div>
  				</div>
  				<div class="ed-ct-nav">
  					<div class="ed-ct-next arrow-nav d-flex justify-content-center align-items-center"><i class="fa-solid fa-arrow-right"></i></div>
  					<div class="ed-ct-prev arrow-nav d-flex justify-content-center align-items-center"><i class="fa-solid fa-arrow-left"></i></div>
  				</div>
  			</div>
  		</div>
  	</div>
  </section>