<?php 
    $this->add_render_attribute( 'title', 'class', 'elementor-gt-heading sec_title ed-sec-tt-anim ed-has-anim' );

    if ( ! empty( $settings['btn_link']['url'] ) ) {
        $this->add_link_attributes( 'btn_link', $settings['btn_link'] );
    }
?>
<section id="ed-course6" class="ed-course6-sec position-relative">
  	<div class="ed-crs6-shape-bg">
  		<svg width="1948" height="393" viewBox="0 0 1948 393" fill="none" xmlns="http://www.w3.org/2000/svg">
  			<g filter="url(#filter0_f_261_377)">
  				<path fill-rule="evenodd" clip-rule="evenodd" d="M14 26V379H1934V239L1879.5 262.501C1871 256.334 1849.3 243.501 1830.5 241.501C1827.06 241.135 1823.39 240.887 1819.52 240.625L1819.52 240.625C1796.94 239.097 1767.36 237.095 1734.5 208.501C1703.7 181.701 1691.67 171.001 1689.5 169.001C1681.83 168.668 1666.1 170.701 1664.5 181.501C1662.9 192.301 1639.5 195.334 1628 195.501L1606.5 169.001H1575.5L1431.5 195.501L1413.5 169.001H1360.5L1321 134.001H1285L1211 51.5009C1181 48.0009 1111.7 43.301 1074.5 52.5009C1064.35 55.0109 1052.34 58.0924 1039.47 61.3973L1039.46 61.3979C993.344 73.235 936.061 87.9366 913 89.5C889.4 91.1 862.167 93.8333 851.5 95L797 107.5C775.5 101.667 728.1 91.5 710.5 97.5C692.9 103.5 680.167 106.667 676 107.5L484 37.5L466.5 64L394.5 48.5C392 43.8333 384 36.2 372 43C357 51.5 304 68.5 237 64C224 62.1667 195.3 54.7 184.5 39.5C184.833 32.5 182.7 18.5 171.5 18.5C160.3 18.5 141.5 17.5 133.5 17L130 14L101 31.5C79.3334 32.1667 34.1 33.1 26.5 31.5C18.9 29.9 15 27.1667 14 26Z" fill="#050505" fill-opacity="0.2"/>
  			</g>
  			<defs>
  				<filter id="filter0_f_261_377" x="0" y="0" width="1948" height="393" filterUnits="userSpaceOnUse" color-interpolation-filters="sRGB">
  					<feFlood flood-opacity="0" result="BackgroundImageFix"/>
  					<feBlend mode="normal" in="SourceGraphic" in2="BackgroundImageFix" result="shape"/>
  					<feGaussianBlur stdDeviation="7" result="effect1_foregroundBlur_261_377"/>
  				</filter>
  			</defs>
  		</svg>
  	</div>
  	<div class="ed-course6-wrap">
  		<div class="container">
  			<div class="ed-sec-title-6 text-center headline-6 pera-content">
                  <?php 
                    printf('<%1$s %2$s>%3$s</%1$s>',
                        tag_escape($settings['title_tag']),
                        $this->get_render_attribute_string('title'),
                        nl2br(edrio_wp_kses($settings['title']))
                    ); 
                ?>
  			</div>
  			<div class="ed-course6-content mt-60 pb-80 d-flex justify-content-center">
              <?php
                    foreach ( $settings['edrios_categorys'] as $cate ):
                    $course_terms = get_term_by( 'slug', $cate['cate_id'], 'course-category' );
                    if ( $course_terms ):
                ?>
  				<div class="ed-course6-item ed-pg6">
  					<div class="inner-item">
  						<div class="item-icon-title d-flex align-items-center">
                            <?php if(!empty($cate['cate_icon_img']['url'])):?>
                                <div class="item-icon d-flex align-items-center justify-content-center">
                                    <img src="<?php echo esc_url( $cate['cate_icon_img']['url'] ); ?>" alt="<?php echo !empty( $cate['cate_icon_img']['alt'] ) ? esc_attr( $cate['cate_icon_img']['alt'] ) : ''; ?>">
                                </div>
                            <?php endif; ?>
  							<div class="item-title headline-6">
  								<h3 class="crs_title href-underline"><a href="<?php echo esc_url( get_term_link( $course_terms->term_id ) ); ?>"><?php echo esc_html( $course_terms->name ); ?></a></h3>
  							</div>
  						</div>
                          <?php if(!empty($cate['cate_img']['url'])):?>
                            <div class="item-img">
                                <img src="<?php echo esc_url( $cate['cate_img']['url'] ); ?>" alt="<?php echo !empty( $cate['cate_img']['alt'] ) ? esc_attr( $cate['cate_img']['alt'] ) : ''; ?>">
                            </div>
                            <?php endif; ?>
  					</div>
  				</div>
                <?php
                    endif;
                endforeach;
                ?> 
  			</div>
  		</div>
  		<div class="ed-crs-bottom txt_item_active mt-70 pera-content text-center">
          <?php 
                if(!empty($settings['descriptions'])):
                    echo edrio_wp_kses(wpautop($settings['descriptions']));
                endif;
            ?>
  		</div>
  	</div>
  </section>