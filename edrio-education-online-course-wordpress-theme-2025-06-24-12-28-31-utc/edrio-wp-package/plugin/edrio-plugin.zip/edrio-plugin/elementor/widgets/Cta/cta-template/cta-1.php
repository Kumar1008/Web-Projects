<div id="ed-newsletter6" class="ed-newsletter6-sec position-relative">
    <?php if(!empty($settings['img1']['url'])):?>
        <span class="ed-news-bg position-absolute">
            <img src="<?php echo esc_url($settings['img1']['url']);?>" alt="<?php if(!empty($settings['img1']['alt'])){ echo esc_attr($settings['img1']['alt']);}else{esc_attr_e('About Image', 'edrio-plugin');}?>">
        </span>
    <?php endif;?>
    <?php if(!empty($settings['img2']['url'])):?>
        <span class="ed-shape-img1 right_view position-absolute">
            <img src="<?php echo esc_url($settings['img2']['url']);?>" alt="<?php if(!empty($settings['img2']['alt'])){ echo esc_attr($settings['img2']['alt']);}else{esc_attr_e('About Image', 'edrio-plugin');}?>">
        </span>
    <?php endif;?>
    <div class="container">
        <div class="ed-newsletter6-content d-flex justify-content-end">
            <div class="ed-newsletter6-text headline-6 d-flex align-items-center">
                <?php if(!empty($settings['title'])):?>
                    <h3>
                        <?php echo edrio_wp_kses($settings['title']);?>
                    </h3>
                <?php endif;?>
                <?php 
                    if(!empty($settings['shortcode'])){
                        echo do_shortcode($settings['shortcode']);
                    }
                ?>
            </div>
        </div>
    </div>
</div> 