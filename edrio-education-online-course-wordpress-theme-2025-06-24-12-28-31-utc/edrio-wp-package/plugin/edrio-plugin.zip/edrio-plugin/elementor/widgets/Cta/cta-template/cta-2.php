<section id="ed-cont6" class="ed-cont6-sec  position-relative pt-130 pb-130">
<?php if(!empty($settings['img1']['url'])):?>
    <div class="ed-cont6-side img-parallax position-absolute">
        <img src="<?php echo esc_url($settings['img1']['url']);?>" alt="<?php if(!empty($settings['img1']['alt'])){ echo esc_attr($settings['img1']['alt']);}else{esc_attr_e('About Image', 'edrio-plugin');}?>">
    </div>
<?php endif;?>
<div class="container">
    <div class="ed-cont6-text-form">
        <div class="ed-cont6-form-area">
            <div class="ed-sec-title-6 headline-6 pera-content">
                <?php if(!empty($settings['title'])):?>
                    <h2 class="sec_title ed-sec-tt-anim ed-has-anim">
                        <?php echo edrio_wp_kses($settings['title']);?>
                    </h2>
                <?php endif;?>
                <?php if(!empty($settings['description'])):?>
                    <p><?php echo edrio_wp_kses($settings['description']);?></p>
                <?php endif;?>
            </div>
            <?php if(!empty($settings['shortcode'])):?>
                <div class="ed-cont6-form">
                    <?php echo do_shortcode($settings['shortcode']);?>
                </div>
            <?php endif;?>
        </div>
        <div class="ed-cont6-img-wrap">
            <div class="item-img-wrap">
            <?php if(!empty($settings['img2']['url'])):?>
                <div class="item-img1 ed_img_ani_5 position-relative">
                    <div class="inner-img">
                        <img src="<?php echo esc_url($settings['img2']['url']);?>" alt="<?php if(!empty($settings['img2']['alt'])){ echo esc_attr($settings['img2']['alt']);}else{esc_attr_e('About Image', 'edrio-plugin');}?>">
                    </div>
                </div>
            <?php endif;?>
            <?php if(!empty($settings['img3']['url'])):?>
                <div class="item-img2 ed_img_ani_4">
                    <div class="inner-img">
                        <img src="<?php echo esc_url($settings['img3']['url']);?>" alt="<?php if(!empty($settings['img3']['alt'])){ echo esc_attr($settings['img3']['alt']);}else{esc_attr_e('About Image', 'edrio-plugin');}?>">
                    </div>
                </div>
            <?php endif;?>
            </div>
        </div>
    </div>
</div>
</section>