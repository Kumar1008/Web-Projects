<?php 
    if ( ! empty( $settings['btn_link']['url'] ) ) {
        $this->add_link_attributes( 'btn_link', $settings['btn_link'] );
    }
?>
<div class="ed-footer4-cta pb-65 d-flex align-items-center justify-content-between">
    <div class="ed-ft4-cta-img right_view">
        <?php if(!empty($settings['img1']['url'])):?>
            <div class="item-img-1 mb-20">
                <img src="<?php echo esc_url($settings['img1']['url']);?>" alt="<?php if(!empty($settings['img1']['alt'])){ echo esc_attr($settings['img1']['alt']);}else{esc_attr_e('About Image', 'edrio-plugin');}?>">
            </div>
        <?php endif;?>
        <div class="cta-img-wrapper d-flex">
            <?php if(!empty($settings['img2']['url'])):?>
                <div class="item-img-2">
                    <img src="<?php echo esc_url($settings['img2']['url']);?>" alt="<?php if(!empty($settings['img2']['alt'])){ echo esc_attr($settings['img2']['alt']);}else{esc_attr_e('About Image', 'edrio-plugin');}?>">
                </div>
            <?php endif;?>
            <?php if(!empty($settings['img3']['url'])):?>
                <div class="item-img-2">
                    <img src="<?php echo esc_url($settings['img3']['url']);?>" alt="<?php if(!empty($settings['img3']['alt'])){ echo esc_attr($settings['img3']['alt']);}else{esc_attr_e('About Image', 'edrio-plugin');}?>">
                </div>
            <?php endif;?>
        </div>
    </div>
    <div class="ed-ft4-cta-text top_view_2 text-center headline-4">
        <?php if(!empty($settings['title'])):?>
        <h2><?php echo edrio_wp_kses($settings['title']);?></h2>
        <?php endif;?>
        <?php if(!empty($settings['description'])):?>
            <div class="cta_info">
                <?php echo edrio_wp_kses($settings['description']);?>
            </div>
        <?php endif;?>
        <div class="cta_btn">
            <a <?php echo $this->get_render_attribute_string( 'btn_link' ); ?>><?php echo edrio_wp_kses($settings['btn_label']);?></a>
        </div>
    </div>
    <div class="ed-ft4-cta-img left_view">
        <div class="cta-img-wrapper mb-20 d-flex justify-content-end">

            <?php if(!empty($settings['img4']['url'])):?>
                <div class="item-img-2">
                    <img src="<?php echo esc_url($settings['img4']['url']);?>" alt="<?php if(!empty($settings['img4']['alt'])){ echo esc_attr($settings['img4']['alt']);}else{esc_attr_e('About Image', 'edrio-plugin');}?>">
                </div>
            <?php endif;?>
            <?php if(!empty($settings['img5']['url'])):?>
                <div class="item-img-2">
                    <img src="<?php echo esc_url($settings['img5']['url']);?>" alt="<?php if(!empty($settings['img5']['alt'])){ echo esc_attr($settings['img5']['alt']);}else{esc_attr_e('About Image', 'edrio-plugin');}?>">
                </div>
            <?php endif;?>
        </div>
        <?php if(!empty($settings['img6']['url'])):?>
            <div class="item-img-1">
                <img src="<?php echo esc_url($settings['img6']['url']);?>" alt="<?php if(!empty($settings['img6']['alt'])){ echo esc_attr($settings['img6']['alt']);}else{esc_attr_e('About Image', 'edrio-plugin');}?>">
            </div>
        <?php endif;?>
    </div>
</div>