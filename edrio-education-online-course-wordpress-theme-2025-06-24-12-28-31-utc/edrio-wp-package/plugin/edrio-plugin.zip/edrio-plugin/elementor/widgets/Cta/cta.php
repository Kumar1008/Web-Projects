<?php

/**
 * Elementor Single Widget
 * @package edrio Tools
 * @since 1.0.0
 */

namespace Elementor;

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly.

class Edrio_Cta extends Widget_Base {

	/**
	 * Slider Style Dependency
	 *
	 * @return void
	 */
	public function get_style_depends()
	{
		return ['edrio-cta'];
	}

	/**
	 * Get widget name.
	 *
	 * Retrieve Elementor widget name.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget name.
	 */
	public function get_name() {
		return 'go-cta-content';
	}

	/**
	 * Get widget title.
	 *
	 * Retrieve Elementor widget title.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget title.
	 */
	public function get_title() {
		return esc_html__( 'Edrio CTA', 'edrio-plugin' );
	}

	/**
	 * Get widget icon.
	 *
	 * Retrieve Elementor widget icon.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget icon.
	 */
	public function get_icon() {
		return 'edrio-custom-icon';
	}

	/**
	 * Get widget categories.
	 *
	 * Retrieve the list of categories the Elementor widget belongs to.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return array Widget categories.
	 */
	public function get_categories() {
		return [ 'edrio_widgets' ];
	}


	protected function register_controls() {

		$this->start_controls_section(
			'int_widget_opt',
			[
				'label' => esc_html__( 'Heading Style Select', 'edrio-plugin' ),
				'tab'   => Controls_Manager::TAB_CONTENT,
			]
		);
        $this->add_control(
			'style',
			[
				'label' => esc_html__( 'Style', 'edrio-plugin' ),
				'type' => \Elementor\Controls_Manager::SELECT,
				'default' => '1',
				'options' => [
					'1'  => esc_html__( 'Style 1', 'edrio-plugin' ),
					'2'  => esc_html__( 'Style 2', 'edrio-plugin' ),
					'3'  => esc_html__( 'Style 3', 'edrio-plugin' )
				]
			]
		);
        $this->end_controls_section();

        $this->start_controls_section(
			'--cta-option',
			[
				'label' => esc_html__( 'CTA Option', 'edrio-plugin' ),
				'tab'   => Controls_Manager::TAB_CONTENT,
			]
		);

        $this->add_control(
			'img1', [
				'label' => esc_html__( 'Image', 'edrio-plugin' ),
				'type' => Controls_Manager::MEDIA,
                'label_block' => true,
			]
		);
        $this->add_control(
			'img2', [
				'label' => esc_html__( 'Image 2', 'edrio-plugin' ),
				'type' => Controls_Manager::MEDIA,
                'label_block' => true,
			]
		);
        $this->add_control(
			'img3', [
				'label' => esc_html__( 'Image 3', 'edrio-plugin' ),
				'type' => Controls_Manager::MEDIA,
                'label_block' => true,
				'condition' => [
					'style' => ['2', '3'],
				],
			]
		);
        $this->add_control(
			'img4', [
				'label' => esc_html__( 'Image 4', 'edrio-plugin' ),
				'type' => Controls_Manager::MEDIA,
                'label_block' => true,
				'condition' => [
					'style' => ['3'],
				],
			]
		);
        $this->add_control(
			'img5', [
				'label' => esc_html__( 'Image 5', 'edrio-plugin' ),
				'type' => Controls_Manager::MEDIA,
                'label_block' => true,
				'condition' => [
					'style' => ['3'],
				],
			]
		);
        $this->add_control(
			'img6', [
				'label' => esc_html__( 'Image 6', 'edrio-plugin' ),
				'type' => Controls_Manager::MEDIA,
                'label_block' => true,
				'condition' => [
					'style' => ['3'],
				],
			]
		);

        $this->add_control(
			'title', [
				'label' => esc_html__( 'Title', 'edrio-plugin' ),
				'default' => esc_html__( 'Section Title', 'edrio-plugin' ),
				'type' => Controls_Manager::TEXTAREA,
                'label_block' => true,
			]
		);
        $this->add_control(
			'description', [
				'label' => esc_html__( 'Description', 'edrio-plugin' ),
				'type' => Controls_Manager::WYSIWYG,
                'label_block' => true,
			]
		);
        $this->add_control(
			'shortcode', [
				'label' => esc_html__( 'Shortcode', 'edrio-plugin' ),
				'type' => Controls_Manager::TEXTAREA,
                'label_block' => true,
				'condition' => [
					'style!' => '3',
				],
			]
		);
		$this->add_control(
			'btn_label', [
				'label' => esc_html__( 'Button Label', 'edrio-plugin' ),
				'default' => esc_html__( 'edrio Button', 'edrio-plugin' ),
				'type' => Controls_Manager::TEXT,
                'label_block' => true,
				'condition' => [
					'style' => '3',
				],
			]
		);
       
        $this->add_control(
			'btn_link', [
				'label' => esc_html__( 'Button Link', 'edrio-plugin' ),
				'type' => Controls_Manager::URL,
                'default' => [
					'url' => '',
					'is_external' => true,
					'nofollow' => true,
					// 'custom_attributes' => '',
				],
				'label_block' => true,
				'condition' => [
					'style' => '3',
				],
			]
		);
		$this->end_controls_section();
		$this->start_controls_section(
			'cta_title_style',
			[
				'label' => esc_html__( 'Cta Title Style', 'edrio-plugin' ),
				'tab'   => Controls_Manager::TAB_STYLE,
				'condition' => [
					'style' => ['10', '2'],
				],
			]
		);
		$this->add_responsive_control(
			'title_margin',
			[
				'label' => esc_html__( 'Title Margin', 'edrio-plugin' ),
				'type' => \Elementor\Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em', 'rem', 'custom' ],
				'selectors' => [
					'{{WRAPPER}} .agt-footer-text h2' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					'{{WRAPPER}} .agn-sec-title-5' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};'
				],
			]
		);
        $this->add_control(
			'title_color',
			[
				'label' => esc_html__( 'Title Color', 'edrio-plugin' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .agt-footer-text h2' => 'color: {{VALUE}}',
					'{{WRAPPER}} .agn-sec-title-5' => 'color: {{VALUE}} !important',
				],
			]
		);
      
		// typography
		$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[

				'name' => 'title_typography',
				'selector' => '
					{{WRAPPER}} .agt-footer-text h2
					{{WRAPPER}} .agn-sec-title-5
				',
			]
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'cta_btn_style',
			[
				'label' => esc_html__( 'Cta BTN Style', 'edrio-plugin' ),
				'tab'   => Controls_Manager::TAB_STYLE,
				'condition' => [
					'style' => ['10'],
				],
			]
		);
		
        $this->add_control(
			'btn_bg_color',
			[
				'label' => esc_html__( 'Button BG Color', 'edrio-plugin' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .agt-footer-text h2 i' => 'background: {{VALUE}}',
				],
			]
		);
      
		$this->end_controls_section();
		$this->start_controls_section(
			'cta_bg_style',
			[
				'label' => esc_html__( 'Cta BG Style', 'edrio-plugin' ),
				'tab'   => Controls_Manager::TAB_STYLE,
				'condition' => [
					'style' => ['5', '6', '4'],
				],
			]
		);
		$this->add_group_control(
			\Elementor\Group_Control_Background::get_type(),
			[
				'name' => 'cta_bg_hover_color',
				'types' => [ 'gradient' ],
				'exclude' => [ 'image' ],
				'selector' => '
					{{WRAPPER}} .agt-cta-content-6:before, .agt-cta-content-6:after,
					{{WRAPPER}} .agt-fr-cta-section:before
				',
                'fields_options' => [
                    'background' => [
                        'label' => esc_html__( 'Cta BG Color ', 'goyto-plugin' ),
                        'description' => esc_html__( 'Choose background type and style.', 'goyto-plugin' ),
                        'separator' => 'before',
                    ]
                ]
			]
		);
        
      
		$this->end_controls_section();
		$this->start_controls_section(
			'cta_desc_style',
			[
				'label' => esc_html__( 'Cta Desc Style', 'edrio-plugin' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);
		
        $this->add_control(
			'box_bg_color',
			[
				'label' => esc_html__( 'Cta Box BG Color', 'edrio-plugin' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .agn-contact-9-content' => 'background: {{VALUE}}'
				],
				'condition' => [
					'style' => ['7'],
				],
			]
		);
		
        $this->add_control(
			'desc_color',
			[
				'label' => esc_html__( 'Cta DEsc Color', 'edrio-plugin' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .disc' => 'color: {{VALUE}}',
					'{{WRAPPER}} .agn-p-5' => 'color: {{VALUE}}',
					'{{WRAPPER}} .agn-p-9' => 'color: {{VALUE}}'
				],
			]
		);
      
		$this->end_controls_section();
		$this->start_controls_section(
			'cta_form_style',
			[
				'label' => esc_html__( 'Cta Form Style', 'edrio-plugin' ),
				'tab'   => Controls_Manager::TAB_STYLE,
				'condition' => [
					'style' => ['8'],
				],
			]
		);
		
        $this->add_control(
			'form_color',
			[
				'label' => esc_html__( 'Cta Form Color', 'edrio-plugin' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .agn-donation-9-form-label-2' => 'color: {{VALUE}}',
					'{{WRAPPER}} .agn-donation-9-form-radio' => 'color: {{VALUE}}',
					'{{WRAPPER}} .agn-donation-9-form-label' => 'color: {{VALUE}}',
					'{{WRAPPER}} .agn-donation-9-form-agree' => 'color: {{VALUE}}',
					'{{WRAPPER}} .agn-donation-9-form-input' => 'color: {{VALUE}}'
				],
			]
		);
      
		$this->end_controls_section();

	}


	protected function render() {
		$settings = $this->get_settings_for_display();

		require __DIR__ . '/cta-template/cta-' . $settings['style'] . '.php';
    }


}


Plugin::instance()->widgets_manager->register( new Edrio_Cta() );