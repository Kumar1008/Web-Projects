<?php 
    $this->add_render_attribute( 'title', 'class', 'elementor-gt-heading sec_title ed-sec-tt-anim ed-has-anim' );

    if ( ! empty( $settings['btn_link']['url'] ) ) {
        $this->add_link_attributes( 'btn_link', $settings['btn_link'] );
    }
?>
<section id="ed-event" class="ed-event-sec pb-130 position-relative">
  	<div class="ed-event-content d-flex">
        <?php if(!empty($settings['video']['url'])):?>
            <div class="ed-event-img">
                <video width="100%" height="100%" loop="" muted="" playsinline="true"  autoplay="true" src="<?php echo esc_url($settings['video']['url']);?>"></video>
            </div>
        <?php endif;?>
  		<div class="ed-event-list-wrap position-relative">
  			<div class="ed-event-list-area position-relative">
  				<div class="ed-ev-shape position-absolute left_view">
  					<svg width="162" height="162" viewBox="0 0 162 162" fill="none" xmlns="http://www.w3.org/2000/svg">
  						<path d="M162 0H81V81H162V0Z" fill="white"/>
  						<path d="M0 81H81V0C36.2612 0 0 36.2638 0 81Z" fill="#F38073"/>
  						<path d="M81 81H0C0 125.733 36.2671 162 81 162V81Z" fill="#4AD2CC"/>
  						<path d="M162 81H81V162H162V81Z" fill="#FF9960"/>
  					</svg>
  				</div> 
  				<div class="ed-ev-shape-2 ed_top_img_3 position-absolute">
  					<svg width="254" height="256" viewBox="0 0 254 256" fill="none" xmlns="http://www.w3.org/2000/svg">
  						<path d="M253.922 128V0H252.827C183.008 0.581944 126.504 57.0859 125.922 126.905V128H253.922Z" fill="white"/>
  						<path d="M0 255.018H126.063V128.941C125.485 198.311 69.356 254.44 0 255.018Z" fill="white"/>
  						<path d="M251.985 128H125.922V254.077C126.5 184.707 182.629 128.578 251.985 128Z" fill="white"/>
  					</svg>
  				</div> 
  				<div class="ed-event-list-text">
  					<div class="ed-event-top mb-45 d-flex justify-content-between align-items-end">
  						<div class="ed-sec-title-5 headline-5 pera-content">
                            <?php if(!empty($settings['subtitle'])):?>
  							<div class="subtitle wow fadeInRight" data-wow-delay="300ms" data-wow-duration="1500ms"><?php echo edrio_wp_kses(val: $settings['subtitle'])?></div>
                            <?php endif;?>
                              <?php 
                                    printf('<%1$s %2$s>%3$s</%1$s>',
                                        tag_escape($settings['title_tag']),
                                        $this->get_render_attribute_string('title'),
                                        nl2br(edrio_wp_kses($settings['title']))
                                    ); 
                                ?>
  						</div>
                        <?php if(!empty($settings['btn_label'])):?>
  						<div class="ed-btn-5 mt-30">
  							<a <?php echo $this->get_render_attribute_string( 'btn_link' ); ?>>
  								<div class="ed_btn_text  d-flex align-items-center">
  									<span class="b-text"><?php echo edrio_wp_kses($settings['btn_label']);?></span>
  									<span class="b-icon">
  										<svg width="10" height="10" viewBox="0 0 10 10" fill="none" xmlns="http://www.w3.org/2000/svg">
  											<path d="M1.66619 0.833333C1.66619 0.61232 1.75399 0.400358 1.91027 0.244078C2.06655 0.0877975 2.27851 0 2.49953 0H9.16619C9.38721 0 9.59917 0.0877975 9.75545 0.244078C9.91173 0.400358 9.99953 0.61232 9.99953 0.833333V7.5C9.99953 7.72101 9.91173 7.93297 9.75545 8.08926C9.59917 8.24554 9.38721 8.33333 9.16619 8.33333C8.94518 8.33333 8.73322 8.24554 8.57694 8.08926C8.42066 7.93297 8.33286 7.72101 8.33286 7.5V2.845L1.42203 9.75583C1.26486 9.90763 1.05436 9.99163 0.835858 9.98973C0.617361 9.98783 0.40835 9.90019 0.253844 9.74568C0.0993368 9.59118 0.0116958 9.38216 0.00979713 9.16367C0.00789844 8.94517 0.0918941 8.73467 0.243692 8.5775L7.15453 1.66667H2.49953C2.27851 1.66667 2.06655 1.57887 1.91027 1.42259C1.75399 1.26631 1.66619 1.05435 1.66619 0.833333Z" fill="#fff"></path>
  										</svg>
  									</span>
  								</div>
  							</a>
  						</div>
                        <?php endif;?>
  					</div>
  					<div class="ed-event-list-items-wrap">
                        <?php foreach($settings['events'] as $item):?>
                            <div class="ed-event-list-item top_view d-flex align-items-center">
                                <div class="item-img position-relative">
                                    <div class="inner-img">
                                        <img src="<?php echo esc_url($item['image']['url']);?>" alt="<?php if(!empty($item['image']['alt'])){ echo esc_attr($item['image']['alt']);}else{esc_attr_e('About Image', 'edrio-plugin');}?>">
                                    </div>
                                </div>
                                <div class="item-text headline-5 pera-content ul-li">
                                    <h3 class="href-underline"><a target="<?php echo esc_attr( $item['link']['is_external'] ? '_blank' : '_self' ); ?>" rel="<?php echo esc_attr( $item['link']['nofollow'] ? 'nofollow' : '' ); ?>" href="<?php echo esc_url($item['link']['url']);?>"><?php echo edrio_wp_kses($item['title'])?></a></h3>
                                    <?php if(!empty($item['desc'])):?>
                                        <p><?php echo edrio_wp_kses($item['desc'])?></p>
                                    <?php endif;?>
                                    <ul>
                                        <?php if(!empty($item['location'])):?>
                                            <li><i class="fa-solid fa-location-dot"></i> <?php echo edrio_wp_kses($item['location'])?></li>
                                        <?php endif;?>
                                        <?php if(!empty($item['time'])):?>
                                            <li><i class="fa-solid fa-clock"></i> <?php echo edrio_wp_kses($item['time'])?></li>
                                        <?php endif;?>
                                    </ul>
                                    <div class="item-arrow">
                                        <a target="<?php echo esc_attr( $item['link']['is_external'] ? '_blank' : '_self' ); ?>" rel="<?php echo esc_attr( $item['link']['nofollow'] ? 'nofollow' : '' ); ?>" href="<?php echo esc_url($item['link']['url']);?>"><i class="fa-solid fa-arrow-right-long"></i></a>
                                    </div>
                                </div>
                            </div>
                        <?php endforeach;?>
  					</div>
  				</div>
  			</div>
  		</div>
  	</div>
  </section>