<?php

/**
 * Elementor Single Widget
 * @package edrio Tools
 * @since 1.0.0
 */

namespace Elementor;

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly.

class Edrio_Event extends Widget_Base {


	/**
	 * Get widget name.
	 *
	 * Retrieve Elementor widget name.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget name.
	 */
	public function get_name() {
		return 'agnr-event';
	}

	/**
	 * Get widget title.
	 *
	 * Retrieve Elementor widget title.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget title.
	 */
	public function get_title() {
		return esc_html__( 'Event', 'edrio-plugin' );
	}

	/**
	 * Get widget icon.
	 *
	 * Retrieve Elementor widget icon.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget icon.
	 */
	public function get_icon() {
		return 'edrio-custom-icon';
	}

	/**
	 * Get widget categories.
	 *
	 * Retrieve the list of categories the Elementor widget belongs to.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return array Widget categories.
	 */
	public function get_categories() {
		return [ 'edrio_widgets' ];
	}


	protected function register_controls() {
       

        $this->start_controls_section(
			'event__content-box',
			[
				'label' => esc_html__( 'Event Conntent', 'edrio-plugin' ),
				'tab'   => Controls_Manager::TAB_CONTENT,
			]
		);
		
        $this->add_control(
			'video', [
				'label' => esc_html__( 'Video', 'edrio-plugin' ),
				'type' => Controls_Manager::MEDIA,
                'label_block' => true,
                'media_types' => ['video']
			]
		);
        $this->add_control(
			'subtitle', [
				'label' => esc_html__( 'Sub Title', 'edrio-plugin' ),
				'default' => esc_html__( 'Get To Know Us', 'edrio-plugin' ),
				'type' => Controls_Manager::TEXT,
                'label_block' => true,
			]
		);
        
        $this->add_control(
			'title', [
				'label' => esc_html__( 'Title', 'edrio-plugin' ),
				'default' => esc_html__( 'Section Title', 'edrio-plugin' ),
				'type' => Controls_Manager::TEXTAREA,
                'label_block' => true,
			]
		);
        
		$this->add_control(
            'title_tag',
            [
                'label'   => __( 'Title HTML Tag', 'edrio-plugin' ),
                'type'    => Controls_Manager::CHOOSE,
                'options' => [
                    'h1' => [
                        'title' => __( 'H1', 'edrio-plugin' ),
                        'icon'  => 'eicon-editor-h1',
                    ],
                    'h2' => [
                        'title' => __( 'H2', 'edrio-plugin' ),
                        'icon'  => 'eicon-editor-h2',
                    ],
                    'h3' => [
                        'title' => __( 'H3', 'edrio-plugin' ),
                        'icon'  => 'eicon-editor-h3',
                    ],
                    'h4' => [
                        'title' => __( 'H4', 'edrio-plugin' ),
                        'icon'  => 'eicon-editor-h4',
                    ],
                    'h5' => [
                        'title' => __( 'H5', 'edrio-plugin' ),
                        'icon'  => 'eicon-editor-h5',
                    ],
                    'h6' => [
                        'title' => __( 'H6', 'edrio-plugin' ),
                        'icon'  => 'eicon-editor-h6',
                    ],
                ],
                'default' => 'h1',
                'toggle'  => false,
            ]
        );
        $this->add_control(
			'btn_label', [
				'label' => esc_html__( 'Button Label', 'edrio-plugin' ),
				'default' => esc_html__( 'edrio Button', 'edrio-plugin' ),
				'type' => Controls_Manager::TEXT,
                'label_block' => true,
			]
		);
        
        $this->add_control(
			'btn_link', [
				'label' => esc_html__( 'Button Link', 'edrio-plugin' ),
				'type' => Controls_Manager::URL,
                'default' => [
					'url' => '',
					'is_external' => true,
					'nofollow' => true,
					// 'custom_attributes' => '',
				],
				'label_block' => true,
			]
		);
        $repeater = new \Elementor\Repeater();
		
        $repeater->add_control(
			'image', [
				'label' => esc_html__( 'Image', 'edrio-plugin' ),
				'type' => Controls_Manager::MEDIA,
                'label_block' => true,
			]
		);
		
        $repeater->add_control(
			'title', [
				'label' => esc_html__( 'Title', 'edrio-plugin' ),
				'default' => esc_html__( 'Residential Construction', 'edrio-plugin' ),
				'type' => Controls_Manager::TEXT,
                'label_block' => true,
			]
		);
        
        $repeater->add_control(
			'desc', [
				'label' => esc_html__( 'Description', 'edrio-plugin' ),
				'default' => esc_html__( 'Residential Construction', 'edrio-plugin' ),
				'type' => Controls_Manager::TEXTAREA,
                'label_block' => true,
			]
		);
        $repeater->add_control(
			'location', [
				'label' => esc_html__( 'Location', 'edrio-plugin' ),
				'type' => Controls_Manager::TEXTAREA,
                'label_block' => true,
			]
		);
        $repeater->add_control(
			'time', [
				'label' => esc_html__( 'Time', 'edrio-plugin' ),
				'type' => Controls_Manager::TEXT,
                'label_block' => true,
			]
		);

        $repeater->add_control(
			'link', [
				'label' => esc_html__( 'link', 'edrio-plugin' ),
				'type' => Controls_Manager::URL,
                'label_block' => true,
			]
		);
        
        $this->add_control(
			'events',
			[
				'label' => esc_html__( 'Add Event Item', 'goyto-plugin' ),
				'type' => \Elementor\Controls_Manager::REPEATER,
				'fields' => $repeater->get_controls(),
                'title_field' => '{{{ title }}}',
			]
		);
		$this->end_controls_section();

	}


	protected function render() {
		$settings = $this->get_settings_for_display();
        require __DIR__ . '/event-template/event.php';
    }


}


Plugin::instance()->widgets_manager->register( new Edrio_Event() );