<?php

/**
 * Elementor Single Widget
 * @package edrio Tools
 * @since 1.0.0
 */

namespace Elementor;

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly.

class Edrio_Footer_About extends Widget_Base {

	/**
	 * Get widget name.
	 *
	 * Retrieve Elementor widget name.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget name.
	 */
	public function get_name() {
		return 'agr-footer-about';
	}

	/**
	 * Get widget title.
	 *
	 * Retrieve Elementor widget title.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget title.
	 */
	public function get_title(): mixed {
		return esc_html__( 'Edrio Footer About', 'edrio-plugin' );
	}

	/**
	 * Get widget icon.
	 *
	 * Retrieve Elementor widget icon.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget icon.
	 */
	public function get_icon() {
		return 'edrio-custom-icon';
	}

	/**
	 * Get widget categories.
	 *
	 * Retrieve the list of categories the Elementor widget belongs to.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return array Widget categories.
	 */
	public function get_categories() {
		return [ 'edrio_widgets' ];
	}


	protected function register_controls() {

		$this->start_controls_section(
			'int_widget_opt',
			[
				'label' => esc_html__( 'Brand Style Select', 'edrio-plugin' ),
				'tab'   => Controls_Manager::TAB_CONTENT,
			]
		);
        $this->add_control(
			'style',
			[
				'label' => esc_html__( 'Style', 'edrio-plugin' ),
				'type' => \Elementor\Controls_Manager::SELECT,
				'default' => '1',
				'options' => [
					'1'  => esc_html__( 'Style 1', 'edrio-plugin' )
				]
			]
		);
        $this->end_controls_section();
		
        $this->start_controls_section(
			'--footer-option',
			[
				'label' => esc_html__( 'Footer Option', 'edrio-plugin' ),
				'tab'   => Controls_Manager::TAB_CONTENT,
			]
		);
		$this->add_control(
			'logo', [
				'label' => esc_html__( 'Logo', 'gtbus-plugin' ),
				'type' => Controls_Manager::MEDIA,
                'label_block' => true,
			]
		);
		$this->add_control(
			'title', [
				'label' => esc_html__( 'Title', 'gtbus-plugin' ),
				'type' => Controls_Manager::TEXT,
                'label_block' => true,
			]
		);
		$this->add_control(
			'description', [
				'label' => esc_html__( 'Description', 'gtbus-plugin' ),
				'type' => Controls_Manager::TEXTAREA,
                'label_block' => true,
			]
		);
		
        $repeater = new \Elementor\Repeater();

        $repeater->add_control(
			'count', [
				'label' => esc_html__( 'Count', 'edrio-plugin' ),
				'type' => Controls_Manager::TEXT,
                'label_block' => true,
			]
		);
        $repeater->add_control(
			'prefix', [
				'label' => esc_html__( 'Prefix', 'edrio-plugin' ),
				'type' => Controls_Manager::TEXT,
                'label_block' => true,
			]
		);
        $repeater->add_control(
			'title', [
				'label' => esc_html__( 'Title', 'edrio-plugin' ),
				'type' => Controls_Manager::TEXT,
                'label_block' => true,
			]
		);
        

        $this->add_control(
			'counters',
			[
				'label' => esc_html__( 'Add Counter Item', 'edrio-plugin' ),
				'type' => \Elementor\Controls_Manager::REPEATER,
				'fields' => $repeater->get_controls(),
			]
		);
        $this->add_control(
			'copyright',
			[
				'label' => esc_html__( 'Copyright', 'edrio-plugin' ),
				'type' => \Elementor\Controls_Manager::WYSIWYG,
				'default' => esc_html__( 'Default description', 'edrio-plugin' ),
			]
		);
		$this->end_controls_section();




	}


	protected function render() {
		$settings = $this->get_settings_for_display();
        ?>
    <div class="ed--ft4-about pera-content pb-60">
        <?php if(!empty($settings['title'])):?>
            <div class="ed_ab_title"><span><?php echo edrio_wp_kses($settings['title']);?></span> <i></i></div>
        <?php endif;?>
        <div class="ed-ft4-counter mt-50 d-flex align-items-center justify-content-between">
            <div class="brand-logo-text d-flex align-items-center">
                <?php if(!empty($settings['logo']['url'])):?>
                    <a href="<?php echo esc_url(home_url());?>" aria-label="name">
                        <img class="logo_site-size" src="<?php echo esc_url($settings['logo']['url']);?>" alt="<?php if(!empty($settings['logo']['alt'])){ echo esc_attr($settings['logo']['alt']);}?>">
                    </a>
                <?php endif;?>

                <?php if(!empty($settings['description'])):?>
                    <p><?php echo edrio_wp_kses($settings['description']);?></p>
                <?php endif;?>
            </div>
            <div class="ft4-counter-wrap d-flex align">
                <?php foreach($settings['counters'] as $item):?>
                    <div class="ft4-count-item headline-4 pera-content">
                        <h3>
                            <span class="counter"><?php echo edrio_wp_kses($item['count'])?></span>
                            <?php if(!empty($item['prefix'])){ echo esc_html($item['prefix']);}?></h3>
                        <p><?php echo edrio_wp_kses($item['title'])?></p>
                    </div>
                <?php endforeach;?>
            </div>
        </div>
    </div>
    <?php
    }


}


Plugin::instance()->widgets_manager->register( new Edrio_Footer_About() );