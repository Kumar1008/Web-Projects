<div class="ed-footer-bottom d-flex justify-content-between align-items-end">
    <div class="ed-ftr-widget">
        <div class="newsletter-widget">
            <?php if(!empty($settings['title'])):?>
                <h3 class="widget-title">
                    <?php echo edrio_wp_kses($settings['title']);?>
                </h3>
            <?php endif;?>
            <?php if($settings['shortcode']){
                echo do_shortcode($settings['shortcode']);
            }?>
        </div>
    </div>
    <div class="ed-ft-gallery-social d-flex align-items-center">
        <?php if(!empty($settings['gallerys'])):?>
            <div class="ed-ft-gallery ul-li">
                <ul>
                    <?php foreach($settings['gallerys'] as $item):?>
                        <li><img src="<?php echo esc_url($item['url']);?>" alt=""></li>
                    <?php endforeach;?>
                </ul>
            </div>
        <?php endif;?>
        <div class="ed-ft-social text-uppercase ul-li-block">
            <ul>
                <?php foreach($settings['socials'] as $item):?>
                    <li>
                        <a href="<?php echo esc_url($item['link']['url']);?>">
                            <?php \Elementor\Icons_Manager::render_icon( $item['icon'], [ 'aria-hidden' => 'true' ] ); ?>
                            <?php echo edrio_wp_kses($item['title']);?>
                        </a>
                    </li>
                <?php endforeach;?>
            </ul>
        </div>
    </div>
</div>
<?php if(!empty($settings['copyright'])):?>
    <div class="ed-footer-copyright text-center">
        <span>
            <?php echo edrio_wp_kses(wpautop($settings['copyright']));?>
        </span>
    </div>
<?php endif;?>