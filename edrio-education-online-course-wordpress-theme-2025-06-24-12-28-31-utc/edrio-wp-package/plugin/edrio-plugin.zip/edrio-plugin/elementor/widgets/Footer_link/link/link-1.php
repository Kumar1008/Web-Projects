<div class="ed-ftr-widget">
    <div class="menu-widget ul-li-block">
        <ul>
            <?php foreach($settings['links'] as $item):?>
                <li><a href="<?php echo esc_url($item['link']['url']);?>"><?php echo edrio_wp_kses($item['title'])?></a></li>
            <?php endforeach;?>
        </ul>
    </div>
</div>