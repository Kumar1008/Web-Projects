<div class="ed-footer6-widget-area">
    <div class="ed-footer6-widget-cont position-relative d-flex justify-content-between">
        <?php foreach($settings['links'] as $item):?>
            <div class="ed-footer5-widget headline-6 ul-li-block">
                <div class="menu-widget">
                    <?php if(!empty($item['title'])):?>
                        <h3 class="widget-title"><?php echo edrio_wp_kses($item['title'])?></h3>
                    <?php endif;?>
                    <ul class="ed-footer-1-menu">
                        <?php foreach($item['links'] as $link):?>
                            <li><a href="<?php echo esc_url($link['link']['url']);?>"><?php echo edrio_wp_kses($link['link_text'])?></a></li>
                        <?php endforeach;?>
                    </ul>
                </div>
            </div>
        <?php endforeach;?>
        <div class="ed-footer5-widget headline-6 ul-li-block">
            <div class="cta-widget">
                <?php if(!empty($settings['ct_title'])):?>
                    <h3 class="widget-title"><?php echo edrio_wp_kses($settings['ct_title'])?></h3>
                <?php endif;?>
                <div class="cta-info-wrap">
                    <?php foreach($settings['ct_infos'] as $item):?>
                        <div class="cta-info-item d-flex">
                            <div class="item-icon">
                                <?php \Elementor\Icons_Manager::render_icon( $item['icon'], [ 'aria-hidden' => 'true' ] ); ?>
                            </div>
                            <div class="item-text">
                                <?php echo edrio_wp_kses($item['title'])?>
                            </div>
                        </div>
                    <?php endforeach;?>
                </div>
            </div>
        </div>
    </div>
</div>