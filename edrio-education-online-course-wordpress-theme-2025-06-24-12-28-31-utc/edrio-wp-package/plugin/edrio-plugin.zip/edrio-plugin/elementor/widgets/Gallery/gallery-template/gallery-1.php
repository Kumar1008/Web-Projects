<div class="ed-media-frame-content">
    <div class="ed-mf-item d-flex justify-content-center">
        <?php $i=0; foreach($settings['gallerys'] as $item): $i++;?>
            <div class="item-img-<?php echo esc_attr($i);?>">
                <?php foreach($item['gallery'] as $gall):?>
                    <div class="inner-img">
                        <img src="<?php echo esc_url($gall['url']);?>" alt="<?php if(!empty($gall['alt'])){ echo esc_attr($gall['alt']);}else{esc_attr_e('Gallery', 'edrio-plugin');}?>">
                    </div>
                <?php endforeach;?>
            </div>
        <?php endforeach;?>
        
    </div>
</div>