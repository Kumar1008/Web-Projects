<div class="ed-footer6-gallery mt-35 ul-li headline-6">
    <?php if(!empty($settings['title'])):?>
        <h3><?php echo edrio_wp_kses($settings['title'])?></h3>
    <?php endif;?>
    <?php if(!empty($settings['gallerys'])):?>
    <ul class="zoom-gallery">
        <?php $i=0; foreach($settings['gallerys'] as $item): $i++;?>
            <li>
                <a href="<?php echo esc_url($item['url']);?>" data-source="<?php echo esc_url($item['url']);?>">
                    <img src="<?php echo esc_url($item['url']);?>" alt="<?php if(!empty($item['alt'])){ echo esc_attr($item['alt']);}else{esc_attr_e('Gallery', 'edrio-plugin');}?>">
                </a>
            </li>
        <?php endforeach;?>
    </ul>
    <?php endif;?>
</div>