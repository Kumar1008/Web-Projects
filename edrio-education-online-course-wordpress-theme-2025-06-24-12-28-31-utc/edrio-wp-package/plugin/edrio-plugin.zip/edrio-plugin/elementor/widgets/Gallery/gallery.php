<?php

/**
 * Elementor Single Widget
 * @package edrios Tools
 * @since 1.0.0
 */

namespace Elementor;

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly.

class Edrios_Gallery extends Widget_Base {

	/**
	 * Get widget name.
	 *
	 * Retrieve Elementor widget name.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget name.
	 */
	public function get_name() {
		return 'agnr-gallery-item';
	}

	/**
	 * Get widget title.
	 *
	 * Retrieve Elementor widget title.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget title.
	 */
	public function get_title() {
		return esc_html__( 'Gallery', 'edrios-plugin' );
	}

	/**
	 * Get widget icon.
	 *
	 * Retrieve Elementor widget icon.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget icon.
	 */
	public function get_icon() {
		return 'edrio-custom-icon';
	}

	/**
	 * Get widget categories.
	 *
	 * Retrieve the list of categories the Elementor widget belongs to.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return array Widget categories.
	 */
	public function get_categories() {
		return [ 'edrio_widgets' ];
	}


	protected function register_controls() {
		$this->start_controls_section(
			'int_widget_opt',
			[
				'label' => esc_html__( 'Gallery Style Select', 'edrios-plugin' ),
				'tab'   => Controls_Manager::TAB_CONTENT,
			]
		);
        $this->add_control(
			'style',
			[
				'label' => esc_html__( 'Style', 'edrios-plugin' ),
				'type' => \Elementor\Controls_Manager::SELECT,
				'default' => '1',
				'options' => [
					'1'  => esc_html__( 'Style 1', 'edrios-plugin' ),
					'2'  => esc_html__( 'Style 2', 'edrios-plugin' )
				]
			]
		);
        $this->end_controls_section();
        
        $this->start_controls_section(
			'--service-option',
			[
				'label' => esc_html__( 'Gallery Option', 'edrios-plugin' ),
				'tab'   => Controls_Manager::TAB_CONTENT,
			]
		);
		$this->add_control(
			'gallerys',
			[
				'label' => esc_html__( 'Add Images', 'edrios-plugin' ),
				'type' => \Elementor\Controls_Manager::GALLERY,
				'show_label' => false,
				'default' => [],
			]
		);
		$this->add_control(
			'title', [
				'label' => esc_html__( 'Title', 'edrio-plugin' ),
				'default' => esc_html__( 'Residential Construction', 'edrio-plugin' ),
				'type' => Controls_Manager::TEXTAREA,
                'label_block' => true,
				'condition' => [
					'style' => ['2'],
				],
			]
		);
		
        $repeater = new \Elementor\Repeater();
        
        $repeater->add_control(
			'gallery',
			[
				'label' => esc_html__( 'Add Images', 'edrios-plugin' ),
				'type' => \Elementor\Controls_Manager::GALLERY,
				'show_label' => false,
				'default' => [],
			]
		);
       
        $this->add_control(
			'gallerys',
			[
				'label' => esc_html__( 'Add Gallery Item', 'edrios-plugin' ),
				'type' => \Elementor\Controls_Manager::REPEATER,
				'fields' => $repeater->get_controls(),
			]
		);
        
		$this->end_controls_section();
	}


	protected function render() {
		$settings = $this->get_settings_for_display();
		require __DIR__ . '/gallery-template/gallery-' . $settings['style'] . '.php';
    }


}


Plugin::instance()->widgets_manager->register( new Edrios_Gallery() );