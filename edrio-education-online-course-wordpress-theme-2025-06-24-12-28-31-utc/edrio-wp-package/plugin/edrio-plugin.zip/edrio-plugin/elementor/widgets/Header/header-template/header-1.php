<header id="ed-header" class="ed-header-section header_style_one txa_sticky_header">
    <div class="ed-header-content d-flex align-items-center justify-content-between">
        <div class="logo-action d-flex align-items-center">
            <div class="brand-logo">
                <a href="<?php echo esc_url(home_url());?>" aria-label="name">
                    <img class="logo_site-size" src="<?php echo esc_url($settings['rzlogo']['url']);?>" alt="<?php if(!empty($settings['rzlogo']['alt'])){ echo esc_attr($settings['rzlogo']['alt']);}?>">
                </a>
            </div>
            <div class="action-select header-slct ed-option">
                <select>
                    <option value="#"><?php esc_html_e('Our All Courses', 'edrio-plugin'); ?></option>
                    <?php
                    // Get all TutorLMS course categories
                    $course_categories = get_terms(array(
                        'taxonomy' => 'course-category',
                        'hide_empty' => true,
                    ));

                    // Loop through each category and output as option
                    if (!empty($course_categories) && !is_wp_error($course_categories)) {
                        foreach ($course_categories as $category) {
                            echo '<option value="' . get_term_link($category) . '">' . $category->name . '</option>';
                        }
                    }
                    ?>
                </select>
            </div>
        </div>
        <div class="header-navigation-cta d-flex align-items-center">
            <nav class="main-navigation clearfix ul-li">
                <?php
                    echo str_replace(['menu-item-has-children', 'sub-menu'], ['dropdown', 'dropdown-menu clearfix'], wp_nav_menu( array(
                        'echo'           => false,
                        'menu' => !empty($settings['choose-menu']) ? $settings['choose-menu'] : 'menu-1',
                        'menu_id'        =>'main-nav',
                        'menu_class'        =>'nav navbar-nav clearfix',
                        'container'=>false,
                        'fallback_cb'    => 'Navwalker_Class::fallback',
                        'walker'         => class_exists( 'Rs_Mega_Menu_Walker' ) ? new \Rs_Mega_Menu_Walker : '',
                    )) );
                ?>
            </nav>
                <div class="cart-btn d-flex align-items-center">
                    <?php if($settings['cart_count'] === 'yes'):?>
                        <button class="hd-cart header-cart-btn"><i class="fa-solid fa-cart-shopping"></i></button>
                    <?php endif;?>
                    <?php if(!empty($settings['btn_label'])):?>
                    <div class="header-cta-btn btn-spin">
                        <a <?php echo $this->get_render_attribute_string( 'btn_link' ); ?>><?php echo edrio_wp_kses($settings['btn_label']);?></a>
                    </div>
                    <?php endif;?>
                </div>
            <button class="agt-mobile-menu-btn mobile_menu_button open_mobile_menu">
                <i class="fa-solid fa-bars"></i>
            </button>
        </div>
    </div>
</header>
<?php $this->mobile_menu(); $this->mini_cart_bar(); ?>