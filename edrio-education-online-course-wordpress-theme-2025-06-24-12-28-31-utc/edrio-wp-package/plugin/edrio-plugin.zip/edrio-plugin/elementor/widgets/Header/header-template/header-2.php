<header id="ed-header" class="ed-header-section header_style_two txa_sticky_header">
    <?php if($settings['top_hide'] === 'yes'):?>
    <div class="ed-header-top">
        <div class="container">
            <div class="header-top-content d-flex justify-content-between align-items-center">
                <?php if(!empty($settings['infos'])):?>
                    <div class="top-cta">
                        <?php foreach($settings['infos'] as $item):?>    
                            <a href="<?php echo esc_url($item['link']['url']);?>">
                                <?php \Elementor\Icons_Manager::render_icon( $item['icon'], [ 'aria-hidden' => 'true' ] ); ?> 
                                <?php echo edrio_wp_kses($item['info_text'])?></a>
                        <?php endforeach;?>
                    </div>
                <?php endif;?>
                <?php if(!empty($settings['header_socials'])):?>
                    <div class="top-social">
                        <?php foreach($settings['header_socials'] as $item):?>    
                            <a href="<?php echo esc_url($item['link']['url']);?>"><?php \Elementor\Icons_Manager::render_icon( $item['icon'], [ 'aria-hidden' => 'true' ] ); ?> </a>
                        <?php endforeach;?>
                    </div>
                <?php endif;?>
            </div>
        </div>
    </div>
    <?php endif;?>
    <div class="ed-header-navigation">
        <div class="container">
            <div class="header-nav-cta d-flex align-items-center justify-content-between">
                <div class="brand-logo">
                    <a href="<?php echo esc_url(home_url());?>" aria-label="name">
                        <img class="logo_site-size" src="<?php echo esc_url($settings['rzlogo']['url']);?>" alt="<?php if(!empty($settings['rzlogo']['alt'])){ echo esc_attr($settings['rzlogo']['alt']);}?>">
                    </a>
                </div>
                <nav class="main-navigation clearfix ul-li">
                    <?php
                        echo str_replace(['menu-item-has-children', 'sub-menu'], ['dropdown', 'dropdown-menu clearfix'], wp_nav_menu( array(
                            'echo'           => false,
                            'menu' => !empty($settings['choose-menu']) ? $settings['choose-menu'] : 'menu-1',
                            'menu_id'        =>'main-nav',
                            'menu_class'        =>'nav navbar-nav clearfix',
                            'container'=>false,
                            'fallback_cb'    => 'Navwalker_Class::fallback',
                            'walker'         => class_exists( 'Rs_Mega_Menu_Walker' ) ? new \Rs_Mega_Menu_Walker : '',
                        )) );
                    ?>
                </nav>
                <div class="header-action d-flex align-items-center">
                <?php if($settings['sear_hide_show'] === 'yes'):?>
                    <button class="ed-search-trigger search_btn_toggle"><i class="fa-solid fa-magnifying-glass"></i></button>
                <?php endif;?>
                    <?php if($settings['cart_count'] === 'yes'):?>
                    <button class="ed-cart-trigger header-cart-btn">
                        <i class="fa-solid fa-cart-shopping"></i> 
                        <span class="cart-contents-count">
                            <?php 
                            if (function_exists('WC') && WC()->cart && !is_admin() && !wp_doing_ajax()) {
                                echo WC()->cart->get_cart_contents_count();
                            } else {
                                echo '0';
                            }
                            ?>
                        </span>
                    </button>
                <?php endif;?>
                    <?php if(!empty($settings['btn_label'])):?>
                        <button data-bs-toggle="modal" data-bs-target="#exampleModal" class="ed-login-trigger"><?php echo edrio_wp_kses($settings['btn_label']);?></button>
                    <?php endif;?>
                    <div class="offcanvas-trigger navSidebar-button">
                        <button>
                            <span></span>
                            <span></span>
                            <span></span>
                            <span></span>
                            <span></span>
                            <span></span>
                            <span></span>
                            <span></span>
                            <span></span>
                        </button>
                    </div>
                    <button class="agt-mobile-menu-btn mobile_menu_button open_mobile_menu">
                        <i class="fa-solid fa-bars"></i>
                    </button>
                </div>
            </div>
        </div>
    </div>
    </header>
    <?php $this->mobile_menu(); $this->mini_cart_bar(); $this->___search_body(); ?>