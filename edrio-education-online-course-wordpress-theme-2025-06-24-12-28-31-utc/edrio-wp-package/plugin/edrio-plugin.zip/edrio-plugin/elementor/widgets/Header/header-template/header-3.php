<header id="ed-header" class="ed-header-section header_style_three txa_sticky_header">
  	<div class="ed-header-content d-flex justify-content-between align-items-center">
  		<div class="brand-logo">
            <a href="<?php echo esc_url(home_url());?>" aria-label="name">
                <img class="logo_site-size" src="<?php echo esc_url($settings['rzlogo']['url']);?>" alt="<?php if(!empty($settings['rzlogo']['alt'])){ echo esc_attr($settings['rzlogo']['alt']);}?>">
            </a>
  		</div>
  		<nav class="main-navigation clearfix ul-li">
          <?php
                echo str_replace(['menu-item-has-children', 'sub-menu'], ['dropdown', 'dropdown-menu clearfix'], wp_nav_menu( array(
                    'echo'           => false,
                    'menu' => !empty($settings['choose-menu']) ? $settings['choose-menu'] : 'menu-1',
                    'menu_id'        =>'main-nav',
                    'menu_class'        =>'nav navbar-nav clearfix',
                    'container'=>false,
                    'fallback_cb'    => 'Navwalker_Class::fallback',
                    'walker'         => class_exists( 'Rs_Mega_Menu_Walker' ) ? new \Rs_Mega_Menu_Walker : '',
                )) );
            ?>
  		</nav>
  		<div class="header-action d-flex align-items-center">
                <?php if($settings['sear_hide_show'] === 'yes'):?>
                    <button class="ed-search-trigger search_btn_toggle"><i class="fa-solid fa-magnifying-glass"></i></button>
                <?php endif;?>
              <?php if(!empty($settings['header_socials'])):?>
                <div class="header-social d-flex">
                    <?php foreach($settings['header_socials'] as $item):?>    
                        <a href="<?php echo esc_url($item['link']['url']);?>"><?php \Elementor\Icons_Manager::render_icon( $item['icon'], [ 'aria-hidden' => 'true' ] ); ?> </a>
                    <?php endforeach;?>
                </div>
                <?php endif;?>
                <?php if(!empty($settings['btn_label'])):?>
                    <div class="ed-head-btn">
                        <a <?php echo $this->get_render_attribute_string( 'btn_link' ); ?>><span data-back="<?php echo edrio_wp_kses($settings['btn_label']);?>" data-front="<?php echo edrio_wp_kses($settings['btn_label']);?>"></span> 
                            <?php if(!empty($settings['btn_shape']['url'])):?>
                                <img src="<?php echo esc_url($settings['btn_shape']['url']);?>" alt="<?php if(!empty($settings['btn_shape']['alt'])){ echo esc_attr($settings['btn_shape']['alt']);}else{esc_attr_e('About Image', 'edrio-plugin');}?>">
                            <?php endif;?>
                        </a>
                    </div>
                <?php endif;?>
  			<button class="agt-mobile-menu-btn mobile_menu_button open_mobile_menu">
  				<i class="fa-solid fa-bars"></i>
  			</button>
  		</div>
  	</div>
  </header>
  <?php $this->mobile_menu(); $this->mini_cart_bar(); $this->___search_body(); ?>