<header id="ed-header" class="ed-header-section header_style_four txa_sticky_header">
  	<div class="ed-header-content d-flex align-items-center justify-content-between">
  		<div class="brand-logo">
  			<a href="<?php echo esc_url(home_url());?>">
              <img class="logo_site-size" src="<?php echo esc_url($settings['rzlogo']['url']);?>" alt="<?php if(!empty($settings['rzlogo']['alt'])){ echo esc_attr($settings['rzlogo']['alt']);}?>">
            </a>
  		</div>
  		<div class="header-action d-flex align-items-center">
		  <?php if ( class_exists( 'WooCommerce' ) && function_exists( 'WC' ) && $settings['cart_count'] === 'yes' ) : ?>
			<?php
				$cart = WC()->cart;
				$cart_count = ( $cart && method_exists( $cart, 'get_cart_contents_count' ) ) ? $cart->get_cart_contents_count() : 0;
				$cart_total = ( $cart && method_exists( $cart, 'get_cart_total' ) ) ? $cart->get_cart_total() : wc_price( 0 );
			?>
				<div class="shop-btn">
					<button class="ed-cart-trigger header-cart-btn"><i class="fa-solid fa-cart-shopping"></i> <span><?php echo esc_html( $cart_count ); ?></span> Cart</button>
				</div>
			<?php endif;?>
			<?php if(!empty($settings['login_text']) || !empty($settings['reg_text'])):?>
				<div class="sign-up-in">
					<button data-bs-toggle="modal" data-bs-target="#exampleModal" class="ed-login-trigger"><?php echo edrio_wp_kses($settings['login_text'])?></button>
					<button data-bs-toggle="modal" data-bs-target="#exampleModal" class="ed-login-trigger"><?php echo edrio_wp_kses($settings['reg_text'])?></button>
				</div>
			<?php endif;?>
			<?php if(!empty($settings['btn_label'])):?>
				<div class="action-btn">
					<a <?php echo $this->get_render_attribute_string( 'btn_link' ); ?>><?php echo edrio_wp_kses($settings['btn_label']);?></a>
				</div>
			<?php endif;?>
  			<div class="offcanvas-trigger navSidebar-button  open_mobile_menu">
  				<button>
  					<span></span>
  					<span></span>
  					<span></span>
  					<span></span>
  				</button>
  			</div>
  		</div>
  	</div>
  </header>

  <?php $this->mobile_menu(); $this->mini_cart_bar(); $this->___search_body(); ?>