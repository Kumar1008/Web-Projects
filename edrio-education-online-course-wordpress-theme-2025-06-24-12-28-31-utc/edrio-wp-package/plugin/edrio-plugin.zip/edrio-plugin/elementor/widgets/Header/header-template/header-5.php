<header id="ed-header" class="ed-header-section header_style_five txa_sticky_header">
  	<div class="ed-header-top">
  		<div class="container">
  			<div class="top-info-social d-flex justify-content-between align-items-center ul-li">
                <?php if(!empty($settings['infos'])):?>
                    <ul>
                        <?php foreach($settings['infos'] as $item):?>  
                            <li><a href="<?php echo esc_url($item['link']['url']);?>"> <?php echo edrio_wp_kses($item['info_text'])?></a></li>
                        <?php endforeach;?>
                    </ul>
                <?php endif;?>
                  <?php if(!empty($settings['header_socials'])):?>
                    <div class="social-icon">
                        <div class="top-social">
                            <?php foreach($settings['header_socials'] as $item):?>    
                                <a href="<?php echo esc_url($item['link']['url']);?>"><?php \Elementor\Icons_Manager::render_icon( $item['icon'], [ 'aria-hidden' => 'true' ] ); ?> </a>
                            <?php endforeach;?>
                        </div>
                    </div>
                <?php endif;?>
  			</div>
  		</div>
  	</div>
  	<div class="ed-header-navigation-wrap">
  		<div class="container">
  			<div class="ed-header-navigation d-flex justify-content-between align-items-center">
  				<div class="brand-logo">
                  <a href="<?php echo esc_url(home_url());?>">
                    <img class="logo_site-size" src="<?php echo esc_url($settings['rzlogo']['url']);?>" alt="<?php if(!empty($settings['rzlogo']['alt'])){ echo esc_attr($settings['rzlogo']['alt']);}?>">
                </a>
  				</div>
  				<nav class="main-navigation clearfix ul-li">
                  <?php
                    echo str_replace(['menu-item-has-children', 'sub-menu'], ['dropdown', 'dropdown-menu clearfix'], wp_nav_menu( array(
                        'echo'           => false,
                        'menu' => !empty($settings['choose-menu']) ? $settings['choose-menu'] : 'menu-1',
                        'menu_id'        =>'main-nav',
                        'menu_class'        =>'nav navbar-nav clearfix',
                        'container'=>false,
                        'fallback_cb'    => 'Navwalker_Class::fallback',
                        'walker'         => class_exists( 'Rs_Mega_Menu_Walker' ) ? new \Rs_Mega_Menu_Walker : '',
                    )) );
                ?>
  				</nav>
  				<div class="hd-cta-btn-wrap d-flex align-items-center">
                    <?php if(!empty($settings['btn_label'])):?>
  					<div class="hd-cta-btn">
  						<a <?php echo $this->get_render_attribute_string( 'btn_link' ); ?>><?php echo edrio_wp_kses($settings['btn_label']);?></a>
  					</div>
                      <?php endif;?>
  					<button class="agt-mobile-menu-btn mobile_menu_button open_mobile_menu">
  						<i class="fa-solid fa-bars"></i>
  					</button>
  				</div>
  			</div>
  		</div>
  	</div>
  </header>
  <?php $this->mobile_menu(); $this->mini_cart_bar(); $this->___search_body(); ?>