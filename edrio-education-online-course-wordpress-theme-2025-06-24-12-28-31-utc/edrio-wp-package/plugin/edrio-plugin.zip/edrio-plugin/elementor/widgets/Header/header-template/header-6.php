<header id="ed-header" class="ed-header-section header_style_six txa_sticky_header">
<div class="ed-top-header-wrap">
    <div class="container">
        <div class="ed-top-header-content d-flex align-items-center justify-content-between">
            <div class="ed-top-search-bar d-flex align-items-center">
                <div class="brand-logo">
                    <a href="<?php echo esc_url(home_url());?>">
                        <img class="logo_site-size" src="<?php echo esc_url($settings['rzlogo']['url']);?>" alt="<?php if(!empty($settings['rzlogo']['alt'])){ echo esc_attr($settings['rzlogo']['alt']);}?>">
                    </a>
                </div>
                <div class="ed-hd-search-bar">
                    <form action="<?php echo esc_url(home_url('/')); ?>" method="get">
                        <div class="action-select ed-option">
                            <select name="course_cat">
                                <option value="">All Categories</option>
                                <?php
                                $course_cats = get_terms(array(
                                    'taxonomy' => 'course-category', // Default taxonomy used by Tutor LMS
                                    'hide_empty' => false,
                                ));
                                if (!empty($course_cats) && !is_wp_error($course_cats)) {
                                    foreach ($course_cats as $cat) {
                                        echo '<option value="' . esc_attr($cat->slug) . '">' . esc_html($cat->name) . '</option>';
                                    }
                                }
                                ?>
                            </select>
                        </div>
                        <div class="search_icon">
                            <i class="fa-solid fa-magnifying-glass"></i>
                        </div>
                        <input type="text" name="s" placeholder="Search here ..." />
                        <input type="hidden" name="post_type" value="courses" />
                        <button type="submit">Search</button>
                    </form>
                </div>

            </div>
            <div class="ed-top-action position-relative d-flex align-items-center">
                <?php if($settings['call_no'] || !empty($settings['call_title'])):?>
                <div class="top-act-item d-flex align-items-center">
                    <div class="item-text">
                        <span><?php echo edrio_wp_kses($settings['call_title'])?></span>
                        <a href="tel:<?php echo esc_attr($settings['call_no']);?>"><?php echo esc_html($settings['call_no']);?></a>
                    </div>
                    <div class="item-icon d-flex align-items-center justify-content-center">
                        <svg width="16" height="16" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <g clip-path="url(#clip0_261_279)">
                                <path d="M12.6451 9.91143C12.3176 9.57036 11.9225 9.38801 11.5037 9.38801C11.0884 9.38801 10.6899 9.56699 10.3488 9.90806L9.28172 10.9718C9.19392 10.9245 9.10612 10.8806 9.0217 10.8367C8.90013 10.7759 8.78532 10.7185 8.68739 10.6577C7.68782 10.0229 6.77943 9.19553 5.90819 8.12505C5.48608 7.5915 5.20242 7.14237 4.99643 6.68648C5.27333 6.43322 5.52998 6.16982 5.77987 5.91655C5.87442 5.82199 5.96898 5.72406 6.06353 5.62951C6.77268 4.92036 6.77268 4.00184 6.06353 3.29269L5.14163 2.37079C5.03695 2.26611 4.92889 2.15805 4.82758 2.04999C4.62497 1.84062 4.41222 1.6245 4.19272 1.42188C3.86516 1.0977 3.47344 0.925476 3.06146 0.925476C2.64947 0.925476 2.251 1.0977 1.91331 1.42188C1.90993 1.42526 1.90993 1.42526 1.90655 1.42864L0.758404 2.58692C0.326159 3.01916 0.0796448 3.54596 0.0256142 4.15718C-0.0554316 5.14324 0.234983 6.06176 0.457859 6.66284C1.00492 8.13855 1.82213 9.5062 3.04119 10.9718C4.52028 12.7379 6.29991 14.1326 8.33281 15.1152C9.1095 15.4833 10.1462 15.919 11.3045 15.9932C11.3754 15.9966 11.4497 16 11.5172 16C12.2973 16 12.9524 15.7197 13.4657 15.1625C13.4691 15.1558 13.4758 15.1524 13.4792 15.1456C13.6548 14.9329 13.8574 14.7404 14.0702 14.5344C14.2154 14.396 14.364 14.2508 14.5092 14.0988C14.8435 13.751 15.0191 13.3457 15.0191 12.9304C15.0191 12.5117 14.8401 12.1098 14.499 11.7721L12.6451 9.91143ZM13.8541 13.4673C13.8507 13.4673 13.8507 13.4707 13.8541 13.4673C13.7224 13.6091 13.5873 13.7375 13.4421 13.8793C13.2226 14.0887 12.9997 14.3082 12.7903 14.5547C12.4493 14.9194 12.0474 15.0916 11.5206 15.0916C11.47 15.0916 11.4159 15.0916 11.3653 15.0882C10.3623 15.0241 9.43031 14.6324 8.73129 14.298C6.81996 13.3728 5.14163 12.0591 3.74697 10.3943C2.59544 9.00642 1.82551 7.72319 1.31559 6.34542C1.00154 5.50457 0.886726 4.84944 0.93738 4.23147C0.971149 3.83637 1.12311 3.50881 1.40339 3.22853L2.55492 2.077C2.72039 1.92166 2.89599 1.83724 3.06821 1.83724C3.28096 1.83724 3.45318 1.96556 3.56124 2.07363C3.56462 2.077 3.56799 2.08038 3.57137 2.08376C3.77736 2.27624 3.97322 2.47548 4.17921 2.68822C4.2839 2.79628 4.39196 2.90435 4.50002 3.01578L5.42192 3.93768C5.77987 4.29563 5.77987 4.62657 5.42192 4.98452C5.32399 5.08245 5.22943 5.18038 5.1315 5.27493C4.84784 5.56535 4.57769 5.8355 4.2839 6.0989C4.27714 6.10565 4.27039 6.10903 4.26701 6.11579C3.9766 6.4062 4.03063 6.68986 4.09141 6.88234C4.09479 6.89247 4.09817 6.90261 4.10154 6.91274C4.3413 7.49356 4.679 8.04062 5.19229 8.69237L5.19566 8.69574C6.12769 9.84389 7.11037 10.7388 8.19436 11.4243C8.33281 11.5121 8.47464 11.583 8.60972 11.6505C8.73129 11.7113 8.8461 11.7687 8.94403 11.8295C8.95754 11.8363 8.97105 11.8464 8.98456 11.8532C9.09937 11.9106 9.20743 11.9376 9.31887 11.9376C9.59915 11.9376 9.77475 11.762 9.83216 11.7046L10.9871 10.5497C11.1019 10.4349 11.2842 10.2964 11.497 10.2964C11.7063 10.2964 11.8786 10.4281 11.9833 10.5429C11.9866 10.5463 11.9866 10.5463 11.99 10.5497L13.8507 12.4103C14.1985 12.7548 14.1985 13.1094 13.8541 13.4673Z" fill="#050505"/>
                                <path d="M8.64869 3.80598C9.53344 3.95456 10.3371 4.3733 10.9788 5.01491C11.6204 5.65653 12.0357 6.46023 12.1877 7.34498C12.2248 7.56786 12.4173 7.72319 12.6368 7.72319C12.6638 7.72319 12.6875 7.71982 12.7145 7.71644C12.9644 7.67592 13.1298 7.43953 13.0893 7.18964C12.907 6.11916 12.4004 5.14324 11.6271 4.36992C10.8538 3.59661 9.87788 3.09008 8.8074 2.90772C8.55751 2.8672 8.3245 3.03267 8.2806 3.27918C8.2367 3.5257 8.3988 3.76546 8.64869 3.80598Z" fill="#050505"/>
                                <path d="M15.9829 7.05794C15.6823 5.2952 14.8516 3.69116 13.5751 2.41469C12.2986 1.13822 10.6946 0.307501 8.93186 0.0069559C8.68535 -0.0369439 8.45234 0.131902 8.40844 0.378416C8.36792 0.628307 8.53339 0.861314 8.78328 0.905214C10.3569 1.17199 11.7921 1.91829 12.9335 3.05631C14.0749 4.1977 14.8178 5.63289 15.0846 7.20653C15.1217 7.4294 15.3142 7.58474 15.5337 7.58474C15.5607 7.58474 15.5844 7.58136 15.6114 7.57799C15.8579 7.54084 16.0268 7.30446 15.9829 7.05794Z" fill="#050505"/>
                            </g>
                            <defs>
                                <clipPath id="clip0_261_279">
                                    <rect width="16" height="16" fill="white"/>
                                </clipPath>
                            </defs>
                        </svg>
                    </div>
                </div>
                <?php endif;?>
                <?php if ( class_exists( 'WooCommerce' ) && function_exists( 'WC' ) && $settings['cart_count'] === 'yes' ) : ?>
                    <?php
                    $cart = WC()->cart;
                    $cart_count = ( $cart && method_exists( $cart, 'get_cart_contents_count' ) ) ? $cart->get_cart_contents_count() : 0;
                    $cart_total = ( $cart && method_exists( $cart, 'get_cart_total' ) ) ? $cart->get_cart_total() : wc_price( 0 );
                    ?>
                    <div class="top-act-item d-flex align-items-center header-cart-btn" id="header-cart">
                        <div class="item-icon d-flex align-items-center justify-content-center">
                            <!-- Your SVG stays the same -->
                            <svg width="16" height="16" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg">
                                <path d="M11.9016 15H4.10156C2.45156 15 1.10156 13.65 1.10156 12V11.9L1.40156 3.9C1.45156 2.25 2.80156 1 4.40156 1H11.6016C13.2016 1 14.5516 2.25 14.6016 3.9L14.9016 11.9C14.9516 12.7 14.6516 13.45 14.1016 14.05C13.5516 14.65 12.8016 15 12.0016 15C12.0016 15 11.9516 15 11.9016 15ZM4.40156 2C3.30156 2 2.45156 2.85 2.40156 3.9L2.10156 12C2.10156 13.1 3.00156 14 4.10156 14H12.0016C12.5516 14 13.0516 13.75 13.4016 13.35C13.7516 12.95 13.9516 12.45 13.9516 11.9L13.6516 3.9C13.6016 2.8 12.7516 2 11.6516 2H4.40156Z" fill="#050505"/>
                                <path d="M8 7C6.05 7 4.5 5.45 4.5 3.5C4.5 3.2 4.7 3 5 3C5.3 3 5.5 3.2 5.5 3.5C5.5 4.9 6.6 6 8 6C9.4 6 10.5 4.9 10.5 3.5C10.5 3.2 10.7 3 11 3C11.3 3 11.5 3.2 11.5 3.5C11.5 5.45 9.95 7 8 7Z" fill="#050505"/>
                            </svg>
                            <span class="cart-count"><?php echo esc_html( $cart_count ); ?></span>
                        </div>
                        <div class="item-text">
                            <span><?php _e('Your Cart', 'edrio-plugin')?></span>
                            <a href="<?php echo esc_url( wc_get_cart_url() ); ?>" class="cart-total">
                                <?php echo wp_kses_post( $cart_total ); ?>
                            </a>
                        </div>
                    </div>
                <?php endif; ?>


            </div>
            <button class="agt-mobile-menu-btn mobile_menu_button open_mobile_menu">
                <i class="fa-solid fa-bars"></i>
            </button>
        </div>
    </div>
</div>
<div class="ed-header-navigation">
    <div class="container">
        <div class="header-navigation-wrap d-flex align-items-center justify-content-between">
            <nav class="main-navigation clearfix ul-li">
                <?php
                    echo str_replace(['menu-item-has-children', 'sub-menu'], ['dropdown', 'dropdown-menu clearfix'], wp_nav_menu( array(
                        'echo'           => false,
                        'menu' => !empty($settings['choose-menu']) ? $settings['choose-menu'] : 'menu-1',
                        'menu_id'        =>'main-nav',
                        'menu_class'        =>'nav navbar-nav clearfix',
                        'container'=>false,
                        'fallback_cb'    => 'Navwalker_Class::fallback',
                        'walker'         => class_exists( 'Rs_Mega_Menu_Walker' ) ? new \Rs_Mega_Menu_Walker : '',
                    )) );
                ?>
            </nav>
            <div class="hd-login-btn d-flex align-items-center">
                <?php if(!empty($settings['login_text']) || !empty($settings['reg_text'])):?>
                    <div class="login-signup">
                        <button><?php echo edrio_wp_kses($settings['login_text'])?></button>
                        <button><?php echo edrio_wp_kses($settings['reg_text'])?></button>
                    </div>
                <?php endif;?>
                <?php if(!empty($settings['btn_label'])):?>
                    <div class="cta-btn">
                        <a <?php echo $this->get_render_attribute_string( 'btn_link' ); ?>><?php echo edrio_wp_kses($settings['btn_label']);?></a>
                    </div>
                <?php endif;?>
            </div>
        </div>
    </div>
</div>
</header>
<?php $this->mobile_menu(); $this->mini_cart_bar(); $this->___search_body(); ?>