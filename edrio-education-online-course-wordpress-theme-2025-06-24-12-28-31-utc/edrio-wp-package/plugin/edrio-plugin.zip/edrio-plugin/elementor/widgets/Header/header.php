<?php

/**
 * Elementor Single Widget
 * @package edrio Tools
 * @since 1.0.0
 */

namespace Elementor;

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly.

class Edrio_Header extends Widget_Base {

	/**
	 * Get widget name.
	 *
	 * Retrieve Elementor widget name.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget name.
	 */
	public function get_name() {
		return 'edrio-header-1';
	}

	/**
	 * Get widget title.
	 *
	 * Retrieve Elementor widget title.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget title.
	 */
	public function get_title() {
		return esc_html__( 'Edrio Header', 'edrio-plugin' );
	}

	/**
	 * Get widget icon.
	 *
	 * Retrieve Elementor widget icon.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget icon.
	 */
	public function get_icon() {
		return 'edrio-custom-icon';
	}

	/**
	 * Get widget categories.
	 *
	 * Retrieve the list of categories the Elementor widget belongs to.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return array Widget categories.
	 */
	public function get_categories() {
		return [ 'edrio_widgets' ];
	}


	protected function register_controls() {
		$this->start_controls_section(
			'__header__style__',
			[
				'label' => esc_html__( 'Header Style Select', 'edrio-plugin' ),
				'tab'   => Controls_Manager::TAB_CONTENT,
			]
		);
        $this->add_control(
			'style',
			[
				'label' => esc_html__( 'Style', 'edrio-plugin' ),
				'type' => \Elementor\Controls_Manager::SELECT,
				'default' => '1',
				'options' => [
					'1'  => esc_html__( 'Style 1', 'edrio-plugin' ),
					'2'  => esc_html__( 'Style 2', 'edrio-plugin' ),
					'3'  => esc_html__( 'Style 3', 'edrio-plugin' ),
					'4'  => esc_html__( 'Style 4', 'edrio-plugin' ),
					'5'  => esc_html__( 'Style 5', 'edrio-plugin' ),
					'6'  => esc_html__( 'Style 6', 'edrio-plugin' )
				]
			]
		);
		
        $this->end_controls_section();

		$this->start_controls_section(
			'header__general',
			[
				'label' => esc_html__( 'Header General Option', 'edrio-plugin' ),
				'tab'   => Controls_Manager::TAB_CONTENT,
			]
		);
		
		$this->add_control(
			'top_hide',
			[
				'label' => esc_html__( 'Header Top Hide', 'eergx-plugin' ),
				'type' => \Elementor\Controls_Manager::SWITCHER,
				'label_on' => esc_html__( 'Show', 'eergx-plugin' ),
				'label_off' => esc_html__( 'Hide', 'eergx-plugin' ),
				'return_value' => 'yes',
				'default' => 'yes',
				'condition' => [
					'style' => ['2'],
				],
			]
		);
		
		$this->add_control(
			'cart_count',
			[
				'label' => esc_html__( 'Cart Count Hide', 'eergx-plugin' ),
				'type' => \Elementor\Controls_Manager::SWITCHER,
				'label_on' => esc_html__( 'Show', 'eergx-plugin' ),
				'label_off' => esc_html__( 'Hide', 'eergx-plugin' ),
				'return_value' => 'yes',
				'default' => 'yes',
				'condition' => [
					'style' => ['1', '2', '4', '6'],
				],
			]
		);
		$this->add_control(
			'sear_hide_show',
			[
				'label' => esc_html__( 'Search HIDE/SHOW', 'edrio-plugin' ),
				'type' => \Elementor\Controls_Manager::SWITCHER,
				'label_on' => esc_html__( 'Show', 'edrio-plugin' ),
				'label_off' => esc_html__( 'Hide', 'edrio-plugin' ),
				'return_value' => 'yes',
				'default' => 'yes',
                'condition' => [
                    'style' => ['2', '3', '4', '5'],
                ]
			]
		);

		$this->add_control(
			'search_btn_label', [
				'label' => esc_html__( 'Search Button Label', 'edrio-plugin' ),
				'default' => esc_html__( 'search here...', 'edrio-plugin' ),
				'type' => Controls_Manager::TEXT,
                'label_block' => true,
				'condition' => [
					'sear_hide_show' => 'yes',
                    'style' => ['2', '3', '4', '5'],
				],
			]
		);
		
		$this->add_control(
			'call_title', [
				'label' => esc_html__( 'Call Title', 'edrio-plugin' ),
				'default' => esc_html__( 'Call Us Now:', 'edrio-plugin' ),
				'type' => Controls_Manager::TEXT,
                'label_block' => true,
				'condition' => [
                    'style' => ['6'],
				],
			]
		);
		$this->add_control(
			'call_no', [
				'label' => esc_html__( 'Call No', 'edrio-plugin' ),
				'default' => esc_html__( '(145) 258 695 456', 'edrio-plugin' ),
				'type' => Controls_Manager::TEXT,
                'label_block' => true,
				'condition' => [
                    'style' => ['6'],
				],
			]
		);

		$this->add_control(
			'btn_label', [
				'label' => esc_html__( 'Header Button Label', 'edrio-plugin' ),
				'default' => esc_html__( 'request a quote', 'edrio-plugin' ),
				'type' => Controls_Manager::TEXT,
                'label_block' => true,
			]
		);
		$this->add_control(
			'btn_shape', [
				'label' => esc_html__( 'Button Shape', 'edrio-plugin' ),
				'type' => Controls_Manager::MEDIA,
				'condition' => [
					'style!' => '6',
				],
			]
		);
		$this->add_control(
			'btn_link', [
				'label' => esc_html__( 'Header Button Link', 'edrio-plugin' ),
				'type' => Controls_Manager::URL,
                'label_block' => true,
				'condition' => [
					'style!' => '2',
				],
			]
		);
		$this->add_control(
			'login_text', [
				'label' => esc_html__( 'Login Text', 'edrio-plugin' ),
				'type' => Controls_Manager::TEXT,
				'condition' => [
					'style' => ['6', '4'],
				],
			]
		);
		$this->add_control(
			'reg_text', [
				'label' => esc_html__( 'Registration Text', 'edrio-plugin' ),
				'type' => Controls_Manager::TEXT,
				'condition' => [
					'style' => ['6', '4'],
				],
			]
		);
		$repeater = new \Elementor\Repeater();

        $repeater->add_control(
			'icon', [
				'label' => esc_html__( 'Icon', 'edrio-plugin' ),
				'type' => Controls_Manager::ICONS,
                'label_block' => true,
			]
		);
        
        $repeater->add_control(
			'info_text', [
				'label' => esc_html__( 'Info Text', 'edrio-plugin' ),
				'default' => esc_html__( 'info@edrio.com', 'edrio-plugin' ),
				'type' => Controls_Manager::TEXT,
                'label_block' => true,
			]
		);
        
        $repeater->add_control(
			'link', [
				'label' => esc_html__( 'Link', 'edrio-plugin' ),
				'type' => Controls_Manager::URL,
                'label_block' => true,
			]
		);

        $this->add_control(
			'infos',
			[
				'label' => esc_html__( 'Add Header Contact Item', 'edrio-plugin' ),
				'type' => \Elementor\Controls_Manager::REPEATER,
				'fields' => $repeater->get_controls(),
				'title_field' => '{{{ info_text }}}',
				'condition' => [
					'style' => ['2', '5'],
				],
			]
		);
		
		$repeater = new \Elementor\Repeater();

        $repeater->add_control(
			'icon', [
				'label' => esc_html__( 'Icon', 'edrio-plugin' ),
				'type' => Controls_Manager::ICONS,
                'label_block' => true,
			]
		);
        
        
        $repeater->add_control(
			'link', [
				'label' => esc_html__( 'Link', 'edrio-plugin' ),
				'type' => Controls_Manager::URL,
                'label_block' => true,
			]
		);

        $this->add_control(
			'header_socials',
			[
				'label' => esc_html__( 'Add Social Icon Item', 'edrio-plugin' ),
				'type' => \Elementor\Controls_Manager::REPEATER,
				'fields' => $repeater->get_controls(),
				'condition' => [
					'style' => ['2', '3', '5'],
				],
			]
		);
		
		$this->end_controls_section();
		
        $this->start_controls_section(
			'logoop',
			[
				'label' => esc_html__( 'Logo Option', 'edrio-plugin' ),
				'tab'   => Controls_Manager::TAB_CONTENT,
			]
		);

		$this->add_control(
			'rzlogo', [
				'label' => esc_html__( 'Logo', 'edrio-plugin' ),
				'type' => Controls_Manager::MEDIA,
                'label_block' => true,
				'default'     => [
                    'url' => Utils::get_placeholder_image_src(),
                ],
			]
		);
		
		$this->add_responsive_control(
			'logo_max_width',
			[
				'label' => esc_html__( 'Max Width', 'edrio-plugin' ),
				'type' => \Elementor\Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%', 'em', 'rem', 'custom' ],
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 5000,
					]
				],

				'selectors' => [
					'{{WRAPPER}} .logo_site-size' => 'max-width: {{SIZE}}{{UNIT}};',
				],
			]
		);
		$this->add_control(
			'rzmlogo', [
				'label' => esc_html__( 'Mobile Logo', 'edrio-plugin' ),
				'type' => Controls_Manager::MEDIA,
                'label_block' => true,
				'default'     => [
                    'url' => Utils::get_placeholder_image_src(),
                ],
			]
		);
		
		$this->add_responsive_control(
			'm_logo_max_width',
			[
				'label' => esc_html__( 'Max Width', 'edrio-plugin' ),
				'type' => \Elementor\Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%', 'em', 'rem', 'custom' ],
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 5000,
					]
				],

				'selectors' => [
					'{{WRAPPER}} .logo_site-m-size' => 'max-width: {{SIZE}}{{UNIT}};',
				],
			]
		);
        
		$this->end_controls_section();

        $this->start_controls_section(
			'menu_select',
			[
				'label' => esc_html__( 'Menu Option', 'edrio-plugin' ),
				'tab'   => Controls_Manager::TAB_CONTENT,
			]
		);
		
		$this->add_control(
			'choose-menu',
			[
				'label' => esc_html__( 'Choose menu', 'edrio-plugin' ),
				'type' => \Elementor\Controls_Manager::SELECT2,
				'options' => edrio_menu_selector(),
				'multiple' => false
			]
		);

		$this->end_controls_section();
		
		$this->start_controls_section(
			'search_menu_options',
			[
				'label' => esc_html__( 'Search Option', 'edrio-plugin' ),
				'tab'   => Controls_Manager::TAB_CONTENT,
				'condition' => [
					'sear_hide_show' => 'yes',
				],
			]
		);
		$this->add_control(
			'search_title', [
				'label' => esc_html__( 'Search Title', 'edrio-plugin' ),
				'default' => esc_html__( 'Search', 'edrio-plugin' ),
				'type' => Controls_Manager::TEXT,
                'label_block' => true,
			]
		);
		$this->add_control(
			'search_link_title', [
				'label' => esc_html__( 'Search Link Title', 'edrio-plugin' ),
				'default' => esc_html__( 'People also search for:', 'edrio-plugin' ),
				'type' => Controls_Manager::TEXT,
                'label_block' => true,
			]
		);
		$repeater = new \Elementor\Repeater();
        $repeater->add_control(
			'title', [
				'label' => esc_html__( 'Title', 'edrio-plugin' ),
				'type' => Controls_Manager::TEXT,
                'label_block' => true,
			]
		);
        
        $repeater->add_control(
			'link', [
				'label' => esc_html__( 'Link', 'edrio-plugin' ),
				'type' => Controls_Manager::URL,
                'label_block' => true,
			]
		);

        $this->add_control(
			'search_link',
			[
				'label' => esc_html__( 'Add Search Link Item', 'edrio-plugin' ),
				'type' => \Elementor\Controls_Manager::REPEATER,
				'fields' => $repeater->get_controls(),
				'title_field' => '{{{ title }}}',
			]
		);
		$this->end_controls_section();

		$this->start_controls_section(
			'header-3__style',
			[
				'label' => esc_html__( 'Header Backgroud  Style', 'edrio-plugin' ),
				'tab'   => Controls_Manager::TAB_STYLE,
				'condition' => [
					'style' => ['3', '4', '5'],
				],
			]
		);
		$this->add_group_control(
			\Elementor\Group_Control_Background::get_type(),
			[
				'name' => 'header_bg_upload',
				'types' => [ 'classic' ],
				'exclude' => [ 'color' ],
				'selector' => '
					{{WRAPPER}} .fx-header-3-main,
					{{WRAPPER}} .fx-header-4-main::after,
					{{WRAPPER}} .fx-header-5-wrap::after
				',
                'fields_options' => [
                    'background' => [
                        'label' => esc_html__( 'Header BG Shape Upload', 'goyto-plugin' ),
                        'description' => esc_html__( 'Choose background type and style.', 'goyto-plugin' ),
                        'separator' => 'before',
                    ]
				],
				
			]
		);
		$this->add_control(
			'header_bg_color',
			[
				'label' => esc_html__( 'Header BG Color', 'goyto-plugin' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .agn-header-3-left' => 'background: {{VALUE}}',
					'{{WRAPPER}} .agn-header-search-form-input' => 'background: {{VALUE}}'
				],
				'condition' => [
					'style' => ['3'],
				],
			]
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'top_menu__style',
			[
				'label' => esc_html__( 'Menu Top Bar  Style', 'edrio-plugin' ),
				'tab'   => Controls_Manager::TAB_STYLE,
				'condition' => [
					'style' => ['3', '4', '5'],
				],
			]
		);
		$this->add_control(
			'tp_bar_bg',
			[
				'label' => esc_html__( 'Top Bar BG Option', 'textdomain' ),
				'type' => \Elementor\Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);
		$this->add_control(
			'top_bar_bg',
			[
				'label' => esc_html__( 'Top Bar Menu BG Color', 'edrio-plugin' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .fx-header-1-top' => 'background: {{VALUE}}'
				],
			]
		);
		$this->add_control(
			'tp_bar_text',
			[
				'label' => esc_html__( 'Top Info Option', 'textdomain' ),
				'type' => \Elementor\Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);
		
		$this->add_control(
			'top-info-hover',
			[
				'label' => esc_html__( 'Top Info Color', 'edrio-plugin' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .fx-contact-list li' => 'color: {{VALUE}}',
					'{{WRAPPER}} .fx-header-5-wrap .fx-contact-list li i' => 'color: {{VALUE}}'
				],
			]
		);
		
        $this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'top_info_fb_typography',
				'selector' => '
					{{WRAPPER}} .fx-contact-list li
				',
			]
		);
		$this->end_controls_section();

		$this->start_controls_section(
			'hamburg_menu_style',
			[
				'label' => esc_html__( 'Brand Color Style', 'edrio-plugin' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);
		$this->add_control(
			'br-bg-color',
			[
				'label' => esc_html__( 'Brand Color', 'edrio-plugin' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .arv__h1 .main-navigation .navbar-nav li:is(.dropdown) > a::before' => 'color: {{VALUE}}',
					'{{WRAPPER}} .ct-search-tag-item' => 'color: {{VALUE}}',
					'{{WRAPPER}} .arv__h1 .main-navigation .navbar-nav li:hover > a' => 'color: {{VALUE}}',
					'{{WRAPPER}} .ct-search-tag-item' => 'border-color: {{VALUE}}',
					'{{WRAPPER}} .ct-search-tag-item:hover' => 'background: {{VALUE}}',
					'{{WRAPPER}} .arv-header-1-side-btn' => 'background: {{VALUE}}'
				],
			]
		);
		$this->add_control(
			'br-box-bg-color',
			[
				'label' => esc_html__( 'Header BG Color', 'edrio-plugin' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .arv-header-1-area' => 'background: {{VALUE}}'
				],
				'condition' => [
					'style' => ['1'],
				],
			]
		);
		
		$this->add_group_control(
			\Elementor\Group_Control_Border::get_type(),
			[
				'name' => 'border',
				'selector' => '{{WRAPPER}} .arv-header-1-wrap',
				'condition' => [
					'style' => ['1'],
				],
			]
		);
		
		$this->end_controls_section();

		$this->start_controls_section(
			'menu_bar_style',
			[
				'label' => esc_html__( 'Menu  Style', 'edrio-plugin' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_control(
			'--menu--style-info',
			[
				'label' => esc_html__( 'Menu Style', 'edrio-plugin' ),
				'type' => \Elementor\Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);
		
        $this->add_control(
			'menu_color',
			[
				'label' => esc_html__( 'Menu Color', 'edrio-plugin' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .navbar-nav>li>a' => 'color: {{VALUE}} !important',
					'{{WRAPPER}} .navbar-nav>li>a:after' => 'color: {{VALUE}} !important'
				],
			]
		);
        $this->add_control(
			'menu_arrow_color',
			[
				'label' => esc_html__( 'Menu Arrow Color', 'edrio-plugin' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .navbar-nav li:is(.dropdown) > a::before' => 'color: {{VALUE}} !important'
				],
			]
		);
        $this->add_control(
			'menu_color-hover',
			[
				'label' => esc_html__( 'Menu Hover Color', 'edrio-plugin' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .navbar-nav>li>a:hover' => 'color: {{VALUE}} !important'
				],
			]
		);
        $this->add_control(
			'menu_sticky-hover',
			[
				'label' => esc_html__( 'Menu Sticky Color', 'edrio-plugin' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .txa_sticky .navbar-nav>li>a' => 'color: {{VALUE}} !important',
					'{{WRAPPER}} .txa_sticky .navbar-nav>li>a:after' => 'color: {{VALUE}} !important'
				],
			]
		);
		
        $this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'menu_fb_typography',
				'selector' => '
					{{WRAPPER}} .navbar-nav li a
				',
			]
		);
		$this->add_control(
			'menu_dropdown_style',
			[
				'label' => esc_html__( 'Menu Dropdown Style', 'edrio-plugin' ),
				'type' => \Elementor\Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);
		
        $this->add_control(
			'mdb_color',
			[
				'label' => esc_html__( 'Dropdown Box BG Color', 'edrio-plugin' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .main-navigation .navbar-nav li .dropdown-menu' => 'background: {{VALUE}}'
				],
			]
		);
        $this->add_control(
			'mdb_menu_color',
			[
				'label' => esc_html__( 'Dropdown Box Border Color', 'edrio-plugin' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .main-navigation .navbar-nav li .dropdown-menu' => 'border-color: {{VALUE}}'
				],
			]
		);

        $this->end_controls_section();
		$this->start_controls_section(
			'search_style',
			[
				'label' => esc_html__( 'Search  Style', 'edrio-plugin' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);

        $this->add_control(
			's-icon-color',
			[
				'label' => esc_html__( 'Search Icon Color', 'edrio-plugin' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .arv-header-1-action .search-btn .icon' => 'color: {{VALUE}} !important'
				],
			]
		);
        $this->add_control(
			'search-text-hover',
			[
				'label' => esc_html__( 'Search Text Color', 'edrio-plugin' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .arv-header-1-action .search-btn .text' => 'color: {{VALUE}} !important'
				],
			]
		);
		
        $this->end_controls_section();
		 // feature style
		 $this->start_controls_section(
			'--button_one',
			[
				'label' => esc_html__( 'Button Style', 'goyto-plugin' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);
        $this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name' => 'm_b_typography',
				'selector' => '{{WRAPPER}} .arv-btn-1',
			]
		);
        $this->add_control(
			'padding',
			[
				'label' => esc_html__( 'Padding', 'goyto-plugin' ),
				'type' => \Elementor\Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em', 'rem', 'custom' ],
				'selectors' => [
					'{{WRAPPER}} .arv-btn-1' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
        $this->add_control(
			'b_round',
			[
				'label' => esc_html__( 'Border Radius', 'goyto-plugin' ),
				'type' => \Elementor\Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em', 'rem', 'custom' ],
				'selectors' => [
					'{{WRAPPER}} .arv-btn-1' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					'{{WRAPPER}} .arv-btn-1::after, .arv-btn-1::before' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);


        $this->start_controls_tabs(
			'style_tabs'
		);

		$this->start_controls_tab(
			'style_normal_tab',
			[
				'label' => esc_html__( 'Normal', 'goyto-plugin' ),
			]
		);
        $this->add_control(
			'btn_text',
			[
				'label' => esc_html__( 'Text Color', 'goyto-plugin' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .arv-btn-1' => 'color: {{VALUE}}',
					'{{WRAPPER}} .arv-btn-1:is(.has-hover-white) .text::before' => 'color: {{VALUE}}',
					'{{WRAPPER}} .arv-btn-1 .btn-text' => 'color: {{VALUE}}'
				],
			]
		);
        $this->add_control(
			'btn_br_text',
			[
				'label' => esc_html__( 'Border Color', 'goyto-plugin' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .arv-btn-1' => 'border-color: {{VALUE}}'
				],
				'condition' => [
					'style!' => ['1'],
				],
			]
		);
        $this->add_group_control(
			\Elementor\Group_Control_Background::get_type(),
			[
				'name' => 'button_bg_color',
				'types' => [ 'gradient' ],
				'exclude' => [ 'image' ],
				'selector' => '{{WRAPPER}} .arv-btn-1::after',
                'fields_options' => [
                    'background' => [
                        'label' => esc_html__( 'Button BG Color ', 'goyto-plugin' ),
                        'description' => esc_html__( 'Choose background type and style.', 'goyto-plugin' ),
                        'separator' => 'before',
                    ]
                ]
			]
		);
        $this->end_controls_tab();
        $this->start_controls_tab(
			'style_hover_tab',
			[
				'label' => esc_html__( 'Hover', 'goyto-plugin' ),
			]
		);
        $this->add_control(
			'btn_h_text',
			[
				'label' => esc_html__( 'Text Hovwe Color', 'goyto-plugin' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .arv-btn-1:hover' => 'color: {{VALUE}}',
					'{{WRAPPER}} .arv-btn-1:hover .btn-text' => 'color: {{VALUE}}'
				],
			]
		);
        $this->add_group_control(
			\Elementor\Group_Control_Background::get_type(),
			[
				'name' => 'button_border_hover_color',
				'types' => [ 'gradient' ],
				'exclude' => [ 'image' ],
				'selector' => '
				{{WRAPPER}} .arv-btn-1::before
				',
				'condition' => [
					'style' => ['1'],
				],
                'fields_options' => [
                    'background' => [
                        'label' => esc_html__( 'Button Hover Border Color ', 'goyto-plugin' ),
                        'description' => esc_html__( 'Choose background type and style.', 'goyto-plugin' ),
                        'separator' => 'before',
                    ]
                ]
			]
		);
        $this->add_group_control(
			\Elementor\Group_Control_Background::get_type(),
			[
				'name' => 'button_bg_hover_color',
				'types' => [ 'gradient' ],
				'exclude' => [ 'image' ],
				'selector' => '
				{{WRAPPER}} .arv-btn-1:hover,
				{{WRAPPER}} .arv-btn-1:hover::after
				',
                'fields_options' => [
                    'background' => [
                        'label' => esc_html__( 'Button Hover BG Color ', 'goyto-plugin' ),
                        'description' => esc_html__( 'Choose background type and style.', 'goyto-plugin' ),
                        'separator' => 'before',
                    ]
                ]
			]
		);
        $this->end_controls_tab();
		$this->end_controls_tabs();
        $this->end_controls_section();



	}


	protected function render() {
		$settings = $this->get_settings_for_display();
		extract( $settings );
		if ( ! empty( $settings['btn_link']['url'] ) ) {
			$this->add_link_attributes( 'btn_link', $settings['btn_link'] );
		}
		require __DIR__ . '/header-template/header-' . $settings['style'] . '.php';
    }

	
	/**
	 * Search Body Display
	 *
	 * @return void
	 */
	protected function ___search_body(){
		$settings = $this->get_settings_for_display();
		?>
		
		<div class="txa-search-box search_box_active ">

		<div class="txa-search-container">
			<div class="txa-search-wrap text-center mb-55">
				<?php if(!empty($settings['search_btn_label'])):?>
					<h5 class="txa-search-title fx-heading-1 fx-font-500"><?php echo edrio_wp_kses($settings['search_title'])?></h5>
				<?php endif;?>
				<form action="<?php echo esc_url(home_url( '/' ));?>" class="txa-search-form">
					<input class="txa-search-form-input" type="text" name="s" value="<?php echo get_search_query();?>"  placeholder="<?php esc_attr_e( 'What are you looking for?...', 'edrio-plugin' );?>">
				</form>

			</div>

			<div class="txa-search-tag-wrap text-center">
				<?php if(!empty($settings['search_link_title'])):?>
					<h6 class="txa-search-tag-title fx-font-400 fx-heading-1"><?php echo edrio_wp_kses($settings['search_link_title']);?></h6>
				<?php endif;?>
				<div class="txa-search-tag d-inline-flex flex-wrap">
					<?php foreach($settings['search_link'] as $item):?>
						<a target="<?php echo esc_attr( $item['link']['is_external'] ? '_blank' : '_self' ); ?>" rel="<?php echo esc_attr( $item['link']['nofollow'] ? 'nofollow' : '' ); ?>" href="<?php echo $item['link']['url'] ? esc_url($item['link']['url']) : ''; ?>" aria-label="name" class="txa-search-tag-item fx-heading-1 fx-font-500" ><?php echo edrio_wp_kses($item['title']);?></a>
					<?php endforeach;?>
				</div>
			</div>
		</div>

		<button aria-label="search-close" type="button" class="txa-search-box-close search_box_close">
			<i class="fa-solid fa-xmark"></i>
		</button>

		</div>

<?php 
}

protected function mini_cart_bar(){ ?>
	<div class="cart_sidebar">
		<div class="cart_sidebar_top">
			<h2 class="heading_title">Cart</h2>
			<button type="button" class="cart_close_btn tx-close"><i class="fa-solid fa-xmark"></i></button>
		</div>
		<div class="cart_items_list">
		<?php 
		// Check if WooCommerce is active and the cart object exists
		if (function_exists('WC') && WC()->cart) : 
			if (WC()->cart->is_empty()) : 
		?>
			<p class="empty_cart_text">Your cart is currently empty.</p>
		<?php else : ?>
			<?php foreach (WC()->cart->get_cart() as $cart_item_key => $cart_item) :
				$product = $cart_item['data'];
				if (!$product || !$product->exists()) {
					continue;
				}
				$product_id = $product->get_id();
				$product_name = $product->get_name();
				$product_img = $product->get_image();
				$product_price = wc_price($product->get_price());
			?>
				<div class="cart_item">
					<div class="item_image">
						<?php echo $product_img; ?>
					</div>
					<div class="item_content headline">
						<h4 class="item_title"><?php echo esc_html($product_name); ?></h4>
						<span class="item_price"><?php echo $product_price; ?></span>
						<form action="<?php echo esc_url(wc_get_cart_remove_url($cart_item_key)); ?>" method="post">
							<button type="submit" class="remove_btn"><i class="fa-solid fa-xmark"></i></button>
						</form>
					</div>
				</div>
			<?php endforeach; ?>
		<?php endif; 
		else : ?>
			<p class="empty_cart_text">Your cart is currently empty.</p>
		<?php endif; ?>
		</div>

		<div class="cart_sidebar_bottom">
			<div class="total_price">
				<span>Sub Total:</span>
				<span><?php echo function_exists('WC') && WC()->cart ? WC()->cart->get_cart_subtotal() : '0.00'; ?></span>
			</div>
			<div class="cart_sidebar_button">
				<a href="<?php echo function_exists('wc_get_cart_url') ? wc_get_cart_url() : '#'; ?>">View Cart</a>
				<a href="<?php echo function_exists('wc_get_checkout_url') ? wc_get_checkout_url() : '#'; ?>">Checkout</a>
			</div>
		</div>
	</div>
<?php 
}

protected function mobile_menu(){ 
	$settings = $this->get_settings_for_display();	
?>
<div class="mobile_menu lenis lenis-smooth ofcanvas_sidebar position-relative">
	<div class="mobile_menu_wrap">
		<div class="mobile_menu_overlay open_mobile_menu"></div>
		<div class="mobile_menu_content">
			<div class="mobile_menu_close open_mobile_menu">
				<i class="fas fa-times"></i>
			</div>
			<div class="m-brand-logo">
				<a href="<?php echo esc_url(home_url());?>" aria-label="name">
					<img class="logo_site-m-size" src="<?php echo esc_url($settings['rzmlogo']['url']);?>" alt="<?php if(!empty($settings['rzmlogo']['alt'])){ echo esc_attr($settings['rzmlogo']['alt']);}?>">
				</a>
			</div>
			<div class="mobile-search-bar position-relative">
				<form method="get" action="<?php echo home_url( '/' ); ?>">
					<input type="text" name="s" placeholder="Keywords">
					<button type="submit"><i class="fas fa-search"></i></button>
				</form>
			</div>
			<nav class="mobile-main-navigation  clearfix ul-li">
				<?php
					echo str_replace(['menu-item-has-children', 'sub-menu'], ['dropdown', 'dropdown-menu clearfix'], wp_nav_menu( array(
						'echo'           => false,
						'menu' => !empty($settings['choose-menu']) ? $settings['choose-menu'] : 'menu-1',
						'menu_id'        =>'main-nav',
						'menu_class'        =>'nav navbar-nav clearfix list-unstyled',
						'container'=>false,
						'fallback_cb'    => 'Navwalker_Class::fallback',
						'walker'         => class_exists( 'Rs_Mega_Menu_Walker' ) ? new \Rs_Mega_Menu_Walker : '',
					)) );
				?>
			</nav>
			<?php if(!empty($settings['f_socials'])):?>
				<div class="ptx-mobile-header-social text-center">
					<?php foreach($settings['f_socials'] as $item):?>
						<a href="<?php echo esc_url($item['link']['url']);?>"> <?php \Elementor\Icons_Manager::render_icon( $item['icon'], [ 'aria-hidden' => 'true' ] ); ?></a>
					<?php endforeach;?>
				</div>
			<?php endif;?>
		</div>
	</div>
	<!-- /Mobile-Menu -->
</div>
<?php 
}






}


Plugin::instance()->widgets_manager->register( new Edrio_Header() );