<?php 
    $this->add_render_attribute( 'title', 'class', 'elementor-gt-heading sec_title ed-sec-tt-anim ed-has-anim' );
?>
<div class="ed-sec-title-5 headline-5 pera-content prthalign">
<?php if(!empty($settings['subtitle'])):?>
    <div class="subtitle wow fadeInRight" data-wow-delay="300ms" data-wow-duration="1500ms">
        <?php echo edrio_wp_kses($settings['subtitle']);?>
    </div>
<?php endif;?>
    <?php 
        printf('<%1$s %2$s>%3$s</%1$s>',
            tag_escape($settings['title_tag']),
            $this->get_render_attribute_string('title'),
            nl2br(edrio_wp_kses($settings['title']))
        ); 
    ?>
    <div class="elementor-gt-desc">
        <?php 
            if(!empty($settings['description'])):
                echo edrio_wp_kses(wpautop($settings['description']));
            endif;
        ?>
    </div>
</div>