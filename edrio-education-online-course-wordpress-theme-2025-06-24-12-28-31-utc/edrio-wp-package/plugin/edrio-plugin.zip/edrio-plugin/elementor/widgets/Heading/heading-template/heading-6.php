<?php 
    $this->add_render_attribute( 'title', 'class', 'elementor-gt-heading sec_title ed-sec-tt-anim ed-has-anim' );
?>
<div class="ed-sec-title-6 headline-6 prthalign pera-content">
    <?php 
        printf('<%1$s %2$s>%3$s</%1$s>',
            tag_escape($settings['title_tag']),
            $this->get_render_attribute_string('title'),
            nl2br(edrio_wp_kses($settings['title']))
        ); 
    ?>
</div>