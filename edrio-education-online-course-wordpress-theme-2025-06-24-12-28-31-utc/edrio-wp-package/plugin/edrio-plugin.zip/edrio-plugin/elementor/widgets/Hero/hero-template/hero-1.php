<?php 
    $this->add_render_attribute( 'title', 'class', 'elementor-gt-heading hero_title_1 banner_title agt_hero_title' );
?>
<section id="ed-hero-1" class="ed-hero-section-1 position-relative" data-background="<?php echo esc_url($settings['hero_bg']['url']);?>">
    <?php if(!empty($settings['shape1']['url'])):?>
        <span class="ed-h-shape1 position-absolute">
            <img src="<?php echo esc_url($settings['shape1']['url']);?>" alt="<?php if(!empty($settings['shape1']['alt'])){ echo esc_attr($settings['shape1']['alt']);}?>">
        </span>
    <?php endif;?>
    <?php if(!empty($settings['shape2']['url'])):?>
        <span class="ed-h-shape2 position-absolute">
            <img src="<?php echo esc_url($settings['shape2']['url']);?>" alt="<?php if(!empty($settings['shape2']['alt'])){ echo esc_attr($settings['shape2']['alt']);}?>">
        </span>
    <?php endif;?>
    <?php if(!empty($settings['shape3']['url'])):?>
        <span class="ed-h-shape3 position-absolute">
            <img src="<?php echo esc_url($settings['shape3']['url']);?>" alt="<?php if(!empty($settings['shape3']['alt'])){ echo esc_attr($settings['shape3']['alt']);}?>">
        </span>
    <?php endif;?>
    <div class="container">
        <div class="ed-h1-content position-relative">
            <div class="h1-img-wrap">
                <?php if(!empty($settings['shape4']['url'])):?>
                    <div class="ed-img-shape1 position-absolute">
                        <span><img src="<?php echo esc_url($settings['shape4']['url']);?>" alt="<?php if(!empty($settings['shape4']['alt'])){ echo esc_attr($settings['shape4']['alt']);}?>"></span>
                    </div>
                <?php endif;?>
                <?php if(!empty($settings['shape5']['url'])):?>
                    <div class="ed-img-shape2 position-absolute"><span><img src="<?php echo esc_url($settings['shape5']['url']);?>" alt="<?php if(!empty($settings['shape5']['alt'])){ echo esc_attr($settings['shape5']['alt']);}?>"></span></div>
                <?php endif;?>
                <?php if(!empty($settings['shape6']['url'])):?>
                    <div class="ed-img-shape3 position-absolute"><span><img src="<?php echo esc_url($settings['shape6']['url']);?>" alt="<?php if(!empty($settings['shape6']['alt'])){ echo esc_attr($settings['shape6']['alt']);}?>"></span></div>
                <?php endif;?>
                <?php if(!empty($settings['shape7']['url'])):?>
                    <div class="ed-img-shape4 position-absolute"><span><img src="<?php echo esc_url($settings['shape7']['url']);?>" alt="<?php if(!empty($settings['shape7']['alt'])){ echo esc_attr($settings['shape7']['alt']);}?>"></span></div>
                <?php endif;?>
                <?php if(!empty($settings['shape8']['url'])):?>
                    <div class="ed-img-shape5 position-absolute"><span><img src="<?php echo esc_url($settings['shape8']['url']);?>" alt="<?php if(!empty($settings['shape8']['alt'])){ echo esc_attr($settings['shape8']['alt']);}?>"></span></div>
                <?php endif;?>
                <?php if(!empty($settings['hero_img']['url'])):?>
                    <div class="item-img">
                        <img src="<?php echo esc_url($settings['hero_img']['url']);?>" alt="<?php if(!empty($settings['hero_img']['alt'])){ echo esc_attr($settings['hero_img']['alt']);}?>">
                    </div>
                <?php endif;?>
            </div>
            <div class="h1-text-wrap headline pera-content">
                <div class="h1-text-area edh-text">
                    <?php if(!empty($settings['sub_title'])):?>
                        <span class="h1_slug"><?php echo edrio_wp_kses($settings['sub_title'])?></span>
                    <?php endif;?>
                    <?php 
                        printf('<%1$s %2$s>%3$s</%1$s>',
                            tag_escape($settings['title_tag']),
                            $this->get_render_attribute_string('title'),
                            nl2br(edrio_wp_kses($settings['title']))
                        ); 
                    ?>
                    <?php if(!empty($settings['description'])):?>
                        <p><?php echo edrio_wp_kses($settings['description'])?></p>
                    <?php endif;?>
                </div>
                <?php if($settings['enable_search'] === 'yes'):?>
                <div class="h1-search-box position-relative">
                    <form action="<?php echo esc_url(home_url('/')); ?>" method="get">
                        <div class="h1-input-field">
                            <input type="text" name="s" placeholder="<?php echo esc_attr($settings['search_placeholder']);?>" value="<?php echo get_search_query(); ?>">
                        </div>
                        <div class="ed-select-option d-flex align-items-center">
                            <div class="action-select ed-option">
                                <select>
                                    <option value="#"><?php echo edrio_wp_kses($settings['search_label']);?></option>
                                    <?php
                                        $categories = get_terms([
                                            'taxonomy'   => 'course-category',
                                            'hide_empty' => true,
                                        ]);
                                        
                                        if (!empty($categories) && !is_wp_error($categories)) {
                                            foreach ($categories as $cat) {
                                                $selected = (isset($_GET['tutor-course-category']) && $_GET['tutor-course-category'] === $cat->slug) ? 'selected' : '';
                                                echo '<option value="' . esc_attr($cat->slug) . '" ' . $selected . '>' . esc_html($cat->name) . '</option>';
                                            }
                                        }
                                        ?>
                                </select>
                            </div>
                            <?php if(!empty($settings['search_btn_text'])):?>
                                <button type="submit"><?php echo edrio_wp_kses($settings['search_btn_text'])?></button>
                            <?php endif;?>
                        </div>
                    </form>
                </div>
                <?php endif;?>
            </div>
        </div>
    </div>
</section>