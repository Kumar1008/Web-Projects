<?php 
    $this->add_render_attribute( 'title', 'class', 'elementor-gt-heading hero_title banner_title agt_hero_title_2' );
?>
<div class="ed-hero-content-4">
    <div class="ed-hero-text-4 text-center headline-4 pera-content edh-text">
        <?php 
            printf('<%1$s %2$s>%3$s</%1$s>',
                tag_escape($settings['title_tag']),
                $this->get_render_attribute_string('title'),
                nl2br(edrio_wp_kses($settings['title']))
            ); 
        ?>
        <?php if(!empty($settings['description'])):?>
            <p><?php echo edrio_wp_kses($settings['description'])?></p>
        <?php endif;?>
    </div>
    <div class="ed-hero-img-wrap-4 txt_item_active  ul-li">
        <ul>
            <?php foreach($settings['features'] as $item):?>
            <li>
                <div class="ed-h-list-img <?php if($item['active'] === 'yes'){ echo esc_attr('active');}?> position-relative">
                    <?php if(!empty($item['title'])):?>
                        <span><?php echo edrio_wp_kses($item['title'])?></span>
                    <?php endif;?>
                    <?php if(!empty($item['feature_img']['url'])):?>
                        <div class="item-img">
                            <img src="<?php echo esc_url($item['feature_img']['url']);?>" alt="<?php if(!empty($item['feature_img']['alt'])){ echo esc_attr($item['feature_img']['alt']);}?>">
                        </div>
                    <?php endif;?>
                    <?php if(!empty($item['btn_label'])):?>
                        <div class="item-text">
                            <?php
                                $link_url     = !empty( $item['link']['url'] ) ? esc_url( $item['link']['url'] ) : '#';
                                $is_external  = !empty( $item['link']['is_external'] ) ? '_blank' : '_self';
                                $nofollow     = !empty( $item['link']['nofollow'] ) ? 'nofollow' : '';
                                ?>

                                <a 
                                    href="<?php echo $link_url; ?>" 
                                    target="<?php echo esc_attr( $is_external ); ?>" 
                                    rel="<?php echo esc_attr( $nofollow ); ?>"
                                >
                                    <?php echo edrio_wp_kses($item['btn_label'])?>
                                    <?php if(!empty($item['btn_arrow']['url'])):?>
                                        <img src="<?php echo esc_url($item['btn_arrow']['url']);?>" alt="<?php if(!empty($item['btn_arrow']['alt'])){ echo esc_attr($item['btn_arrow']['alt']);}?>">
                                    <?php endif;?>
                                </a>
                        </div>
                    <?php endif;?>
                </div>
            </li>
            <?php endforeach;?>
            
        </ul>
    </div>
    <?php if($settings['enable_search'] === 'yes'):?>
    <div class="ed-hero-search-4 top_view_4">
    <form action="<?php echo esc_url(home_url('/')); ?>" method="get" class="tutor-course-search-form">
    <input type="text" name="s" placeholder="<?php echo esc_attr($settings['search_placeholder']);?>" value="<?php echo get_search_query(); ?>">

    <div class="action-select ed-option">
        <select name="tutor-course-category">
            <option value="">
                <?php echo edrio_wp_kses($settings['search_label']);?>
            </option>
            <?php
            $categories = get_terms([
                'taxonomy'   => 'course-category',
                'hide_empty' => true,
            ]);
            
            if (!empty($categories) && !is_wp_error($categories)) {
                foreach ($categories as $cat) {
                    $selected = (isset($_GET['tutor-course-category']) && $_GET['tutor-course-category'] === $cat->slug) ? 'selected' : '';
                    echo '<option value="' . esc_attr($cat->slug) . '" ' . $selected . '>' . esc_html($cat->name) . '</option>';
                }
            }
            ?>
        </select>
    </div>

    <!-- Make sure to use the correct post type for Tutor LMS courses -->
    <input type="hidden" name="post_type" value="courses">
    
    <!-- Add this to ensure Tutor LMS recognizes this as a course search -->  
    <input type="hidden" name="search_mode" value="tutor_course_search">

    <button type="submit"><i class="fa-solid fa-magnifying-glass"></i></button>
</form>

        <div class="ed-h4-search-list mt-35 text-center ul-li">
            <?php if(!empty($settings['lists'])):?>
            <ul>
            <?php foreach($settings['lists'] as $item):?>
                <li>
                    <?php \Elementor\Icons_Manager::render_icon( $item['icon'], [ 'aria-hidden' => 'true' ] ); ?>
                    <?php echo edrio_wp_kses($item['title'])?>
                </li>
            <?php endforeach;?>
            </ul>
            <?php endif;?>
            <?php if(!empty($settings['course_text'])):?>
                <span>
                    <?php echo edrio_wp_kses($settings['course_text'])?>
                </span>
            <?php endif;?>
        </div>
    </div>
    <?php endif;?>
</div>