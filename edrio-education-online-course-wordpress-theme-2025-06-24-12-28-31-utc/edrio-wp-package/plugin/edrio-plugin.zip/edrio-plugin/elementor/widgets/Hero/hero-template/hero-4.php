<?php 
    $this->add_render_attribute( 'title', 'class', 'elementor-gt-heading ed_banner_title banner_title agt_hero_title_3' );

    if ( ! empty( $settings['btn_link']['url'] ) ) {
        $this->add_link_attributes( 'btn_link', $settings['btn_link'] );
    }
?>
<section id="ed-hero-6" class="ed-hero-sec-6">
<div class="ed-hero6-wrap position-relative">
    <span class="hero6-shape position-absolute">
        <svg width="1946" height="516" viewBox="0 0 1946 516" fill="none" xmlns="http://www.w3.org/2000/svg">
            <g filter="url(#filter0_f_261_221)">
                <path d="M1878.5 503.001L1933 479L1932.5 13H13V266.5C14 267.667 17.9 270.4 25.5 272C33.1 273.6 78.3334 272.667 100 272L129 254.5L132.5 257.5C140.5 258 159.3 259 170.5 259C181.7 259 183.833 273 183.5 280C194.3 295.2 223 302.667 236 304.5C303 309 356 292 371 283.5C383 276.7 391 284.333 393.5 289L465.5 304.5L483 278L675 348C679.167 347.167 691.9 344 709.5 338C727.1 332 774.5 342.167 796 348L850.5 335.5C861.167 334.333 888.4 331.6 912 330C941.5 328 1027 304.501 1073.5 293.001C1110.7 283.801 1180 288.501 1210 292.001L1284 374.501H1320L1359.5 409.501H1412.5L1430.5 436.001L1574.5 409.501H1605.5L1627 436.001C1638.5 435.834 1661.9 432.801 1663.5 422.001C1665.1 411.201 1680.83 409.168 1688.5 409.501C1690.67 411.501 1702.7 422.201 1733.5 449.001C1772 482.501 1806 479.501 1829.5 482.001C1848.3 484.001 1870 496.834 1878.5 503.001Z" fill="#050505" fill-opacity="0.2"/>
            </g>
            <defs>
                <filter id="filter0_f_261_221" x="0" y="0" width="1946" height="516.001" filterUnits=ss"userSpaceOnUse" color-interpolation-filters="sRGB">
                    <feFlood flood-opacity="0" result="BackgroundImageFix"/>
                    <feBlend mode="normal" in="SourceGraphic" in2="BackgroundImageFix" result="shape"/>
                    <feGaussianBlur stdDeviation="6.5" result="effect1_foregroundBlur_261_221"/>
                </filter>
            </defs>
        </svg>
    </span>
    <div class="ed-hero-content-6 position-relative">
    <?php if(!empty($settings['hero_bg']['url'])):?>
        <div class="hero_img6 position-absolute">
            <img src="<?php echo esc_url($settings['hero_bg']['url']);?>" alt="<?php if(!empty($settings['hero_bg']['alt'])){ echo esc_attr($settings['hero_bg']['alt']);}?>">
        </div>
    <?php endif;?>
        <div class="ed-h6-img">
            <?php if(!empty($settings['shape1']['url'])):?>
                <div class="item-img1">
                    <img src="<?php echo esc_url($settings['shape1']['url']);?>" alt="<?php if(!empty($settings['shape1']['alt'])){ echo esc_attr($settings['shape1']['alt']);}?>">
                </div>
            <?php endif;?>
            <?php if(!empty($settings['shape2']['url'])):?>
            <div class="item-img2">
                <img src="<?php echo esc_url($settings['shape2']['url']);?>" alt="<?php if(!empty($settings['shape2']['alt'])){ echo esc_attr($settings['shape2']['alt']);}?>">
            </div>
            <?php endif;?>
        </div>
        <div class="container">
            <div class="ed-hero-text-6 headline-6 pera-content">
                <?php 
                    printf('<%1$s %2$s>%3$s</%1$s>',
                        tag_escape($settings['title_tag']),
                        $this->get_render_attribute_string('title'),
                        nl2br(edrio_wp_kses($settings['title']))
                    ); 
                ?>
                <div class="hero-decs6 edh-text d-flex">
                    <div class="item-img text-center">
                    <?php if(!empty($settings['shape3']['url'])):?>
                        <span class="img_1">
                            <img src="<?php echo esc_url($settings['shape3']['url']);?>" alt="<?php if(!empty($settings['shape3']['alt'])){ echo esc_attr($settings['shape3']['alt']);}?>">
                        </span>
                    <?php endif;?>
                    <?php if(!empty($settings['shape4']['url'])):?>
                        <span class="img_2">
                            <img src="<?php echo esc_url($settings['shape4']['url']);?>" alt="<?php if(!empty($settings['shape4']['alt'])){ echo esc_attr($settings['shape4']['alt']);}?>">
                        </span>
                    <?php endif;?>
                    </div>
                    <div class="item-text pera-content">
                    <?php if(!empty($settings['description'])):?>
                        <p><?php echo edrio_wp_kses($settings['description'])?></p>
                    <?php endif;?>
                    <?php if(!empty($settings['btn_label'])):?>
                        <div class="ed-btn-6">
                            <a <?php echo $this->get_render_attribute_string( 'btn_link' ); ?>>
                                <span><?php echo edrio_wp_kses($settings['btn_label']);?></span>
                                <svg width="18" height="14" viewBox="0 0 18 14" fill="none" xmlns="http://www.w3.org/2000/svg">
                                    <path opacity="0.4" d="M16.5013 7.83244H1.5013C1.28029 7.83244 1.06833 7.74464 0.912046 7.58836C0.755766 7.43208 0.667969 7.22012 0.667969 6.9991C0.667969 6.77809 0.755766 6.56613 0.912046 6.40985C1.06833 6.25357 1.28029 6.16577 1.5013 6.16577H16.5013C16.7223 6.16577 16.9343 6.25357 17.0906 6.40985C17.2468 6.56613 17.3346 6.77809 17.3346 6.9991C17.3346 7.22012 17.2468 7.43208 17.0906 7.58836C16.9343 7.74464 16.7223 7.83244 16.5013 7.83244Z" fill="white"/>
                                    <path d="M10.6691 13.6666C10.5043 13.6666 10.3432 13.6177 10.2062 13.5261C10.0692 13.4345 9.96242 13.3044 9.89936 13.1521C9.8363 12.9999 9.8198 12.8324 9.85194 12.6707C9.88408 12.5091 9.96342 12.3606 10.0799 12.2441L15.3241 6.99993L10.0799 1.75577C9.92813 1.5986 9.84413 1.3881 9.84603 1.1696C9.84793 0.951101 9.93557 0.742091 10.0901 0.587584C10.2446 0.433077 10.4536 0.345436 10.6721 0.343537C10.8906 0.341639 11.1011 0.425634 11.2583 0.577433L17.0916 6.41077C17.2478 6.56704 17.3356 6.77896 17.3356 6.99993C17.3356 7.2209 17.2478 7.43283 17.0916 7.5891L11.2583 13.4224C11.102 13.5787 10.8901 13.6666 10.6691 13.6666Z" fill="white"/>
                                </svg>
                            </a>
                        </div>
                    <?php endif;?>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
</section>