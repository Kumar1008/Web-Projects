<div class="ed-ab-text-feature">
    <div class="row">
    <?php foreach($settings['boxes'] as $item):?>
        <div class="col-sm-6">
            <div class="ed-ab-ft-3 d-flex align-items-center top_view">
                <div class="item-icon d-flex align-items-center justify-content-center">
                    <?php if ($item['type'] === 'image' && ($item['icon_img']['url'])) :?>
                        <img src="<?php echo esc_url($item['icon_img']['url']);?>" alt="<?php if(!empty($item['icon_img']['alt'])){ echo esc_attr($item['icon_img']['alt']);}else{esc_attr_e('List', 'edrio-plugin');}?>">
                    <?php else:?>
                        <?php \Elementor\Icons_Manager::render_icon( $item['icon'], [ 'aria-hidden' => 'true' ] ); ?>
                    <?php endif;?>
                </div>
                <div class="item-text headline-3">
                    <h3><a target="<?php echo esc_attr( $item['link']['is_external'] ? '_blank' : '_self' ); ?>" rel="<?php echo esc_attr( $item['link']['nofollow'] ? 'nofollow' : '' ); ?>" href="<?php echo esc_url($item['link']['url']);?>"><?php echo edrio_wp_kses($item['title']);?></a></h3>
                </div>
            </div>
        </div>
    <?php endforeach;?>
    </div>
</div>