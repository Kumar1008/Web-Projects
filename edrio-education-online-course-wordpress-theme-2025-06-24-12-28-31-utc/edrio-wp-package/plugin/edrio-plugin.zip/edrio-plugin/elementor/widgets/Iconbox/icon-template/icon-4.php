<div class="ed-wc-elem-3">
<?php foreach($settings['boxes'] as $item):?>
    <div class="ed-wc-item-3 top_view_3 d-flex align-items-center">
        <div class="item-icon d-flex justify-content-center align-items-center">
            <?php if ($item['type'] === 'image' && ($item['icon_img']['url'])) :?>
                <img src="<?php echo esc_url($item['icon_img']['url']);?>" alt="<?php if(!empty($item['icon_img']['alt'])){ echo esc_attr($item['icon_img']['alt']);}else{esc_attr_e('List', 'edrio-plugin');}?>">
            <?php else:?>
                <?php \Elementor\Icons_Manager::render_icon( $item['icon'], [ 'aria-hidden' => 'true' ] ); ?>
            <?php endif;?>
        </div>
        <div class="item-text headline-3 pera-content">
            <h3><?php echo edrio_wp_kses($item['title']);?></h3>
            <?php if(!empty($item['desc'])):?>
                <p>
                    <?php echo edrio_wp_kses($item['desc']);?>
                </p>
            <?php endif;?>
        </div>
    </div>
<?php endforeach;?>
</div>