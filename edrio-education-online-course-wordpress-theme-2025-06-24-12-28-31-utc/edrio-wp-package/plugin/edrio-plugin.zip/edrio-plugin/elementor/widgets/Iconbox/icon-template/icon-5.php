<div class="ed-feature5-wrap position-relative">
        <div class="line-shape"><span></span></div>
        <?php if(!empty($settings['shape']['url'])):?>
            <div class="line-shape-2 position-absolute">
                <img src="<?php echo esc_url($settings['shape']['url']);?>" alt="<?php if(!empty($settings['shape']['alt'])){ echo esc_attr($settings['shape']['alt']);}?>">
            </div>
        <?php endif;?>
        <div class="ed-feature5-content position-relative">
            <div class="ed-dec-shape">
                <span class="box_shape_1"></span>
                <span class="box_shape_2"></span>
            </div>
            <div class="row justify-content-center">
            <?php foreach($settings['boxes'] as $item):?>
                <div class="col-lg-4 col-md-6">
                    <div class="ed-feature5-item">
                        <div class="item-icon">
                            <div class="inner-img">
                                <?php if ($item['type'] === 'image' && ($item['icon_img']['url'])) :?>
                                    <img src="<?php echo esc_url($item['icon_img']['url']);?>" alt="<?php if(!empty($item['icon_img']['alt'])){ echo esc_attr($item['icon_img']['alt']);}else{esc_attr_e('List', 'edrio-plugin');}?>">
                                <?php else:?>
                                    <?php \Elementor\Icons_Manager::render_icon( $item['icon'], [ 'aria-hidden' => 'true' ] ); ?>
                                <?php endif;?>
                            </div>
                        </div>
                        <div class="item-text headline-5 pera-content">
                            <h3><?php echo edrio_wp_kses($item['title']);?></h3>
                            <?php if(!empty($item['desc'])):?>
                                <p><?php echo edrio_wp_kses($item['desc']);?></p>
                            <?php endif;?>
                        </div>
                    </div>
                </div>
            <?php endforeach;?>
            </div>
        </div>
    </div>