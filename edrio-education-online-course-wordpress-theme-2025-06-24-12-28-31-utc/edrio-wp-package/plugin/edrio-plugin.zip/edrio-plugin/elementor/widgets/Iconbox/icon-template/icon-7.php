<div class="ed-ft6-sec">
    <div class="ed-ft6-content">
        <div class="row justify-content-center">
        <?php foreach($settings['boxes'] as $item):?>
            <div class="col-lg-4 col-md-6">
                <div class="ed-ft6-item ed-ft6-app">
                    <div class="item-icon">
                        <span class="inner-icon d-flex align-items-center justify-content-center">
                            <?php if ($item['type'] === 'image' && ($item['icon_img']['url'])) :?>
                                <img src="<?php echo esc_url($item['icon_img']['url']);?>" alt="<?php if(!empty($item['icon_img']['alt'])){ echo esc_attr($item['icon_img']['alt']);}else{esc_attr_e('List', 'edrio-plugin');}?>">
                            <?php else:?>
                                <?php \Elementor\Icons_Manager::render_icon( $item['icon'], [ 'aria-hidden' => 'true' ] ); ?>
                            <?php endif;?>
                        </span>
                    </div>
                    <div class="item-text headline-6 pera-content">
                        <h3><?php echo edrio_wp_kses($item['title']);?></h3>
                        <?php if(!empty($item['desc'])):?>
                            <p><?php echo edrio_wp_kses($item['desc']);?></p>
                        <?php endif;?>
                    </div>
                </div>
            </div>
        <?php endforeach;?>
        </div>
    </div>
</div>