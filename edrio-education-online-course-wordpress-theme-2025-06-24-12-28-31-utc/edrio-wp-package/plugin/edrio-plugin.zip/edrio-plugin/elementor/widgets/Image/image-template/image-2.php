<div class="ed-review-count-img-wrap position-relative d-flex">
    <div class="ed-rv-item-count zoom_in text-center headline pera-content ul-li">
    <?php if (!empty($settings['rating'])): ?>
    <div class="count-star text-center">
        <ul>
            <?php 
                $rating = floatval($settings['rating']);
                $full_stars = floor($rating); // Number of full stars
                $half_star = ($rating - $full_stars) >= 0.5 ? 1 : 0; // Check if there's a half star
                $empty_stars = 5 - ($full_stars + $half_star); // Remaining empty stars

                // Full stars
                for ($i = 0; $i < $full_stars; $i++) {
                    echo '<li><i class="fa-solid fa-star"></i></li>';
                }

                // Half star
                if ($half_star) {
                    echo '<li><i class="fa-solid fa-star-half-stroke"></i></li>';
                }

                // Empty stars
                for ($i = 0; $i < $empty_stars; $i++) {
                    echo '<li><i class="fa-regular fa-star"></i></li>';
                }
            ?>
        </ul>
        <span><?php echo number_format($rating, 1); ?></span>
    </div>
<?php endif; ?>
        <?php if(!empty($settings['title'])):?>
            <p><?php echo edrio_wp_kses($settings['title']);?></p>
        <?php endif;?>
        <?php if(!empty($settings['counter'])):?>
            <h3><?php if(!empty($settings['suffix'])):?>
                    <?php echo esc_html($settings['suffix']);?>
                <?php endif;?><span class="counter"><?php echo esc_html($settings['counter']);?></span>
                <?php if(!empty($settings['prefix'])):?>
                    <?php echo esc_html($settings['prefix']);?>
                <?php endif;?>
            </h3>
        <?php endif;?>
    </div>
    <?php if(!empty($settings['img_1']['url'])):?>
        <div class="item-img left_view">
            <img src="<?php echo esc_url($settings['img_1']['url']);?>" alt="<?php if(!empty($settings['img_1']['alt'])){ echo esc_url($settings['img_1']['alt']);}?>">
        </div>
    <?php endif;?>
    <?php if(!empty($settings['img_2']['url'])):?>
        <div class="item-img right_view">
            <img src="<?php echo esc_url($settings['img_2']['url']);?>" alt="<?php if(!empty($settings['img_2']['alt'])){ echo esc_url($settings['img_2']['alt']);}?>">
        </div>
    <?php endif;?>
</div>