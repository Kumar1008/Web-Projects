<div class="ed-intro-img-wrap position-relative">
    <?php if(!empty($settings['img_1']['url'])):?>
        <span class="intro-shape1 position-absolute"><img src="<?php echo esc_url($settings['img_1']['url']);?>" alt="<?php if(!empty($settings['img_1']['alt'])){ echo esc_url($settings['img_1']['alt']);}?>"></span>
     <?php endif;?>
     <?php if(!empty($settings['img_2']['url'])):?>
        <span class="intro-shape2 position-absolute">
            <img src="<?php echo esc_url($settings['img_2']['url']);?>" alt="<?php if(!empty($settings['img_2']['alt'])){ echo esc_url($settings['img_2']['alt']);}?>">
        </span>
    <?php endif;?>
    <?php if(!empty($settings['img_3']['url'])):?>
        <span class="intro-shape3 position-absolute">
            <img src="<?php echo esc_url($settings['img_3']['url']);?>" alt="<?php if(!empty($settings['img_3']['alt'])){ echo esc_url($settings['img_3']['alt']);}?>">
        </span>
    <?php endif;?>
    <?php if(!empty($settings['img_4']['url'])):?>
        <span class="intro-shape4 position-absolute">
            <img src="<?php echo esc_url($settings['img_4']['url']);?>" alt="<?php if(!empty($settings['img_4']['alt'])){ echo esc_url($settings['img_4']['alt']);}?>">
        </span>
    <?php endif;?>
    <?php if(!empty($settings['img_5']['url'])):?>
        <span class="intro-shape5 position-absolute">
            <img src="<?php echo esc_url($settings['img_5']['url']);?>" alt="<?php if(!empty($settings['img_5']['alt'])){ echo esc_url($settings['img_5']['alt']);}?>">
        </span>
    <?php endif;?>
    <?php if(!empty($settings['img_6']['url'])):?>
        <div class="item-img ed_top_img_3">
            <img src="<?php echo esc_url($settings['img_6']['url']);?>" alt="<?php if(!empty($settings['img_6']['alt'])){ echo esc_url($settings['img_6']['alt']);}?>">
        </div>
    <?php endif;?>
</div>