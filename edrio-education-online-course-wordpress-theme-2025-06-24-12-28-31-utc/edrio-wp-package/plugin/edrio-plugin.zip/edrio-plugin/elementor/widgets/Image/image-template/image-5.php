<?php if(!empty($settings['img_1']['url'])):?>
<div class="ed-wc-elem-2 upper_view">
    <div class="item-img">
        <img src="<?php echo esc_url($settings['img_1']['url']);?>" alt="<?php if(!empty($settings['img_1']['alt'])){ echo esc_url($settings['img_1']['alt']);}?>">
    </div>
</div>
<?php endif;?>