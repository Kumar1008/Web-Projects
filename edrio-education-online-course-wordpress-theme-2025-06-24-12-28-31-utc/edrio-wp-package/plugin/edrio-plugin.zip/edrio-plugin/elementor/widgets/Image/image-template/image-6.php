<div class="ed-ab4-img">
    <div class="ab4-item-img d-flex top_view">
    <?php if(!empty($settings['img_1']['url'])):?>
        <div class="item-img-1">
            <img src="<?php echo esc_url($settings['img_1']['url']);?>" alt="<?php if(!empty($settings['img_1']['alt'])){ echo esc_url($settings['img_1']['alt']);}?>">
        </div>
    <?php endif;?>
        <?php if(!empty($settings['img_2']['url'])):?>
        <div class="item-img-2">
            <img src="<?php echo esc_url($settings['img_2']['url']);?>" alt="<?php if(!empty($settings['img_2']['alt'])){ echo esc_url($settings['img_2']['alt']);}?>">
        </div>
        <?php endif;?>
    </div>
    <div class="ab4-item-img d-flex top_view">
        <?php if(!empty($settings['img_3']['url'])):?>
            <div class="item-img-2">
                <img src="<?php echo esc_url($settings['img_3']['url']);?>" alt="<?php if(!empty($settings['img_3']['alt'])){ echo esc_url($settings['img_3']['alt']);}?>">
            </div>  
        <?php endif;?>
        <?php if(!empty($settings['img_4']['url'])):?>
            <div class="item-img-1">
                <img src="<?php echo esc_url($settings['img_4']['url']);?>" alt="<?php if(!empty($settings['img_4']['alt'])){ echo esc_url($settings['img_4']['alt']);}?>">
            </div>
        <?php endif;?>
    </div>
    <div class="ab4-item-img d-flex top_view">
    <?php if(!empty($settings['img_5']['url'])):?>
        <div class="item-img-1">
            <img src="<?php echo esc_url($settings['img_5']['url']);?>" alt="<?php if(!empty($settings['img_5']['alt'])){ echo esc_url($settings['img_5']['alt']);}?>">
        </div>
    <?php endif;?>
        <?php if(!empty($settings['img_6']['url'])):?>
            <div class="item-img-2">
                <img src="<?php echo esc_url($settings['img_6']['url']);?>" alt="<?php if(!empty($settings['img_6']['alt'])){ echo esc_url($settings['img_6']['alt']);}?>">
            </div>
        <?php endif;?>
    </div>
</div>