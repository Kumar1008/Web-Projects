<div class="ed-wc5-img-wrap position-relative">
    <div class="ed-wc5-count headline-5 pera-content d-flex align-items-center">
        <h3><span class="counter"><?php echo esc_html($settings['counter']);?></span><?php if(!empty($settings['prefix'])):?>
                    <sup><?php echo esc_html($settings['prefix']);?></sup>
                <?php endif;?></h3>
        <?php if(!empty($settings['title'])):?>
            <p>
                <?php echo edrio_wp_kses($settings['title']);?>
            </p>
        <?php endif;?>
    </div>
    <div class="ed-wc5-img-wrapper">
    <?php if(!empty($settings['img_1']['url'])):?>
        <div class="item-img-1 d-flex justify-content-end">
            <div class="inner-img ed-image-appear3">
                <span>
                    <img class="ed-img-rvl_3" src="<?php echo esc_url($settings['img_1']['url']);?>" alt="<?php if(!empty($settings['img_1']['alt'])){ echo esc_url($settings['img_1']['alt']);}?>">
                </span>
            </div> 
        </div>
    <?php endif;?>
        <?php if(!empty($settings['img_2']['url'])):?>
        <div class="item-img-2 d-flex ">
            <div class="inner-img ed-image-appear2">
                <span>
                    <img class="ed-img-rvl_2" src="<?php echo esc_url($settings['img_2']['url']);?>" alt="<?php if(!empty($settings['img_2']['alt'])){ echo esc_url($settings['img_2']['alt']);}?>">
                </span>
            </div>
        </div>
        <?php endif;?>
    </div>
</div>