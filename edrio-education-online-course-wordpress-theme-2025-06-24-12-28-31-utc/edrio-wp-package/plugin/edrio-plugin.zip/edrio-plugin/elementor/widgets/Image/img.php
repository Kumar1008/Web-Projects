<?php

/**
 * Elementor Single Widget
 * @package edrios Tools
 * @since 1.0.0
 */

namespace Elementor;

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly.

class Edrios_Image extends Widget_Base {

	/**
	 * Get widget name.
	 *
	 * Retrieve Elementor widget name.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget name.
	 */
	public function get_name() {
		return 'go-img--bx';
	}

	/**
	 * Get widget title.
	 *
	 * Retrieve Elementor widget title.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget title.
	 */
	public function get_title() {
		return esc_html__( 'Image', 'edrios-plugin' );
	}

	/**
	 * Get widget icon.
	 *
	 * Retrieve Elementor widget icon.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget icon.
	 */
	public function get_icon() {
		return 'edrio-custom-icon';
	}

	/**
	 * Get widget categories.
	 *
	 * Retrieve the list of categories the Elementor widget belongs to.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return array Widget categories.
	 */
	public function get_categories() {
		return [ 'edrio_widgets' ];
	}


	protected function register_controls() {

        $this->start_controls_section(
			'int_widget_opt',
			[
				'label' => esc_html__( 'Feature Box Select', 'edrios-plugin' ),
				'tab'   => Controls_Manager::TAB_CONTENT,
			]
		);
        $this->add_control(
			'style',
			[
				'label' => esc_html__( 'Style', 'edrios-plugin' ),
				'type' => \Elementor\Controls_Manager::SELECT,
				'default' => '1',
				'options' => [
					'1'  => esc_html__( 'Style 1', 'edrios-plugin' ),
					'2'  => esc_html__( 'Style 2', 'edrios-plugin' ),
					'3'  => esc_html__( 'Style 3', 'edrios-plugin' ),
					'4'  => esc_html__( 'Style 4', 'edrios-plugin' ),
					'5'  => esc_html__( 'Style 5', 'edrios-plugin' ),
					'6'  => esc_html__( 'Style 6', 'edrios-plugin' ),
					'7'  => esc_html__( 'Style 7', 'edrios-plugin' )
				]
			]
		);
        $this->end_controls_section();

        $this->start_controls_section(
			'--img-option',
			[
				'label' => esc_html__( 'Image Option', 'edrios-plugin' ),
				'tab'   => Controls_Manager::TAB_CONTENT,
			]
		);
        
        $this->add_control(
			'img_1', [
				'label' => esc_html__( 'Image 1', 'edrio-plugin' ),
				'type' => Controls_Manager::MEDIA,
                'label_block' => true,
			]
		);
        $this->add_control(
			'img_2', [
				'label' => esc_html__( 'Image 2', 'edrio-plugin' ),
				'type' => Controls_Manager::MEDIA,
                'label_block' => true,
				'condition' => [
					'style' => ['2' , '3', '4', '6', '7'],
				],
			]
		);
        $this->add_control(
			'img_3', [
				'label' => esc_html__( 'Image 3', 'edrio-plugin' ),
				'type' => Controls_Manager::MEDIA,
                'label_block' => true,
				'condition' => [
					'style' => ['3', '4', '6'],
				],
			]
		);
        $this->add_control(
			'img_4', [
				'label' => esc_html__( 'Image 4', 'edrio-plugin' ),
				'type' => Controls_Manager::MEDIA,
                'label_block' => true,
				'condition' => [
					'style' => ['3', '4', '6'],
				],
			]
		);
        $this->add_control(
			'img_5', [
				'label' => esc_html__( 'Image 5', 'edrio-plugin' ),
				'type' => Controls_Manager::MEDIA,
                'label_block' => true,
				'condition' => [
					'style' => ['3', '4', '6'],
				],
			]
		);
        $this->add_control(
			'img_6', [
				'label' => esc_html__( 'Image 6', 'edrio-plugin' ),
				'type' => Controls_Manager::MEDIA,
                'label_block' => true,
				'condition' => [
					'style' => ['3', '4', '6'],
				],
			]
		);
		$this->add_control(
			'rating',
			[
				'label' => esc_html__( 'Rating', 'edrio-plugin' ),
				'type' => \Elementor\Controls_Manager::NUMBER,
				'min' => 1,
				'max' => 5,
				'step' => 1,
				'default' => 5,
				'condition' => [
					'style' => '2',
				],
			]
		);
		$this->add_control(
			'title', [
				'label' => esc_html__( 'Title', 'edrio-plugin' ),
				'type' => Controls_Manager::TEXT,
                'label_block' => true,
				'condition' => [
					'style' => ['2', '4', '7'],
				],
			]
		);
		$this->add_control(
			'counter', [
				'label' => esc_html__( 'Counter', 'edrio-plugin' ),
				'type' => Controls_Manager::TEXT,
                'label_block' => true,
				'condition' => [
					'style' => ['2', '7'],
				],
			]
		);
		$this->add_control(
			'suffix', [
				'label' => esc_html__( 'Suffix', 'edrio-plugin' ),
				'type' => Controls_Manager::TEXT,
                'label_block' => true,
				'condition' => [
					'style' => '2',
				],
			]
		);
		$this->add_control(
			'prefix', [
				'label' => esc_html__( 'Prefix', 'edrio-plugin' ),
				'type' => Controls_Manager::TEXT,
                'label_block' => true,
				'condition' => [
					'style' => ['2', '7'],
				],
			]
		);
		$this->end_controls_section();


	}


	protected function render() {
		$settings = $this->get_settings_for_display();
        require __DIR__ . '/image-template/image-' . $settings['style'] . '.php';
    }


}


Plugin::instance()->widgets_manager->register( new Edrios_Image() );