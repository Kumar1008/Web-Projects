<?php if(!empty($settings['img_1']['url'])):?>
<span class="ed-blog5-shape ed_left_img position-absolute">
    <img src="<?php echo esc_url($settings['img_1']['url']);?>" alt="<?php if(!empty($settings['img_1']['alt'])){ echo esc_attr($settings['img_1']['alt']);}?>">
</span>
<?php endif;?>