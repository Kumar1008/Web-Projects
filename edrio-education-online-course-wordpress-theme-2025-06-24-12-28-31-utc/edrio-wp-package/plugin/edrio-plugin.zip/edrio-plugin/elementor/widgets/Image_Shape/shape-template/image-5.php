<?php if(!empty($settings['img_1']['url'])):?>
    <div class="ed-wc5-sec">
        <span class="ed-wc5-shape left_view position-absolute">
            <img src="<?php echo esc_url($settings['img_1']['url']);?>" alt="<?php if(!empty($settings['img_1']['alt'])){ echo esc_url($settings['img_1']['alt']);}?>">
        </span>
    </div>
<?php endif;?>

