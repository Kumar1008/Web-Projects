<?php if(!empty($settings['img_1']['url'])):?>
    <span class="ed-mf-vector1 right_view position-absolute">
        <img src="<?php echo esc_url($settings['img_1']['url']);?>" alt="<?php if(!empty($settings['img_1']['alt'])){ echo esc_url($settings['img_1']['alt']);}?>">
    </span>
<?php endif;?>