<div class="ed-ab-review-wrap d-flex align-items-center justify-content-between">
    <div class="ed-ab-review headline ul-li">
        <?php if(!empty($settings['counter'])):?>
            <h3><?php echo edrio_wp_kses($settings['counter'])?></h3>
        <?php endif;?>
        <ul>
            <?php for($i=0; $i< $settings['rating']; $i++):?>
                <li><i class="fa-solid fa-star"></i></li>   
            <?php endfor;?>
        </ul>
        <?php if(!empty($settings['title'])):?>
            <span><?php echo edrio_wp_kses($settings['title'])?></span>
        <?php endif;?>
    </div>
    <div class="ed-ab-review-list ul-li-block">
        <ul>
            <?php foreach($settings['links'] as $item):?>
                <li class="top_view">
                    <?php \Elementor\Icons_Manager::render_icon( $item['icon'], [ 'aria-hidden' => 'true' ] ); ?>
                    <?php echo edrio_wp_kses($item['title'])?>
                </li>
            <?php endforeach;?>
        </ul>
    </div>
</div>