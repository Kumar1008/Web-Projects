<div class="ed-intro-feature d-flex justify-content-between ul-li-block">
    <ul>
    <?php foreach($settings['links'] as $item):?>
        <li class="top_view">
        <?php \Elementor\Icons_Manager::render_icon( $item['icon'], [ 'aria-hidden' => 'true' ] ); ?>
        <?php echo edrio_wp_kses($item['title'])?>
        </li>
    <?php endforeach;?>
    </ul>
        <?php if(!empty($settings['pricings'])):?>
        <div class="intro-salary headline-2">
            <?php if(!empty($settings['title'])):?>
                <h3>
                    <?php echo edrio_wp_kses($settings['title']);?>
                </h3>
            <?php endif;?>

            <?php $i = 0; foreach($settings['pricings'] as $item): $i++;?>
            <div class="in-sl-item item-<?php echo esc_attr($i);?>">
            <?php if(!empty($item['title'])):?>
                <span>
                   <?php echo edrio_wp_kses($item['title']);?>
                </span>
                <?php endif;?>
                <?php if(!empty($item['price'])):?>
                <span>
                     <?php echo edrio_wp_kses($item['price']);?>
                </span>
                <?php endif;?>
            </div>
            <?php endforeach;?>
            
        </div>
        <?php endif;?>
</div>