<div class="ed-counter4-text ul-li-block">
    <ul>
        <?php foreach($settings['links'] as $item):?>
            <li class="top_view">
            <?php \Elementor\Icons_Manager::render_icon( $item['icon'], [ 'aria-hidden' => 'true' ] ); ?>
            <?php echo edrio_wp_kses($item['title'])?>
            </li>
        <?php endforeach;?>
    </ul>
</div>