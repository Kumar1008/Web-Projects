<div class="ed-footer5-newsletter-form  mb-35 pb-50 d-flex headline-5">
    <?php if(!empty($settings['title'])):?>
        <h3 class="ed-sec-tt-anim ed-has-anim"><?php echo edrio_wp_kses($settings['title'])?></h3>
    <?php endif;?>
    <?php 
        if(!empty($settings['shortcode'])){
            echo do_shortcode($settings['shortcode']);
        }
    ?>
</div>