<?php 
    if ( ! empty( $settings['btn_link']['url'] ) ) {
        $this->add_link_attributes( 'btn_link', $settings['btn_link'] );
    }
?>
<div class="wow fadeInUp" <?php if(!empty($settings['animas'])):?>  data-wow-delay="<?php echo esc_attr($settings['animas']);?>" data-wow-duration="1000ms" <?php endif;?>>
    <div class="ed-price-item <?php if($settings['active'] === 'yes'):?> highlight-item <?php endif;?>">
        <div class="item-top">
            <?php if(!empty($settings['img']['url'])):?>
                <div class="item-icon">
                    <img src="<?php echo esc_url($settings['img']['url']);?>" alt="<?php if(!empty($settings['img']['alt'])){ echo esc_attr($settings['img']['alt']);}else{esc_attr_e('List', 'edrio-plugin');}?>">
                </div>
            <?php endif;?>
            <div class="item-text headline pera-content">
            <?php if(!empty($settings['title'])):?>
                <h3><?php echo edrio_wp_kses($settings['title'])?></h3>
            <?php endif;?>
                <span><?php echo edrio_wp_kses($settings['currency'])?><?php echo edrio_wp_kses($settings['price'])?><?php if(!empty($settings['period'])):?><span><?php echo edrio_wp_kses($settings['period'])?></span><?php endif;?></span>
            </div>
        </div>
        <?php if(!empty($settings['text'])):?>
            <div class="item-desc pera-content">
                <p><?php echo edrio_wp_kses($settings['text'])?></p>
            </div>
        <?php endif;?>
        <div class="item-list ul-li-block">
            <ul>
                <?php foreach($settings['lists'] as $list):?>   
                    <li><i class="fa-solid fa-circle-check"></i> <?php echo edrio_wp_kses($list['title']);?></li>
                <?php endforeach;?>
            </ul>
        </div>
        <?php if(!empty($settings['btn_label'])):?>
            <div class="item-btn btn-spin mt-45 text-center">
                <a <?php echo $this->get_render_attribute_string( 'btn_link' ); ?>><?php echo edrio_wp_kses($settings['btn_label']);?></a>
            </div>
        <?php endif;?>
        <?php if(!empty($settings['trile_text'])):?>
            <div class="price-slug text-center"><span><?php echo edrio_wp_kses($settings['trile_text']);?></span></div>
        <?php endif;?>
    </div>
</div>