<?php

/**
 * Elementor Single Widget
 * @package edrio Tools
 * @since 1.0.0
 */

namespace Elementor;

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly.

class Edrio_Pricing_Table extends Widget_Base {

	/**
	 * Get widget name.
	 *
	 * Retrieve Elementor widget name.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget name.
	 */
	public function get_name() {
		return 'edrio-prc-table';
	}

	/**
	 * Get widget title.
	 *
	 * Retrieve Elementor widget title.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget title.
	 */
	public function get_title() {
		return esc_html__( 'Pricing Table', 'edrio-plugin' );
	}

	/**
	 * Get widget icon.
	 *
	 * Retrieve Elementor widget icon.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget icon.
	 */
	public function get_icon() {
		return 'edrio-custom-icon';
	}

	/**
	 * Get widget categories.
	 *
	 * Retrieve the list of categories the Elementor widget belongs to.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return array Widget categories.
	 */
	public function get_categories() {
		return [ 'edrio_widgets' ];
	}


	protected function register_controls() {

        $this->start_controls_section(
			'int_heading_opt',
			[
				'label' => esc_html__( 'Icon Option', 'edrio-plugin' ),
				'tab'   => Controls_Manager::TAB_CONTENT,
			]
		);
		$this->add_control(
			'active',
			[
				'label' => esc_html__( 'Active Item', 'edrio-plugin' ),
				'type' => \Elementor\Controls_Manager::SWITCHER,
				'label_on' => esc_html__( 'YES', 'edrio-plugin' ),
				'label_off' => esc_html__( 'NO', 'edrio-plugin' ),
				'return_value' => 'yes',
				'default' => 'yes',
			]
		);
		
        $this->add_control(
			'animas', [
				'label' => esc_html__( 'Animation Speed', 'edrio-plugin' ),
				'type' => Controls_Manager::TEXT,
                'label_block' => true,
			]
		);
		
        $this->add_control(
			'img', [
				'label' => esc_html__( 'Price Image', 'edrio-plugin' ),
				'type' => Controls_Manager::MEDIA,
                'label_block' => true,
			]
		);
        $this->add_control(
			'title', [
				'label' => esc_html__( 'Title', 'edrio-plugin' ),
				'default' => esc_html__( 'Section Title', 'edrio-plugin' ),
				'type' => Controls_Manager::TEXTAREA,
                'label_block' => true,
			]
		);
        $this->add_control(
			'text', [
				'label' => esc_html__( 'Pricing  Text', 'edrio-plugin' ),
				'type' => Controls_Manager::TEXTAREA,
                'label_block' => true,
			]
		);
        $this->add_control(
			'currency', [
				'label' => esc_html__( 'Currency', 'edrio-plugin' ),
				'default' => esc_html__( '$', 'edrio-plugin' ),
				'type' => Controls_Manager::TEXT,
                'label_block' => true,
			]
		);
        $this->add_control(
			'price', [
				'label' => esc_html__( 'Monthly Price', 'edrio-plugin' ),
				'type' => Controls_Manager::TEXT,
                'label_block' => true,
			]
		);
        $this->add_control(
			'period', [
				'label' => esc_html__( 'Period', 'edrio-plugin' ),
				'type' => Controls_Manager::TEXT,
                'label_block' => true,
			]
		);
        $repeater = new \Elementor\Repeater();
		
        $repeater->add_control(
			'title', [
				'label' => esc_html__( 'Title', 'cantia-plugin' ),
				'default' => esc_html__( 'Section Title', 'cantia-plugin' ),
				'type' => Controls_Manager::TEXTAREA,
                'label_block' => true,
			]
		);
        
		$this->add_control(
			'lists',
			[
				'label' => esc_html__( 'Add List Item', 'cantia-plugin' ),
				'type' => \Elementor\Controls_Manager::REPEATER,
				'fields' => $repeater->get_controls(),
				'title_field' => '{{{ title }}}',
			]
		);
        $this->add_control(
			'btn_label', [
				'label' => esc_html__( 'Button Label', 'edrio-plugin' ),
				'default' => esc_html__( 'edrio Button', 'edrio-plugin' ),
				'type' => Controls_Manager::TEXT,
                'label_block' => true,
			]
		);
        $this->add_control(
			'btn_link', [
				'label' => esc_html__( 'Button Link', 'edrio-plugin' ),
				'type' => Controls_Manager::URL,
                'default' => [
					'url' => '',
					'is_external' => true,
					'nofollow' => true,
					// 'custom_attributes' => '',
				],
				'label_block' => true,
			]
		);
		$this->add_control(
			'trile_text', [
				'label' => esc_html__( 'Trile Text', 'edrio-plugin' ),
				'type' => Controls_Manager::TEXT,
                'label_block' => true,
			]
		);
		$this->end_controls_section();

		$this->start_controls_section(
			'price__box_style',
			[
				'label' => esc_html__( 'Pricing Box Style', 'edrio-plugin' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);
		
        $this->add_control(
			'pricing-box-bg-color',
			[
				'label' => esc_html__( 'Pricing Box BG Color', 'edrio-plugin' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .agn-price-1-card' => 'background: {{VALUE}}'
				],
			]
		);
        $this->add_control(
			'pricing-box-border-color',
			[
				'label' => esc_html__( 'Pricing Box Border Color', 'edrio-plugin' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .agn-price-1-card' => 'border-color: {{VALUE}}'
				],
			]
		);
		
       
		$this->end_controls_section();
		$this->start_controls_section(
			'price__text_style',
			[
				'label' => esc_html__( 'Pricing Text Style', 'edrio-plugin' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);
        $this->add_control(
			'text-color',
			[
				'label' => esc_html__( 'Pricing Text Color', 'edrio-plugin' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .agn-price-1-card .card-title' => 'color: {{VALUE}}',
					'{{WRAPPER}} .agn-price-1-card .price-feature li' => 'color: {{VALUE}}',
					'{{WRAPPER}} .agn-price-1-card .card-btn' => 'color: {{VALUE}}'
				],
			]
		);
		
       
		$this->end_controls_section();
        
	}


	protected function render() {
		$settings = $this->get_settings_for_display();
		require __DIR__ . '/pricing-template/pricing.php';
    }


}


Plugin::instance()->widgets_manager->register( new Edrio_Pricing_Table() );