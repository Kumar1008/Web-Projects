<div class="ed-process6-wrap position-relative">

<?php if(!empty($settings['title'])):?>
    <div class="ed-sec-title-6 headline-6 pera-content">
        <h2 class="sec_title ed-sec-tt-anim ed-has-anim"><?php echo edrio_wp_kses($settings['title']);?><span class="has-dot">.</span></h2>
    </div>
    <?php endif;?>
    <div class="ed-process6-content top_view d-flex justify-content-center">
        <?php foreach($settings['boxes'] as $item):?>
            <div class="ed-process6-item text-center">
                <?php if(!empty($item['count'])):?>
                    <span><?php echo edrio_wp_kses($item['count']);?></span>
                <?php endif;?>
                <div class="inner-item headline-6 pera-content">
                    <h3><?php echo edrio_wp_kses($item['title']);?></h3>
                    <p><?php echo edrio_wp_kses($item['desc']);?></p>
                </div>
            </div>
        <?php endforeach;?>
        
    </div>
    <div class="ed-process6-bottom">
        <?php if(!empty($settings['shape']['url'])):?>
            <div class="shape-img1 right_view mb-25">
                <img src="<?php echo esc_url($settings['shape']['url']);?>" alt="<?php if(!empty($settings['shape']['alt'])){ echo esc_url($settings['shape']['alt']);}?>">
            </div>
        <?php endif;?>
        <?php if(!empty($settings['shape_2']['url'])):?>
            <div class="shape-img2">
                <img src="<?php echo esc_url($settings['shape_2']['url']);?>" alt="<?php if(!empty($settings['shape_2']['alt'])){ echo esc_url($settings['shape_2']['alt']);}?>">
            </div>
        <?php endif;?>
        <?php if(!empty($settings['description'])):?>
        <div class="item-text ed-text pera-content">
            <p><?php echo edrio_wp_kses($settings['description']);?></p>
        </div>
        <?php endif;?>
    </div>
</div>