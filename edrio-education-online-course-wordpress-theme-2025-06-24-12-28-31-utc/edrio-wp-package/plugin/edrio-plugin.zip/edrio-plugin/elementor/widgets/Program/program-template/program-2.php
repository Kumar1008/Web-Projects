<div class="ed-program-content">
    <div class="row justify-content-center">
        <?php foreach ($settings['projects'] as $item): ?>
            <div class="col-lg-4 col-md-6">
                <div class="ed-program-item">
                    <div class="item-img position-relative">
                        <div class="inner-img">
                        <img src="<?php echo esc_url($item['project_img']['url']);?>" alt="<?php if(!empty($item['project_img']['alt'])){ echo esc_attr($item['project_img']['alt']);}?>"  />
                        </div>
                        <?php if(!empty($item['category'])):?>
                            <span class="sale_tag"><?php echo edrio_wp_kses($item['category']);?></span>
                        <?php endif;?>
                    </div>
                    <div class="item-text ul-li headline-2 pera-content">
                        <?php if(!empty($item['badge'])):?>
                            <div class="pro-meta">
                                <a href="#"><?php echo edrio_wp_kses($item['badge']);?></a>
                                <?php if(!empty($item['rating'])):?>
                                    <span><i class="fa-solid fa-star"></i> <?php echo esc_html($item['rating']);?></span>
                                <?php endif;?>
                            </div>
                        <?php endif;?>
                        <h3 class="prog_title href-underline">
                        <?php
                            $link_url     = !empty( $item['link']['url'] ) ? esc_url( $item['link']['url'] ) : '#';
                            $is_external  = !empty( $item['link']['is_external'] ) ? '_blank' : '_self';
                            $nofollow     = !empty( $item['link']['nofollow'] ) ? 'nofollow' : '';
                            ?>

                            <a 
                                href="<?php echo $link_url; ?>" 
                                target="<?php echo esc_attr( $is_external ); ?>" 
                                rel="<?php echo esc_attr( $nofollow ); ?>"
                            >
                                <?php echo edrio_wp_kses($item['title']);?>
                            </a>
                        </h3>
                        <?php if(!empty($item['tags'])):?>
                            <div class="prog_tag">
                                <?php foreach($item['tags'] as $tag):?>
                                    <a href="<?php echo esc_url($tag['link']['url']);?>"><?php echo edrio_wp_kses($tag['tag']);?></a>
                                <?php endforeach;?>
                            </div>
                        <?php endif;?>
                        
                        <?php if(!empty($item['tags2'])):?>
                            <ul>
                                <?php foreach($item['tags2'] as $tag):?>
                                    <li><?php echo edrio_wp_kses($tag['tag']);?></li>
                                <?php endforeach;?>
                            </ul>
                        <?php endif;?>
                        <?php if(!empty($item['btn_label'])):?>
                            <a class="view_more d-block text-center"
                                href="<?php echo $link_url; ?>" 
                                target="<?php echo esc_attr( $is_external ); ?>" 
                                rel="<?php echo esc_attr( $nofollow ); ?>"
                                ><span><?php echo edrio_wp_kses($item['btn_label']);?> <i class="fa-solid fa-right-long"></i></span></a>
                        <?php endif;?>
                    </div>
                </div>
            </div>
        <?php endforeach;?>
    </div>
</div>