<?php 
    $this->add_render_attribute( 'title', 'class', 'elementor-gt-heading sec_title  ed-sec-tt-anim ed-has-anim' );
?>
<section id="ed-activities" class="ed-activities-sec pb-140">
  	<div class="container">
  		<div class="ed-acti-top mb-65 d-flex align-items-end justify-content-between flex-wrap">
  			<div class="ed-sec-title-3  headline-3 pera-content">
              <?php if(!empty($settings['subtitle'])):?>
  				<div class="subtitle  ed-sec-tt-anim ed-has-anim-char"><?php echo edrio_wp_kses($settings['subtitle']);?></div>
                <?php endif;?>
  				<?php 
                    printf('<%1$s %2$s>%3$s</%1$s>',
                        tag_escape($settings['title_tag']),
                        $this->get_render_attribute_string('title'),
                        nl2br(edrio_wp_kses($settings['title']))
                    ); 
                ?>
  			</div>
  			<div class="ed-acti-filter-btn">
  				<div class="button-group p-filter-btn  clearfix">
  					<button class="filter-button is-checked" data-filter="*"><?php echo edrio_wp_kses($settings['filter_text'])?></button>
                    <?php foreach ($settings['filters'] as $item): ?>
  					    <button class="filter-button" data-filter=".<?php echo esc_attr($item['filter_id']);?>"><?php echo edrio_wp_kses($item['title'])?></button>
                    <?php endforeach; ?>
  				</div>
  			</div>
  		</div>
  	</div>
  	<div class="filtr-container-area p-filter-area grid clearfix" data-isotope="{ &quot;masonry&quot;: { &quot;columnWidth&quot;: 0 } }">
  		<div class="grid-sizer"></div>
        <?php foreach ($settings['projects'] as $item): ?>
  		<div class="grid-item grid-size-33 <?php echo esc_attr($item['filter_id']);?>" data-category="<?php echo esc_attr($item['filter_id']);?>">
  			<div class="ed-activity-item position-relative">
                <?php if(!empty($item['project_img']['url'])):?>
  				<div class="item-img">
                    <img src="<?php echo esc_url($item['project_img']['url']);?>" alt="<?php if(!empty($item['project_img']['alt'])){ echo esc_attr($item['project_img']['alt']);}?>"  />
  				</div>
                <?php endif;?>
  				<div class="item-text text-center">
  					<div class="inner-icon">
                      <?php
                        $link_url     = !empty( $item['link']['url'] ) ? esc_url( $item['link']['url'] ) : '#';
                        $is_external  = !empty( $item['link']['is_external'] ) ? '_blank' : '_self';
                        $nofollow     = !empty( $item['link']['nofollow'] ) ? 'nofollow' : '';
                        ?>

                        <a 
                            href="<?php echo $link_url; ?>" 
                            target="<?php echo esc_attr( $is_external ); ?>" 
                            rel="<?php echo esc_attr( $nofollow ); ?>"
                        >
                            <i class="fa-solid fa-plus"></i>
                        </a>
  					</div>
  					<div class="inner-text headline-3">
  						<h3 class="href-underline">
                          <?php
                            $link_url     = !empty( $item['link']['url'] ) ? esc_url( $item['link']['url'] ) : '#';
                            $is_external  = !empty( $item['link']['is_external'] ) ? '_blank' : '_self';
                            $nofollow     = !empty( $item['link']['nofollow'] ) ? 'nofollow' : '';
                            ?>

                            <a 
                                href="<?php echo $link_url; ?>" 
                                target="<?php echo esc_attr( $is_external ); ?>" 
                                rel="<?php echo esc_attr( $nofollow ); ?>"
                            >
                                <?php echo edrio_wp_kses($item['title']);?>
                            </a>
                        </h3>
  					</div>
  				</div>
  			</div>
  		</div>
        <?php endforeach;?>
  	</div>
  </section>