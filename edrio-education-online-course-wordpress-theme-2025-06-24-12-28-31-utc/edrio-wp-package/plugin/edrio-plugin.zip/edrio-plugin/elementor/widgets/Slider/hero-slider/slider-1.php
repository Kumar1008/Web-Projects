<section id="ed-hero-slider-1" class="ed-hero-slider-sec">
    <div class="ed-hs-slide-active swiper-container">
        <div class="swiper-wrapper">
            <?php foreach($settings['sliders'] as $item):?>
            <div class="swiper-slide">
                <div class="ed-hs-slide-item position-relative">
                    <?php if(!empty($item['hero_bg']['url'])):?>
                        <div class="slide-bg position-absolute">
                            <img src="<?php echo esc_url($item['hero_bg']['url']);?>" alt="<?php if(!empty($item['hero_bg']['alt'])){ echo esc_attr($item['hero_bg']['alt']);}?>">
                        </div>
                    <?php endif;?>
                    <div class="container">
                        <div class="ed-hs-slide-content">
                            <div class="ed-hs-img-wrap d-flex">
                            <?php if(!empty($item['hero_img']['url'])):?>
                                <div class="item-img-1">
                                    <div class="inner-img">
                                        <img src="<?php echo esc_url($item['hero_img']['url']);?>" alt="<?php if(!empty($item['hero_img']['alt'])){ echo esc_attr($item['hero_img']['alt']);}?>">
                                    </div>
                                </div>
                            <?php endif;?>
                                <?php if(!empty($item['video']['url'])):?>
                                <div class="item-img-2">
                                    <div class="inner-img">
                                        <video width="100%" height="100%" loop="" muted="" playsinline="true"  autoplay="true" src="<?php echo esc_url($item['video']['url']);?>"></video>
                                    </div>
                                </div>
                                <?php endif;?>

                            <?php if(!empty($item['hero_img2']['url'])):?>
                                <div class="item-img-3">
                                    <div class="inner-img">
                                        <img src="<?php echo esc_url($item['hero_img2']['url']);?>" alt="<?php if(!empty($item['hero_img2']['alt'])){ echo esc_attr($item['hero_img2']['alt']);}?>">
                                    </div>
                                </div>
                            <?php endif;?>
                            </div>
                            <div class="ed-hs-text-wrap text-center headline-2 pera-content">
                                <?php if(!empty($item['sub_title'])):?>
                                    <div class="hs-slug">
                                        <?php echo edrio_wp_kses($item['sub_title']);?>
                                    </div>
                                <?php endif;?>
                                <?php if(!empty($item['title'])):?>
                                    <h1 class="slider_title ed-split-word"><?php echo edrio_wp_kses($item['title']);?></h1>
                                <?php endif;?>

                                <?php if(!empty($item['description'])):?>
                                    <p class="ed-split-line"><?php echo edrio_wp_kses($item['description']);?></p>
                                <?php endif;?>
                                <?php if(!empty($item['btn_label'])):?>
                                    <div class="ed-btn-2 mt-30">
                                        <a target="<?php echo esc_attr( $item['btn_link']['is_external'] ? '_blank' : '_self' ); ?>" rel="<?php echo esc_attr( $item['btn_link']['nofollow'] ? 'nofollow' : '' ); ?>" href="<?php echo esc_url($item['btn_link']['url']);?>"><?php echo edrio_wp_kses($item['btn_label']);?> <i class="fa-solid fa-right-long"></i></a>
                                    </div>
                                <?php endif;?>
                            </div>
                        </div>
                    </div>
                </div>
            </div> 
            <?php endforeach;?>

        </div>
    </div>
</section>