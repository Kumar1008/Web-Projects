<section id="ed-hero-slider-3" class="ed-hero-slider-sec-3">
<div class="ed-hs-slide-3 swiper-container">
    <div class="swiper-wrapper">
    <?php foreach($settings['sliders'] as $item):?>
        <div class="swiper-slide">
            <div class="ed-hs-slide-item-wrap position-relative">
                <?php if(!empty($item['hero_img']['url'])):?>
                <span class="ed-ds1 position-absolute">
                    <img src="<?php echo esc_url($item['hero_img']['url']);?>" alt="<?php if(!empty($item['hero_img']['alt'])){ echo esc_attr($item['hero_img']['alt']);}?>">
                </span>
                <?php endif;?>
                <?php if(!empty($item['hero_img2']['url'])):?>
                <span class="ed-ds2 position-absolute">
                    <img src="<?php echo esc_url($item['hero_img2']['url']);?>" alt="<?php if(!empty($item['hero_img2']['alt'])){ echo esc_attr($item['hero_img2']['alt']);}?>">
                </span>
                <?php endif;?>
                
                <div class="ed-hs-slide-item-3 position-relative" <?php if(!empty($item['hero_bg']['url'])):?> data-background="<?php echo esc_url($item['hero_bg']['url']);?>" <?php endif;?>>

                <?php if(!empty($item['hero_img3']['url'])):?>
                    <span class="ed-h-shape1 position-absolute">
                        <img src="<?php echo esc_url($item['hero_img3']['url']);?>" alt="<?php if(!empty($item['hero_img3']['alt'])){ echo esc_attr($item['hero_img3']['alt']);}?>">
                    </span>
                <?php endif;?>
                    <div class="ed-hs-wrap position-absolute">
                    <?php if(!empty($item['hero_img4']['url'])):?>
                        <span class="ed-h-shape2">
                            <img src="<?php echo esc_url($item['hero_img4']['url']);?>" alt="<?php if(!empty($item['hero_img4']['alt'])){ echo esc_attr($item['hero_img4']['alt']);}?>">
                        </span>
                    <?php endif;?>
                    <?php if(!empty($item['hero_img5']['url'])):?>
                        <span class="ed-h-shape3 position-absolute">
                            <img src="<?php echo esc_url($item['hero_img5']['url']);?>" alt="<?php if(!empty($item['hero_img5']['alt'])){ echo esc_attr($item['hero_img5']['alt']);}?>">
                        </span>
                        <?php endif;?>
                    </div>
                    <?php if(!empty($item['hero_img6']['url'])):?>
                        <span class="ed-h-shape4 position-absolute">
                            <img src="<?php echo esc_url($item['hero_img6']['url']);?>" alt="<?php if(!empty($item['hero_img6']['alt'])){ echo esc_attr($item['hero_img6']['alt']);}?>">
                        </span>
                    <?php endif;?>
                    <?php if(!empty($item['hero_img7']['url'])):?>
                        <span class="ed-h-shape5 position-absolute">
                            <img src="<?php echo esc_url($item['hero_img7']['url']);?>" alt="<?php if(!empty($item['hero_img7']['alt'])){ echo esc_attr($item['hero_img7']['alt']);}?>">
                        </span>
                    <?php endif;?>

                    <?php if(!empty($item['hero_img8']['url'])):?>
                        <span class="ed-h-shape6 position-absolute">
                            <img src="<?php echo esc_url($item['hero_img8']['url']);?>" alt="<?php if(!empty($item['hero_img8']['alt'])){ echo esc_attr($item['hero_img8']['alt']);}?>">
                        </span>
                    <?php endif;?>
                    <?php if(!empty($item['hero_img9']['url'])):?>
                        <span class="ed-h-shape7 position-absolute">
                            <img src="<?php echo esc_url($item['hero_img9']['url']);?>" alt="<?php if(!empty($item['hero_img9']['alt'])){ echo esc_attr($item['hero_img9']['alt']);}?>">
                        </span>
                    <?php endif;?>
                    <?php if(!empty($item['hero_img10']['url'])):?>
                        <span class="ed-h-shape8 position-absolute">
                            <img src="<?php echo esc_url($item['hero_img10']['url']);?>" alt="<?php if(!empty($item['hero_img10']['alt'])){ echo esc_attr($item['hero_img10']['alt']);}?>">
                        </span>
                    <?php endif;?>
                    <?php if(!empty($item['hero_img11']['url'])):?>
                        <span class="ed-h-shape9 position-absolute">
                            <img src="<?php echo esc_url($item['hero_img11']['url']);?>" alt="<?php if(!empty($item['hero_img11']['alt'])){ echo esc_attr($item['hero_img11']['alt']);}?>">
                        </span>
                    <?php endif;?>
                    <?php if(!empty($item['hero_img12']['url'])):?>
                        <span class="ed-h-shape10 position-absolute">
                            <img src="<?php echo esc_url($item['hero_img12']['url']);?>" alt="<?php if(!empty($item['hero_img12']['alt'])){ echo esc_attr($item['hero_img12']['alt']);}?>">
                        </span>
                    <?php endif;?>
                    <?php if(!empty($item['hero_img13']['url'])):?>
                        <span class="ed-h-shape11 position-absolute">
                            <img src="<?php echo esc_url($item['hero_img13']['url']);?>" alt="<?php if(!empty($item['hero_img13']['alt'])){ echo esc_attr($item['hero_img13']['alt']);}?>">
                        </span>
                    <?php endif;?>

                    <?php if(!empty($item['hero_img14']['url'])):?>
                        <span class="ed-h-shape12 position-absolute">
                            <img src="<?php echo esc_url($item['hero_img14']['url']);?>" alt="<?php if(!empty($item['hero_img14']['alt'])){ echo esc_attr($item['hero_img14']['alt']);}?>">
                        </span>
                    <?php endif;?>
                    <div class="container">
                        <div class="ed-hs-slide-content-2 position-relative">
                        <?php if(!empty($item['hero_img15']['url'])):?>
                            <div class="ed-slide-img-2">
                                <div class="img-wrapper position-relative">
                                    <div class="item-img">
                                        <img src="<?php echo esc_url($item['hero_img15']['url']);?>" alt="<?php if(!empty($item['hero_img15']['alt'])){ echo esc_attr($item['hero_img15']['alt']);}?>">
                                    </div>
                                </div>
                            </div> 
                        <?php endif;?>
                            <div class="ed-slide-text-2 headline-3 pera-content">
                            <?php if(!empty($item['sub_title'])):?>
                                <span class="slide-slug ed-split-word"><?php echo edrio_wp_kses($item['sub_title']);?></span>
                            <?php endif;?>
                                <?php if(!empty($item['title'])):?>
                                    <h1 class="slide_title ed-split-char"><?php echo edrio_wp_kses($item['title']);?></h1>
                                <?php endif;?>
                                <?php if(!empty($item['description'])):?>
                                    <p class="ed-split-line"><?php echo edrio_wp_kses($item['description']);?></p>
                                <?php endif;?>
                                <?php if(!empty($item['btn_label'])):?>
                                    <div class="ed-btn-3">
                                        <a target="<?php echo esc_attr( $item['btn_link']['is_external'] ? '_blank' : '_self' ); ?>" rel="<?php echo esc_attr( $item['btn_link']['nofollow'] ? 'nofollow' : '' ); ?>" href="<?php echo esc_url($item['btn_link']['url']);?>"><span data-back="<?php echo edrio_wp_kses($item['btn_label']);?>" data-front="<?php echo edrio_wp_kses($item['btn_label']);?>"></span> 
                                        <?php if(!empty($settings['btn_arrow']['url'])):?>
                                            <img src="<?php echo esc_url($settings['btn_arrow']['url']);?>" alt="<?php if(!empty($settings['btn_arrow']['alt'])){ echo esc_attr($settings['btn_arrow']['alt']);}?>">
                                        <?php endif;?>
                                        </a>
                                    </div>
                                <?php endif;?>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    <?php endforeach;?>
    </div>
    <div class="ed-hs-nav d-flex justify-content-center">
        <?php if(!empty($settings['arrow_prev']['url'])):?>
            <div class="ed-hs-prev arrow-nav d-flex justify-content-center align-items-center">
                <img src="<?php echo esc_url($settings['arrow_prev']['url']);?>" alt="<?php if(!empty($settings['arrow_prev']['alt'])){ echo esc_attr($settings['arrow_prev']['alt']);}?>">
            </div>
        <?php endif;?>
        <?php if(!empty($settings['arrow_next']['url'])):?>
            <div class="ed-hs-next arrow-nav d-flex justify-content-center align-items-center">
                <img src="<?php echo esc_url($settings['arrow_next']['url']);?>" alt="<?php if(!empty($settings['arrow_next']['alt'])){ echo esc_attr($settings['arrow_next']['alt']);}?>">
            </div>
        <?php endif;?>
    </div>
</div>
</section>