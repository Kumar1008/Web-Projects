<section id="ed-hs5" class="ed-hs5-sec">
    <div class="ed-hs5-slider-area position-relative">
        <div class="ed-hs5-slider swiper-container">
            <div class="swiper-wrapper">

            <?php foreach($settings['sliders'] as $item):?>
                <div class="swiper-slide">
                    <div class="ed-hs5-slide-item position-relative">
                        <div class="ed-hs5-side">
                            <span class="shape_1"></span>	
                            <span class="shape_2"></span>	
                        </div>
                        <div class="ed-hs5-shape1">
                            <span class="shape_1"></span>	
                            <span class="shape_2"></span>	
                        </div>
                        <div class="ed-hs5-sh3">
                            <div class="box_dec_1">
                                <svg width="128" height="128" viewBox="0 0 128 128" fill="none" xmlns="http://www.w3.org/2000/svg">
                                    <path d="M128 128V0H126.905C57.0859 0.581944 0.581944 57.0859 0 126.905V128H128Z" fill="#111218"/>
                                </svg>
                            </div>
                            <div class="box_dec_2">
                                <svg width="128" height="128" viewBox="0 0 128 128" fill="none" xmlns="http://www.w3.org/2000/svg">
                                    <g class="animate-fluid">
                                        <clipPath id="clipPathSliderMarker"> <rect x="0" y="-100" width="228" height="228" rx="0" class="clip_path"> </rect> </clipPath>
                                        <g clip-path="url(#clipPathSliderMarker)"> <rect x="-100" y="0" width="228" height="228" fill="#C3F498" rx="100" class="clip_path_2"></rect> </g>
                                    </g>
                                </svg>
                            </div>
                        </div>
                        <div class="ed-hs5-sh7 d-flex">
                            <div class="box_dec_1">
                                <svg width="128" height="128" viewBox="0 0 128 128" fill="none" xmlns="http://www.w3.org/2000/svg">
                                    <path d="M128 0C57.3093 0 0 57.3061 0 128H128V0Z" fill="#fff"/>
                                </svg>
                            </div>
                            <div class="box_dec_2">
                                <svg width="128" height="128" viewBox="0 0 128 128" fill="none" xmlns="http://www.w3.org/2000/svg">
                                    <path d="M0 0V128H128C128 57.3061 70.6907 0 0 0Z" fill="#fff"/>
                                </svg>
                            </div>
                        </div>
                        <div class="container">
                            <div class="ed-hs5-content position-relative">
                                <div class="ed-hs5-circle">
                                    <?php if(!empty($item['hero_img']['url'])):?>
                                        <div class="item-icon d-flex justify-content-center align-items-center">
                                            <span>
                                                <img src="<?php echo esc_url($item['hero_img']['url']);?>" alt="<?php if(!empty($item['hero_img']['alt'])){ echo esc_attr($item['hero_img']['alt']);}?>">
                                            </span>
                                        </div>
                                    <?php endif;?>
                                    <?php if(!empty($item['hero_img2']['url'])):?>
                                        <div class="item-icon d-flex justify-content-center align-items-center">
                                            <span>
                                                <img src="<?php echo esc_url($item['hero_img2']['url']);?>" alt="<?php if(!empty($item['hero_img2']['alt'])){ echo esc_attr($item['hero_img2']['alt']);}?>">
                                            </span>
                                        </div>
                                    <?php endif;?>
                                    <?php if(!empty($item['hero_img3']['url'])):?>
                                        <div class="item-icon d-flex justify-content-center align-items-center">
                                            <span>
                                                <img src="<?php echo esc_url($item['hero_img3']['url']);?>" alt="<?php if(!empty($item['hero_img3']['alt'])){ echo esc_attr($item['hero_img3']['alt']);}?>">
                                            </span>
                                        </div>
                                    <?php endif;?>
                                </div>
                                <?php if(!empty($item['hero_img4']['url'])):?>
                                    <div class="ed-hs5-sh1">
                                        <span>
                                            <img src="<?php echo esc_url($item['hero_img4']['url']);?>" alt="<?php if(!empty($item['hero_img4']['alt'])){ echo esc_attr($item['hero_img4']['alt']);}?>">
                                        </span>
                                    </div>
                                <?php endif;?>
                                <div class="ed-hs5-sh2 d-flex flex-wrap">
                                    <div class="box_dec_1">
                                        <svg width="129" height="128" viewBox="0 0 129 128" fill="none" xmlns="http://www.w3.org/2000/svg">
                                            <path d="M128.184 121.179V127.854H0.621094V121.179H128.184ZM0.621094 106.121V112.797H128.184V106.121H0.621094ZM0.621094 91.0635V97.739H128.184V91.0635H0.621094ZM0.621094 75.9921V82.6676H128.184V75.9921H0.621094ZM0.621094 60.9345V67.61H128.184V60.9345H0.621094ZM0.621094 45.8768V52.5523H128.184V45.8768H0.621094ZM0.621094 30.8192V37.4946H128.184V30.8192H0.621094ZM0.621094 15.7615V22.437H128.184V15.7615H0.621094ZM0.621094 0.703857V7.37933H128.184V0.703857H0.621094Z" fill="white"/>
                                        </svg>
                                    </div>
                                    <div class="box_dec_2">
                                        <svg width="128" height="128" viewBox="0 0 128 128" fill="none" xmlns="http://www.w3.org/2000/svg">
                                            <path d="M128 128V81.4044C83.0449 81.4044 46.5956 44.9551 46.5956 0H0C0 70.6929 57.307 128 128 128Z" fill="white"/>
                                        </svg>
                                    </div>
                                    <div class="box_dec_3">
                                        <svg width="128" height="128" viewBox="0 0 128 129" fill="none" xmlns="http://www.w3.org/2000/svg">
                                            <rect x="-100" y="-100" width="228" height="228" rx="200" fill="#FF5C5B" transform="scale(0)" class="rect-1"></rect>
                                        </svg>
                                    </div>
                                    <div class="box_dec_4">
                                        <svg width="128" height="129" viewBox="0 0 128 129" fill="none" xmlns="http://www.w3.org/2000/svg">
                                            <rect x="-100" y="-100" width="228" height="228" rx="200" fill="#4AD2CC" transform="scale(0)" class="rect-2"></rect>
                                        </svg>
                                    </div>
                                </div>
                                <div class="ed-hs5-sh4">
                                    <svg width="128" height="128" viewBox="0 0 128 128" fill="none" xmlns="http://www.w3.org/2000/svg">
                                        <path d="M0 0V46.5956C44.9551 46.5956 81.4044 83.0449 81.4044 128H128C128 57.3071 70.6929 0 0 0Z" fill="white"/>
                                    </svg>
                                </div>
                                <div class="ed-hs5-sh5 d-flex">
                                    <div class="box_dec_1">
                                        <svg width="128" height="128" viewBox="0 0 128 128" fill="none" xmlns="http://www.w3.org/2000/svg">
                                            <path d="M128 0C57.3093 0 0 57.3061 0 128H128V0Z" fill="#2F584F"/>
                                        </svg>
                                    </div>
                                    <div class="box_dec_2">
                                        <svg width="128" height="128" viewBox="0 0 128 128" fill="none" xmlns="http://www.w3.org/2000/svg">
                                            <path d="M0 0V128H128C128 57.3061 70.6907 0 0 0Z" fill="#2F584F"/>
                                        </svg>
                                    </div>
                                </div>
                                <div class="ed-hs5-sh6 d-flex">
                                    <div class="box_dec_1">
                                        <svg width="128" height="128" viewBox="0 0 128 128" fill="none" xmlns="http://www.w3.org/2000/svg">
                                            <path d="M128 0C57.3093 0 0 57.3061 0 128H128V0Z" fill="#FF9960"/>
                                        </svg>
                                    </div>
                                </div>
                                <div class="ed-hs5-sh8 d-flex">
                                    <div class="box_dec_1">
                                        <svg width="128" height="128" viewBox="0 0 128 128" fill="none" xmlns="http://www.w3.org/2000/svg">
                                            <path d="M64 128C99.3462 128 128 99.3462 128 64C128 28.6538 99.3462 0 64 0C28.6538 0 0 28.6538 0 64C0 99.3462 28.6538 128 64 128Z" fill="#4AD2CC"/>
                                        </svg>
                                    </div>
                                </div>
                                <?php if(!empty($item['hero_img5']['url'])):?>
                                    <div class="ed-hs5-img position-absolute">
                                        <div class="item-img">
                                            <img src="<?php echo esc_url($item['hero_img5']['url']);?>" alt="<?php if(!empty($item['hero_img5']['alt'])){ echo esc_attr($item['hero_img5']['alt']);}?>">
                                        </div>
                                    </div>
                                <?php endif;?>  
                                <div class="ed-hs5-text headline-5 pera-content">
                                    <?php if(!empty($item['title'])):?>
                                        <h1 class="slide_title slider_title ed-split-word">
                                            <?php echo edrio_wp_kses($item['title']);?>
                                        </h1>
                                    <?php endif;?>
                                    <?php if(!empty($item['description'])):?>
                                        <p class="ed-split-line"><?php echo edrio_wp_kses($item['description']);?></p>
                                    <?php endif;?>
                                    <?php if(!empty($item['btn_label'])):?>
                                    <div class="ed-btn-5">
                                        <a target="<?php echo esc_attr( $item['btn_link']['is_external'] ? '_blank' : '_self' ); ?>" rel="<?php echo esc_attr( $item['btn_link']['nofollow'] ? 'nofollow' : '' ); ?>" href="<?php echo esc_url($item['btn_link']['url']);?>">
                                            <div class="ed_btn_text d-flex align-items-center">
                                                <span class="b-text"><?php echo edrio_wp_kses($item['btn_label']);?></span>
                                                <span class="b-icon">
                                                    <svg width="10" height="10" viewBox="0 0 10 10" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                        <path d="M1.66619 0.833333C1.66619 0.61232 1.75399 0.400358 1.91027 0.244078C2.06655 0.0877975 2.27851 0 2.49953 0H9.16619C9.38721 0 9.59917 0.0877975 9.75545 0.244078C9.91173 0.400358 9.99953 0.61232 9.99953 0.833333V7.5C9.99953 7.72101 9.91173 7.93297 9.75545 8.08926C9.59917 8.24554 9.38721 8.33333 9.16619 8.33333C8.94518 8.33333 8.73322 8.24554 8.57694 8.08926C8.42066 7.93297 8.33286 7.72101 8.33286 7.5V2.845L1.42203 9.75583C1.26486 9.90763 1.05436 9.99163 0.835858 9.98973C0.617361 9.98783 0.40835 9.90019 0.253844 9.74568C0.0993368 9.59118 0.0116958 9.38216 0.00979713 9.16367C0.00789844 8.94517 0.0918941 8.73467 0.243692 8.5775L7.15453 1.66667H2.49953C2.27851 1.66667 2.06655 1.57887 1.91027 1.42259C1.75399 1.26631 1.66619 1.05435 1.66619 0.833333Z" fill="#FF9960"/>
                                                    </svg>
                                                </span>
                                            </div>
                                        </a>
                                    </div>
                                    <?php endif;?>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            <?php endforeach;?>
            </div>
        </div>
        <div class="ed-hs5-nav">
            <div class="ed-hs5-next arrow-nav d-flex justify-content-center align-items-center">
                <svg width="24" height="18" viewBox="0 0 24 18" fill="none" xmlns="http://www.w3.org/2000/svg">
                    <path fill-rule="evenodd" clip-rule="evenodd" d="M1.33268 7.6668C4.58335 7.6668 7.54602 4.70545 7.54602 1.45345V0.120117H10.2127V1.45345C10.2127 3.81878 9.17535 6.03745 7.54735 7.6668H23.9994V10.3335H7.54735C9.17535 11.9628 10.2127 14.1815 10.2127 16.5468V17.8801H7.54602V16.5468C7.54602 13.2948 4.58335 10.3335 1.33268 10.3335H-0.000652313V7.6668H1.33268Z" fill="white"/>
                </svg>
            </div>
            <div class="ed-hs5-pagi"></div>
            <div class="ed-hs5-prev arrow-nav d-flex justify-content-center align-items-center">
                <svg width="25" height="18" viewBox="0 0 25 18" fill="none" xmlns="http://www.w3.org/2000/svg">
                    <path fill-rule="evenodd" clip-rule="evenodd" d="M23.0007 7.6668C19.75 7.6668 16.7873 4.70545 16.7873 1.45345V0.120117H14.1207V1.45345C14.1207 3.81878 15.158 6.03745 16.786 7.6668H0.333984V10.3335H16.786C15.158 11.9628 14.1207 14.1815 14.1207 16.5468V17.8801H16.7873V16.5468C16.7873 13.2948 19.75 10.3335 23.0007 10.3335H24.334V7.6668H23.0007Z" fill="white"/>
                </svg>
            </div>
        </div>
    </div>
</section>