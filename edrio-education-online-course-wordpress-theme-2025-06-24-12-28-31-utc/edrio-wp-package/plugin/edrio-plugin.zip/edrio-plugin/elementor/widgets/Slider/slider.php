<?php

/**
 * Elementor Single Widget
 * @package edrio Tools
 * @since 1.0.0
 */

namespace Elementor;

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly.

class Edrio_Slider extends Widget_Base {

	/**
	 * Get widget name.
	 *
	 * Retrieve Elementor widget name.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget name.
	 */
	public function get_name() {
		return 'edirio-slider';
	}

	/**
	 * Get widget title.
	 *
	 * Retrieve Elementor widget title.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget title.
	 */
	public function get_title() {
		return esc_html__( 'Hero Slider', 'edrio-plugin' );
	}

	/**
	 * Get widget icon.
	 *
	 * Retrieve Elementor widget icon.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget icon.
	 */
	public function get_icon() {
		return 'edrio-custom-icon';
	}

	/**
	 * Get widget categories.
	 *
	 * Retrieve the list of categories the Elementor widget belongs to.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return array Widget categories.
	 */
	public function get_categories() {
		return [ 'edrio_widgets' ];
	}


	protected function register_controls() {

		$this->start_controls_section(
			'int_widget_opt',
			[
				'label' => esc_html__( 'Hero Style Select', 'edrio-plugin' ),
				'tab'   => Controls_Manager::TAB_CONTENT,
			]
		);
        $this->add_control(
			'style',
			[
				'label' => esc_html__( 'Style', 'edrio-plugin' ),
				'type' => \Elementor\Controls_Manager::SELECT,
				'default' => '1',
				'options' => [
					'1'  => esc_html__( 'Style 1', 'edrio-plugin' ),
					'2'  => esc_html__( 'Style 2', 'edrio-plugin' ),
					'3'  => esc_html__( 'Style 3', 'edrio-plugin' )
				]
			]
		);
        $this->end_controls_section();

        $this->start_controls_section(
			'--about-option',
			[
				'label' => esc_html__( 'Hero Option', 'edrio-plugin' ),
				'tab'   => Controls_Manager::TAB_CONTENT,
			]
		);
        $repeater = new \Elementor\Repeater();
		$repeater->add_control(
			'style',
			[
				'label' => esc_html__( 'Style', 'edrio-plugin' ),
				'type' => \Elementor\Controls_Manager::SELECT,
				'default' => '1',
				'options' => [
					'1'  => esc_html__( 'Style 1', 'edrio-plugin' ),
					'2'  => esc_html__( 'Style 2', 'edrio-plugin' ),
					'3'  => esc_html__( 'Style 3', 'edrio-plugin' )
				]
			]
		);

        $repeater->add_control(
			'hero_bg', [
				'label' => esc_html__( 'Hero BG Image', 'edrio-plugin' ),
				'type' => Controls_Manager::MEDIA,
				'condition' => [
					'style!' => '3',
				],
			]
		);

        $repeater->add_control(
			'hero_img', [
				'label' => esc_html__( 'Hero Image', 'edrio-plugin' ),
				'type' => Controls_Manager::MEDIA,
			]
		);

        $repeater->add_control(
			'hero_img2', [
				'label' => esc_html__( 'Hero Image 2', 'edrio-plugin' ),
				'type' => Controls_Manager::MEDIA,
			]
		);
        $repeater->add_control(
			'hero_img3', [
				'label' => esc_html__( 'Hero Image 3', 'edrio-plugin' ),
				'type' => Controls_Manager::MEDIA,
				'condition' => [
					'style' => ['2', '3'],
				],
			]
		);
        $repeater->add_control(
			'hero_img4', [
				'label' => esc_html__( 'Hero Image 4', 'edrio-plugin' ),
				'type' => Controls_Manager::MEDIA,
				'condition' => [
					'style' => ['2', '3'],
				],
			]
		);
        $repeater->add_control(
			'hero_img5', [
				'label' => esc_html__( 'Hero Image 5', 'edrio-plugin' ),
				'type' => Controls_Manager::MEDIA,
				'condition' => [
					'style' => ['2', '3'],
				],
			]
		);
        $repeater->add_control(
			'hero_img6', [
				'label' => esc_html__( 'Hero Image 6', 'edrio-plugin' ),
				'type' => Controls_Manager::MEDIA,
				'condition' => [
					'style' => '2',
				],
			]
		);
        $repeater->add_control(
			'hero_img7', [
				'label' => esc_html__( 'Hero Image 7', 'edrio-plugin' ),
				'type' => Controls_Manager::MEDIA,
				'condition' => [
					'style' => '2',
				],
			]
		);
        $repeater->add_control(
			'hero_img8', [
				'label' => esc_html__( 'Hero Image 8', 'edrio-plugin' ),
				'type' => Controls_Manager::MEDIA,
				'condition' => [
					'style' => '2',
				],
			]
		);
        $repeater->add_control(
			'hero_img9', [
				'label' => esc_html__( 'Hero Image 9', 'edrio-plugin' ),
				'type' => Controls_Manager::MEDIA,
				'condition' => [
					'style' => '2',
				],
			]
		);
        $repeater->add_control(
			'hero_img10', [
				'label' => esc_html__( 'Hero Image 10', 'edrio-plugin' ),
				'type' => Controls_Manager::MEDIA,
				'condition' => [
					'style' => '2',
				],
			]
		);
        $repeater->add_control(
			'hero_img11', [
				'label' => esc_html__( 'Hero Image 11', 'edrio-plugin' ),
				'type' => Controls_Manager::MEDIA,
				'condition' => [
					'style' => '2',
				],
			]
		);
        $repeater->add_control(
			'hero_img12', [
				'label' => esc_html__( 'Hero Image 12', 'edrio-plugin' ),
				'type' => Controls_Manager::MEDIA,
				'condition' => [
					'style' => '2',
				],
			]
		);
        $repeater->add_control(
			'hero_img13', [
				'label' => esc_html__( 'Hero Image 13', 'edrio-plugin' ),
				'type' => Controls_Manager::MEDIA,
				'condition' => [
					'style' => '2',
				],
			]
		);
        $repeater->add_control(
			'hero_img14', [
				'label' => esc_html__( 'Hero Image 14', 'edrio-plugin' ),
				'type' => Controls_Manager::MEDIA,
				'condition' => [
					'style' => '2',
				],
			]
		);
        $repeater->add_control(
			'hero_img15', [
				'label' => esc_html__( 'Hero Image 15', 'edrio-plugin' ),
				'type' => Controls_Manager::MEDIA,
				'condition' => [
					'style' => '2',
				],
			]
		);
        $repeater->add_control(
			'video',
			[
				'label' => esc_html__( 'Upload Video', 'edrio-plugin' ),
				'type' => \Elementor\Controls_Manager::MEDIA,
                'media_types' => [ 'video' ],
				'condition' => [
					'style' => '1',
				],
			]
		);

        $repeater->add_control(
			'sub_title', [
				'label' => esc_html__( 'Sub Title', 'edrio-plugin' ),
				'default' => esc_html__( 'Sub Title', 'edrio-plugin' ),
				'type' => Controls_Manager::TEXT,
                'label_block' => true,
				'condition' => [
					'style' => ['1', '2'],
				],
			]
		);

        $repeater->add_control(
			'title', [
				'label' => esc_html__( 'Title', 'edrio-plugin' ),
				'default' => esc_html__( 'Section Title', 'edrio-plugin' ),
				'type' => Controls_Manager::TEXTAREA,
                'label_block' => true,
			]
		);
		
        $repeater->add_control(
			'description', [
				'label' => esc_html__( 'Description', 'edrio-plugin' ),
				'type' => Controls_Manager::TEXTAREA,
                'label_block' => true,
			]
		);
		$repeater->add_control(
			'btn_arrow', [
				'label' => esc_html__( 'Button Arrow', 'edrio-plugin' ),
				'type' => Controls_Manager::MEDIA,
                'label_block' => true,
			]
		);
		$repeater->add_control(
			'btn_label', [
				'label' => esc_html__( 'Button Label', 'edrio-plugin' ),
				'default' => esc_html__( 'edrio Button', 'edrio-plugin' ),
				'type' => Controls_Manager::TEXT,
                'label_block' => true,
			]
		);
        $repeater->add_control(
			'btn_link', [
				'label' => esc_html__( 'Button Link', 'edrio-plugin' ),
				'type' => Controls_Manager::URL,
                'default' => [
					'url' => '',
					'is_external' => true,
					'nofollow' => true,
					// 'custom_attributes' => '',
				],
				'label_block' => true,
			]
		);
        $this->add_control(
			'sliders',
			[
				'label' => esc_html__( 'Add Slide Item', 'agenriver-plugin' ),
				'type' => \Elementor\Controls_Manager::REPEATER,
				'fields' => $repeater->get_controls(),
                'title_field' => '{{{ title }}}',
			]
		);
		$this->add_control(
			'arrow_prev', [
				'label' => esc_html__( 'Arrow Prev', 'edrio-plugin' ),
				'type' => Controls_Manager::MEDIA,
				'condition' => [
					'style' => '2',
				],
			]
		);
		$this->add_control(
			'arrow_next', [
				'label' => esc_html__( 'Arrow Next', 'edrio-plugin' ),
				'type' => Controls_Manager::MEDIA,
				'condition' => [
					'style' => '2',
				],
			]
		);
		$this->end_controls_section();

		$this->start_controls_section(
			'section-bg-stle',
			[
				'label' => esc_html__( 'Section BG  Style', 'edrio-plugin' ),
				'tab'   => Controls_Manager::TAB_STYLE,
				'condition' => [
					'style' => '4',
				],
			]
		);

		$this->add_control(
			'bg_s_color',
			[
				'label' => esc_html__( 'Hero BG Color', 'edrio-plugin' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .agt-hr7-text-wrap' => 'background: {{VALUE}}',
				],
			]
		);
		
		$this->end_controls_section();

        // title style
		$this->start_controls_section(
			'slider_title_style',
			[
				'label' => esc_html__( 'Title Style', 'edrio-plugin' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);
        $this->add_responsive_control(
			'title_margin',
			[
				'label' => esc_html__( 'Title Margin', 'edrio-plugin' ),
				'type' => \Elementor\Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em', 'rem', 'custom' ],
				'selectors' => [
					'{{WRAPPER}} .elementor-gt-heading' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[

				'name' => 'm_t_typography',
				'selector' => '{{WRAPPER}} .elementor-gt-heading',
			]
		);
		$this->add_control(
			'title_color',
			[
				'label' => esc_html__( 'Title Color', 'edrio-plugin' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .elementor-gt-heading' => 'color: {{VALUE}}',
				],
			]
		);
		
		$this->end_controls_section();

		$this->start_controls_section(
			'int_conta_opt',
			[
				'label' => esc_html__( 'Container Option', 'edrio-plugin' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);
		$this->add_control(
			'width',
			[
				'label' => esc_html__( 'Container Width', 'textdomain' ),
				'type' => \Elementor\Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%', 'em', 'rem', 'custom' ],				
				'selectors' => [
					'{{WRAPPER}} .container' => 'max-width: {{SIZE}}{{UNIT}};',
				],
			]
		);
		$this->end_controls_section();
		
        // description style
		$this->start_controls_section(
			'slider_description_style',
			[
				'label' => esc_html__( 'Description Style', 'edrio-plugin' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);
        $this->add_responsive_control(
			'desc_margin',
			[
				'label' => esc_html__( 'Desc Margin', 'edrio-plugin' ),
				'type' => \Elementor\Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em', 'rem', 'custom' ],
				'selectors' => [
					'{{WRAPPER}} .elementor-gt-desc' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		// typography
		$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[

				'name' => 'm_d_typography',
				'selector' => '{{WRAPPER}} .elementor-gt-desc',
			]
		);

		// description color
		$this->add_control(
			'description_color',
			[
				'label' => esc_html__( 'Description Color', 'edrio-plugin' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .elementor-gt-desc' => 'color: {{VALUE}}',
				],
			]
		);

		$this->end_controls_section();
        // description style
		$this->start_controls_section(
			'slider_info_style',
			[
				'label' => esc_html__( 'Info Style', 'edrio-plugin' ),
				'tab'   => Controls_Manager::TAB_STYLE,
				'condition' => [
					'style' => '3',
				],
			]
		);
        

		// description color
		$this->add_control(
			'info_title_color',
			[
				'label' => esc_html__( 'Info Title Color', 'edrio-plugin' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .agt-h8-img-text .item-text .item-info span, .agt-h8-img-text .item-text .item-info a' => 'color: {{VALUE}}',
				],
			]
		);
        

		// description color
		$this->add_control(
			'info_text_color',
			[
				'label' => esc_html__( 'Info Text Color', 'edrio-plugin' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .agt-h8-img-text .item-text .item-info a' => 'color: {{VALUE}}',
				],
			]
		);

		$this->end_controls_section();
        
		$this->start_controls_section(
			'--button_one',
			[
				'label' => esc_html__( 'Button Style', 'goyto-plugin' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);
        $this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name' => 'm_b_typography',
				'selector' => '
					{{WRAPPER}} .agn-pr-btn-3,
					{{WRAPPER}} .anr__btn-elementor-common a
				',
			]
		);
        $this->add_control(
			'padding',
			[
				'label' => esc_html__( 'Padding', 'goyto-plugin' ),
				'type' => \Elementor\Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em', 'rem', 'custom' ],
				'selectors' => [
					'{{WRAPPER}} .agn-pr-btn-3' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					'{{WRAPPER}} .anr__btn-elementor-common a' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
        $this->add_control(
			'b_round',
			[
				'label' => esc_html__( 'Border Radius', 'goyto-plugin' ),
				'type' => \Elementor\Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em', 'rem', 'custom' ],
				'selectors' => [
					'{{WRAPPER}} .agn-pr-btn-3' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					'{{WRAPPER}} .anr__btn-elementor-common a' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};'
				],
			]
		);


        $this->start_controls_tabs(
			'style_tabs'
		);

		$this->start_controls_tab(
			'style_normal_tab',
			[
				'label' => esc_html__( 'Normal', 'goyto-plugin' ),
			]
		);
        $this->add_control(
			'btn_text',
			[
				'label' => esc_html__( 'Text Color', 'goyto-plugin' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .agn-pr-btn-3 .text' => 'color: {{VALUE}}',
					'{{WRAPPER}} .anr__btn-elementor-common a' => 'color: {{VALUE}}'
				],
			]
		);
        $this->add_control(
			'icon_bg',
			[
				'label' => esc_html__( 'Icon Color', 'goyto-plugin' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .agn-pr-btn-3 .icon' => 'background: {{VALUE}}',
					'{{WRAPPER}} .agn-pr-btn-3 .shape path' => 'fill: {{VALUE}}'
				],
			]
		);
        $this->add_group_control(
			\Elementor\Group_Control_Background::get_type(),
			[
				'name' => 'button_bg_color',
				'types' => [ 'gradient' ],
				'exclude' => [ 'image' ],
				'selector' => '
				{{WRAPPER}} .agn-pr-btn-3 .text,
				{{WRAPPER}} .anr__btn-elementor-common a
				',
                'fields_options' => [
                    'background' => [
                        'label' => esc_html__( 'Button BG Color ', 'goyto-plugin' ),
                        'description' => esc_html__( 'Choose background type and style.', 'goyto-plugin' ),
                        'separator' => 'before',
                    ]
                ]
			]
		);
        $this->end_controls_tab();
        $this->start_controls_tab(
			'style_hover_tab',
			[
				'label' => esc_html__( 'Hover', 'goyto-plugin' ),
			]
		);
        $this->add_control(
			'btn_h_text',
			[
				'label' => esc_html__( 'Text Hovwe Color', 'goyto-plugin' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .agn-pr-btn-3:hover' => 'color: {{VALUE}}',
					'{{WRAPPER}} .agn-pr-btn-3:is(.has-clip):is(.has-hover-black) .text::after' => 'color: {{VALUE}}',
					'{{WRAPPER}} .anr__btn-elementor-common a:hover' => 'color: {{VALUE}}'
				],
			]
		);
        $this->add_group_control(
			\Elementor\Group_Control_Background::get_type(),
			[
				'name' => 'button_bg_hover_color',
				'types' => [ 'gradient' ],
				'exclude' => [ 'image' ],
				'selector' => '
				{{WRAPPER}} .agn-pr-btn-3:hover,
				{{WRAPPER}} .agt-btn-7 a:before
				',
                'fields_options' => [
                    'background' => [
                        'label' => esc_html__( 'Button Hover BG Color ', 'goyto-plugin' ),
                        'description' => esc_html__( 'Choose background type and style.', 'goyto-plugin' ),
                        'separator' => 'before',
                    ]
                ]
			]
		);
        $this->end_controls_tab();
		$this->end_controls_tabs();
        $this->end_controls_section();

	}


	protected function render() {
		$settings = $this->get_settings_for_display();
		require __DIR__ . '/hero-slider/slider-' . $settings['style'] . '.php';
    }


}


Plugin::instance()->widgets_manager->register( new Edrio_Slider() );