<div class="ed-team-content mt-45">
    <div class="ed-team-slide swiper-container">
        <div class="swiper-wrapper">
        <?php foreach($settings['teams'] as $item):?>
            <div class="swiper-slide">
                <div class="ed-team-item-1">
                    <?php if(!empty($item['team_img']['url'])):?>
                        <div class="item-img">
                            <img src="<?php echo esc_url($item['team_img']['url']);?>" alt="<?php if(!empty($item['team_img']['alt'])){ echo esc_attr($item['team_img']['alt']);}else{esc_attr_e('List', 'ftech-plugin');}?>">
                        </div>
                    <?php endif;?>
                    <div class="item-text text-center headline pera-content">

                        <?php if(!empty($item['name'])):?>
                            <h3><a target="<?php echo esc_attr( $item['link']['is_external'] ? '_blank' : '_self' ); ?>" rel="<?php echo esc_attr( $item['link']['nofollow'] ? 'nofollow' : '' ); ?>" href="<?php echo esc_url($item['link']['url']);?>"><?php echo edrio_wp_kses($item['name']);?></a></h3>
                        <?php endif;?>

                        <?php if(!empty($item['designation'])):?>
                            <span><?php echo edrio_wp_kses($item['designation']);?></span>
                        <?php endif;?>

                    </div>
                </div>
            </div>
        <?php endforeach;?>
        </div>
    </div>
</div>