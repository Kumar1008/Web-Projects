<div class="ed-team-content-2 mt-50">
    <div class="ed-team-slider-2 swiper-container">
        <div class="swiper-wrapper">
        <?php foreach($settings['teams'] as $item):?>
            <div class="swiper-slide">
                <div class="ed-team-item-2 position-relative">
                <?php if(!empty($item['team_img']['url'])):?>
                    <div class="item-img">
                        <img src="<?php echo esc_url($item['team_img']['url']);?>" alt="<?php if(!empty($item['team_img']['alt'])){ echo esc_attr($item['team_img']['alt']);}else{esc_attr_e('List', 'edrio-plugin');}?>">
                    </div>
                <?php endif;?>
                    <?php if(!empty($item['social_links'])):?>
                        <div class="social-link">
                            <?php foreach($item['social_links'] as $s_icon):?>
                                <a target="<?php echo esc_attr( $s_icon['social_link']['is_external'] ? '_blank' : '_self' ); ?>" rel="<?php echo esc_attr( $s_icon['social_link']['nofollow'] ? 'nofollow' : '' ); ?>" href="<?php echo esc_url($s_icon['social_link']['url']);?>">
                                    <?php \Elementor\Icons_Manager::render_icon( $s_icon['social_icon'], [ 'aria-hidden' => 'true' ] ); ?>
                                </a>
                            <?php endforeach;?>
                        </div>
                    <?php endif;?>

                    <div class="item-text headline-2 d-flex align-items-center">
                        <div class="inner-text">
                            <?php if(!empty($item['name'])):?>
                                <h3><a target="<?php echo esc_attr( $item['link']['is_external'] ? '_blank' : '_self' ); ?>" rel="<?php echo esc_attr( $item['link']['nofollow'] ? 'nofollow' : '' ); ?>" href="<?php echo esc_url($item['link']['url']);?>"><?php echo edrio_wp_kses($item['name']);?></a></h3>
                            <?php endif;?>
                            <?php if(!empty($item['designation'])):?>
                                <span><?php echo edrio_wp_kses($item['designation']);?></span>
                            <?php endif;?>
                        </div>
                        <div class="inner-social d-flex align-items-center justify-content-center">
                            <i class="fa-solid fa-share-nodes"></i>
                        </div>
                    </div>
                </div>
            </div>
            <?php endforeach;?>
        </div>
    </div>
    <div class="ed-team-pagi text-center"></div>
</div>

<?php if(!empty($settings['description'])):?>
    <div class="ed-course-bottom pera-content mt-30 text-center">
        <p><?php echo edrio_wp_kses( wpautop($settings['description']) );?></p>
    </div>
<?php endif;?>