<div class="ed-team-content-4 pt-65">
<?php foreach($settings['teams'] as $item):?>
    <div class="ed-tm4-item <?php if($item['active'] === 'yes'){ echo esc_attr('active');} ?>  headline-4 position-relative">
        <div class="container">
            <div class="item-content d-flex justify-content-between align-items-center">
                <h3><a target="<?php echo esc_attr( $item['link']['is_external'] ? '_blank' : '_self' ); ?>" rel="<?php echo esc_attr( $item['link']['nofollow'] ? 'nofollow' : '' ); ?>" href="<?php echo esc_url($item['link']['url']);?>"><?php echo edrio_wp_kses($item['title']);?></a></h3>
                <?php if(!empty($item['team_img']['url'])):?>
                    <div class="item-img">
                        <img src="<?php echo esc_url($item['team_img']['url']);?>" alt="<?php if(!empty($item['team_img']['alt'])){ echo esc_attr($item['team_img']['alt']);}else{esc_attr_e('List', 'edrio-plugin');}?>">
                    </div>
                <?php endif;?>
                <div class="item-name-btn d-flex align-items-center">
                    <div class="item-name">
                        <?php if(!empty($item['name'])):?>
                            <h4><?php echo edrio_wp_kses($item['name']);?></h4>
                        <?php endif;?>
                        <?php if(!empty($item['designation'])):?>
                            <span><?php echo edrio_wp_kses($item['designation']);?></span>
                        <?php endif;?>
                    </div>
                    <?php if(!empty($item['btn_label'])):?>
                        <a target="<?php echo esc_attr( $item['link']['is_external'] ? '_blank' : '_self' ); ?>" rel="<?php echo esc_attr( $item['link']['nofollow'] ? 'nofollow' : '' ); ?>" href="<?php echo esc_url($item['link']['url']);?>"><?php echo edrio_wp_kses($item['btn_label']);?></a>
                    <?php endif;?>
                </div>
            </div>
        </div>
    </div>
<?php endforeach;?>
</div>