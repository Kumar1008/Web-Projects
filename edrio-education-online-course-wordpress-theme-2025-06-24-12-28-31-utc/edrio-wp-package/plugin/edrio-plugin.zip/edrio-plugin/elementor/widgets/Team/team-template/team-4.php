<div class="ed-team5-item position-relative">
    <div class="item-img position-relative">
    <?php if(!empty($settings['team_img']['url'])):?>
        <div class="inner-img">
            <img src="<?php echo esc_url($settings['team_img']['url']);?>" alt="<?php if(!empty($settings['team_img']['alt'])){ echo esc_attr($settings['team_img']['alt']);}else{esc_attr_e('List', 'edrio-plugin');}?>">
        </div>
    <?php endif;?>
    </div>
    <div class="item-text headline-5 d-flex align-items-center justify-content-between">
        <div class="name-degi">
            <h3 class="href-underline"><a target="<?php echo esc_attr( $settings['link']['is_external'] ? '_blank' : '_self' ); ?>" rel="<?php echo esc_attr( $settings['link']['nofollow'] ? 'nofollow' : '' ); ?>" href="<?php echo esc_url($settings['link']['url']);?>"><?php echo edrio_wp_kses($settings['name']);?></a></h3>
            <?php if(!empty($settings['designation'])):?>
                <span><?php echo edrio_wp_kses($settings['designation']);?></span>
            <?php endif;?>
        </div>
        <div class="icon-social d-flex justify-content-center align-items-center position-relative">
            <i class="fa-solid fa-plus"></i>
            <svg class="icon_shape" viewBox="0 0 100 100" xmlns="http://www.w3.org/2000/svg">
                <g>
                    <rect x="-50" y="-50" width="100" height="100" rx="100" fill="#0505050f"></rect>
                    <rect x="50" y="-50" width="100" height="100" rx="100" fill="#0505050f"></rect>
                    <rect x="-50" y="50" width="100" height="100" rx="100" fill="#0505050f"></rect>
                    <rect x="50" y="50" width="100" height="100" rx="100" fill="#0505050f"></rect>
                </g>
            </svg>
        </div>
        <?php if(!empty($settings['socials'])):?>
            <div class="social-icon">
                <?php foreach($settings['socials'] as $item):?>
                    <a target="<?php echo esc_attr( $item['link']['is_external'] ? '_blank' : '_self' ); ?>" rel="<?php echo esc_attr( $item['link']['nofollow'] ? 'nofollow' : '' ); ?>" href="<?php echo esc_url($item['link']['url']);?>"><?php \Elementor\Icons_Manager::render_icon( $item['icon'], [ 'aria-hidden' => 'true' ] ); ?></a>
                <?php endforeach;?>
            </div>
        <?php endif;?>
    </div>
</div>