<?php

/**
 * Elementor Single Widget
 * @package edrio Tools
 * @since 1.0.0
 */

namespace Elementor;

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly.

class Edrio_Team extends Widget_Base {

	/**
	 * Get widget name.
	 *
	 * Retrieve Elementor widget name.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget name.
	 */
	public function get_name() {
		return 'edrio-team';
	}

	/**
	 * Get widget title.
	 *
	 * Retrieve Elementor widget title.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget title.
	 */
	public function get_title() {
		return esc_html__( 'Team', 'edrio-plugin' );
	}

	/**
	 * Get widget icon.
	 *
	 * Retrieve Elementor widget icon.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget icon.
	 */
	public function get_icon() {
		return 'edrio-custom-icon';
	}

	/**
	 * Get widget categories.
	 *
	 * Retrieve the list of categories the Elementor widget belongs to.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return array Widget categories.
	 */
	public function get_categories() {
		return [ 'edrio_widgets' ];
	}


	protected function register_controls() {

		$this->start_controls_section(
			'int_widget_opt',
			[
				'label' => esc_html__( 'Team Style Select', 'edrio-plugin' ),
				'tab'   => Controls_Manager::TAB_CONTENT,
			]
		);
        $this->add_control(
			'style',
			[
				'label' => esc_html__( 'Style', 'edrio-plugin' ),
				'type' => \Elementor\Controls_Manager::SELECT,
				'default' => '1',
				'options' => [
					'1'  => esc_html__( 'Style 1', 'edrio-plugin' ),
					'2'  => esc_html__( 'Style 2', 'edrio-plugin' ),
					'3'  => esc_html__( 'Style 3', 'edrio-plugin' ),
					'4'  => esc_html__( 'Style 4', 'edrio-plugin' ),
					'5'  => esc_html__( 'Style 5', 'edrio-plugin' )
				]
			]
		);
        $this->end_controls_section();
		
        $this->start_controls_section(
			'--team-option',
			[
				'label' => esc_html__( 'Team Option', 'edrio-plugin' ),
				'tab'   => Controls_Manager::TAB_CONTENT,
			]
		);
		$this->add_control(
			'team_img', [
				'label' => esc_html__( 'Team Image', 'edrio-plugin' ),
				'type' => Controls_Manager::MEDIA,
                'label_block' => true,
				'condition' => [
					'style' => ['4'],
				],
			]
		);
       
       
        $this->add_control(
			'name', [
				'label' => esc_html__( 'Name', 'edrio-plugin' ),
				'type' => Controls_Manager::TEXT,
                'label_block' => true,
				'condition' => [
					'style' => ['4'],
				],
			]
		);
       
        $this->add_control(
			'designation', [
				'label' => esc_html__( 'Designation', 'edrio-plugin' ),
				'type' => Controls_Manager::TEXT,
                'label_block' => true,
				'condition' => [
					'style' => ['4'],
				],
			]
		);
        
        $this->add_control(
			'link', [
				'label' => esc_html__( 'Link', 'edrio-plugin' ),
				'type' => Controls_Manager::URL,
                'label_block' => true,
				'condition' => [
					'style' => ['4'],
				],
			]
		);
		
        $repeater = new \Elementor\Repeater();
		$repeater->add_control(
			'icon', [
				'label' => esc_html__( 'Icon', 'edrio-plugin' ),
				'type' => Controls_Manager::ICONS,
                'label_block' => true,
			]
		);
        $repeater->add_control(
			'link', [
				'label' => esc_html__( 'Link', 'edrio-plugin' ),
				'type' => Controls_Manager::URL,
                'label_block' => true,
			]
		);
		$this->add_control(
			'socials',
			[
				'label' => esc_html__( 'Add Social Item', 'goyto-plugin' ),
				'type' => \Elementor\Controls_Manager::REPEATER,
				'fields' => $repeater->get_controls(),
				'condition' => [
                    'style' => ['4'],
                ],
			]
		);

        $repeater = new \Elementor\Repeater();
        $repeater->add_control(
			'style',
			[
				'label' => esc_html__( 'Layout', 'edrio-plugin' ),
				'type' => \Elementor\Controls_Manager::SELECT,
				'default' => '1',
				'options' => [
					'1'  => esc_html__( 'Team 1', 'edrio-plugin' ),
					'2'  => esc_html__( 'Team 2', 'edrio-plugin' ),
					'3'  => esc_html__( 'Team 3', 'edrio-plugin' )
				]
			]
		);
		$repeater->add_control(
			'active',
			[
				'label' => esc_html__( 'Active Item', 'edrio-plugin' ),
				'type' => \Elementor\Controls_Manager::SWITCHER,
				'label_on' => esc_html__( 'YES', 'edrio-plugin' ),
				'label_off' => esc_html__( 'NO', 'edrio-plugin' ),
				'return_value' => 'yes',
				'default' => 'no',
				'condition' => [
					'style' => ['3'],
				],
			]
		);
        $repeater->add_control(
			'team_img', [
				'label' => esc_html__( 'Team Image', 'edrio-plugin' ),
				'type' => Controls_Manager::MEDIA,
                'label_block' => true,
			]
		);
       
       
        $repeater->add_control(
			'title', [
				'label' => esc_html__( 'Title', 'edrio-plugin' ),
				'type' => Controls_Manager::TEXT,
                'label_block' => true,
				'condition' => [
					'style' => ['3'],
				],
			]
		);
       
       
        $repeater->add_control(
			'name', [
				'label' => esc_html__( 'Name', 'edrio-plugin' ),
				'type' => Controls_Manager::TEXT,
                'label_block' => true,
			]
		);
       
        $repeater->add_control(
			'designation', [
				'label' => esc_html__( 'Designation', 'edrio-plugin' ),
				'type' => Controls_Manager::TEXT,
                'label_block' => true,
			]
		);
        $repeater->add_control(
			'btn_label', [
				'label' => esc_html__( 'Button Label', 'edrio-plugin' ),
				'type' => Controls_Manager::TEXT,
                'label_block' => true,
				'condition' => [
					'style' => ['3'],
				],
			]
		);
        $repeater->add_control(
			'link', [
				'label' => esc_html__( 'Link', 'edrio-plugin' ),
				'type' => Controls_Manager::URL,
                'label_block' => true,
			]
		);
		$repeater->add_control(
            'social_links',
            [
                'label' => __('Social Links', 'edrio-plugin'),
                'type' => Controls_Manager::REPEATER,
				'condition' => [
                    'style' => ['2'],
                ],
                'fields' => [
                    // social icon
                    [
                        'name' => 'social_icon',
                        'label' => __('Social Icon', 'edrio-plugin'),
                        'type' => Controls_Manager::ICONS,
                        'default' => [
                            'value' => 'fab fa-facebook-f',
                            'library' => 'fa-solid',
                        ],
                    ],
                    // social link
                    [
                        'name' => 'social_link',
                        'label' => __('Social Link', 'edrio-plugin'),
                        'type' => Controls_Manager::URL,
                        'placeholder' => __('https://your-link.com', 'edrio-plugin'),
                        'default' => [
                            'url' => '#',
                        ],
                    ],
                ],
            ],
        );
        $this->add_control(
			'teams',
			[
				'label' => esc_html__( 'Add Team Item', 'goyto-plugin' ),
				'type' => \Elementor\Controls_Manager::REPEATER,
				'fields' => $repeater->get_controls(),
				'condition' => [
                    'style' => ['1', '2', '3', '5'],
                ],
			]
		);
		$this->add_control(
			'description', [
				'label' => esc_html__( 'Description', 'edrio-plugin' ),
				'type' => Controls_Manager::WYSIWYG,
                'label_block' => true,
				'condition' => [
                    'style' => ['2'],
                ],
			]
		);

		$this->end_controls_section();
		// title style
		$this->start_controls_section(
			'team_box_style',
			[
				'label' => esc_html__( 'Team Box Style', 'edrio-plugin' ),
				'tab'   => Controls_Manager::TAB_STYLE,
				'condition' => [
					'style' => ['4'],
				],
			]
		);
        
		$this->add_control(
			'team_box_bg_color',
			[
				'label' => esc_html__( 'Team Box BG Color', 'edrio-plugin' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .ed-team5-item:before' => 'background: {{VALUE}}'
				],
			]
		);
		$this->add_control(
			'team_box_img_color',
			[
				'label' => esc_html__( 'Team Box Image Color', 'edrio-plugin' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .ed-team5-item .item-img:before' => 'background: {{VALUE}}'
				],
			]
		);
		$this->add_control(
			'team_hover_color',
			[
				'label' => esc_html__( 'Team Hover Color', 'edrio-plugin' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .ed-team5-item:hover .icon-social i' => 'color: {{VALUE}}'
				],
			]
		);
		
		
		$this->end_controls_section();
		
		// title style
		$this->start_controls_section(
			'slider_title_style',
			[
				'label' => esc_html__( 'Title Style', 'edrio-plugin' ),
				'tab'   => Controls_Manager::TAB_STYLE,
				'condition' => [
					'style' => ['4', '3'],
				],
			]
		);
        $this->add_responsive_control(
			'title_margin',
			[
				'label' => esc_html__( 'Sub Title Margin', 'edrio-plugin' ),
				'type' => \Elementor\Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em', 'rem', 'custom' ],
				'selectors' => [
					'{{WRAPPER}} .agn-h-4' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					'{{WRAPPER}} .agn-p-9' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};'
				],
			]
		);
		$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[

				'name' => 'm_t_typography',
				'selector' => '
					{{WRAPPER}} .agn-h-4,
					{{WRAPPER}} .agn-p-9
				',
			]
		);
		$this->add_control(
			'title_color',
			[
				'label' => esc_html__( 'Title Color', 'edrio-plugin' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .agn-h-4' => 'color: {{VALUE}}',
					'{{WRAPPER}} .agn-p-9' => 'color: {{VALUE}}'
				],
			]
		);
		
		
		$this->end_controls_section();

		// title style
		$this->start_controls_section(
			'slider_desc_style',
			[
				'label' => esc_html__( 'Designation Style', 'edrio-plugin' ),
				'tab'   => Controls_Manager::TAB_STYLE,
				'condition' => [
					'style' => ['4', '3'],
				],
			]
		);
        $this->add_responsive_control(
			'desig_margin',
			[
				'label' => esc_html__( 'Designation Margin', 'edrio-plugin' ),
				'type' => \Elementor\Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em', 'rem', 'custom' ],
				'selectors' => [
					'{{WRAPPER}} .agn-p-4' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					'{{WRAPPER}} .agn-p-9' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[

				'name' => 'desig_typography',
				'selector' => '
					{{WRAPPER}} .agn-p-4
					{{WRAPPER}} .agn-p-9
				',
			]
		);
		$this->add_control(
			'desig_color',
			[
				'label' => esc_html__( 'Designation Color', 'edrio-plugin' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .agn-p-4' => 'color: {{VALUE}}',
					'{{WRAPPER}} .agn-p-9' => 'color: {{VALUE}}'
				],
			]
		);
		
		
		$this->end_controls_section();
		// title style
		$this->start_controls_section(
			'social_icon_style',
			[
				'label' => esc_html__( 'Designation Style', 'edrio-plugin' ),
				'tab'   => Controls_Manager::TAB_STYLE,
				'condition' => [
					'style' => ['3'],
				],
			]
		);
       
		$this->add_control(
			'social_icon_color',
			[
				'label' => esc_html__( 'icon Color', 'edrio-plugin' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .agn-team-9-member .social-link a' => 'color: {{VALUE}}'
				],
			]
		);
       
		$this->add_control(
			'social_icon_h_color',
			[
				'label' => esc_html__( 'Icon Hover Color', 'edrio-plugin' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .agn-team-9-member .social-link a:hover' => 'color: {{VALUE}}'
				],
			]
		);
		
		
		$this->end_controls_section();
		

	}


	protected function render() {
		$settings = $this->get_settings_for_display();
		require __DIR__ . '/team-template/team-' . $settings['style'] . '.php';
    }


}


Plugin::instance()->widgets_manager->register( new Edrio_Team() );