<div class="ed-testimonial-content">
    <div class="ed-testimonial-slide swiper-container">
        <div class="swiper-wrapper">
            <?php foreach($settings['testimonials'] as $item):?>
            <div class="swiper-slide">
                <div class="ed-testimonial-item d-flex">

                    <?php if(!empty($item['authore']['url'])):?>
                        <div class="item-img">
                            <img src="<?php echo esc_url($item['authore']['url']);?>" alt="<?php if(!empty($item['authore']['alt'])){ echo esc_attr($item['authore']['alt']);}?>">
                        </div>
                    <?php endif;?>

                    <div class="item-text pera-content">
                        <?php if(!empty($item['title'])):?>
                            <span><?php echo edrio_wp_kses($item['title'])?></span>
                        <?php endif;?>
                        <?php if(!empty($item['feedback'])):?>
                            <p><?php echo edrio_wp_kses($item['feedback'])?></p>
                        <?php endif;?>
                        <div class="item-bottom mt-20 d-flex justify-content-between align-items-center">
                            <div class="inner-text headline">
                                <?php if(!empty($item['name'])):?>
                                    <h3><?php echo edrio_wp_kses($item['name']);?></h3>
                                <?php endif;?>
                                <?php if(!empty($item['designation'])):?>
                                    <span><?php echo edrio_wp_kses($item['designation']);?></span>
                                <?php endif;?>
                            </div>
                            <?php if(!empty($item['logo']['url'])):?>
                                <div class="inner-img">
                                    <img src="<?php echo esc_url($item['logo']['url']);?>" alt="<?php if(!empty($item['logo']['alt'])){ echo esc_attr($item['logo']['alt']);}?>">
                                </div>
                            <?php endif;?>
                        </div>
                    </div>
                </div>
            </div>
            <?php endforeach;?>
        </div>
    </div>
</div>