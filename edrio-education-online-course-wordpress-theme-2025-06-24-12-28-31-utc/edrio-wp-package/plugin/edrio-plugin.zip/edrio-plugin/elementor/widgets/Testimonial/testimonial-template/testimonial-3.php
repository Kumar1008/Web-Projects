<div id="ed-tst5" class="ed-tst5-sec pb-60 position-relative">
  	<div class="ed-tst5-shape2 position-absolute">
  		<svg width="264" height="264" viewBox="0 0 264 264" fill="none" xmlns="http://www.w3.org/2000/svg">
  			<path class="box_21" d="M264 -5.7699e-06C264 72.8998 204.903 132 132 132L132 0L264 -5.7699e-06Z" fill="#FF9960"/>
  			<g class="box_20">
  				<path d="M132,132H264V264H132Z" fill="#F38073" />
  				<path d="M0,132H132V264H0Z" fill="#4AD2CC" />
  			</g>
  		</svg>
  	</div>
  	<div class="container">
  		<div class="ed-tst5-content mt-50 d-flex">
  			<div class="ed-tst5-shape">
  				<svg width="380" height="380" viewBox="0 0 380 380" fill="none" xmlns="http://www.w3.org/2000/svg">
  					<path d="M190 380C190 275.066 275.066 190 380 190V380H190Z" fill="#FFDA8A"/>
  					<path d="M190 380C190 275.066 104.934 190 0 190V380H190Z" fill="#C3F498"/>
  					<path d="M380 190C275.066 190 190 104.934 190 0L380 -8.30516e-06L380 190Z" fill="#C3F498"/>
  					<path d="M0 190C104.934 190 190 104.934 190 0L8.30516e-06 -8.30516e-06L0 190Z" fill="#FFDA8A"/>
  				</svg>
  			</div>
  			<div class="ed-tst5-slider">
  				<div class="ed-tst5-slider-active  swiper-container">
  					<div class="swiper-wrapper">
                      <?php foreach($settings['testimonials'] as $item):?>
  						<div class="swiper-slide">
  							<div class="ed-tst5-item pera-content ul-li">
                              <?php
                                $rating = isset($item['rating']) ? floatval($item['rating']) : 0;
                                $fullStars = floor($rating);
                                $halfStar = ($rating - $fullStars) >= 0.5 ? 1 : 0;
                                $emptyStars = 5 - $fullStars - $halfStar;
                                ?>

                                <ul>
                                    <?php for ($i = 0; $i < $fullStars; $i++): ?>
                                        <li><i class="fa-solid fa-star"></i></li>
                                    <?php endfor; ?>

                                    <?php if ($halfStar): ?>
                                        <li><i class="fa-solid fa-star-half-stroke"></i></li>
                                    <?php endif; ?>

                                    <?php for ($i = 0; $i < $emptyStars; $i++): ?>
                                        <li><i class="fa-regular fa-star"></i></li>
                                    <?php endfor; ?>
                                </ul>

  								<?php if(!empty($item['feedback'])):?>
                                    <p>
                                        <?php echo edrio_wp_kses($item['feedback'])?>
                                    </p>
                                <?php endif;?>
  								<div class="tst5-author d-flex align-items-center">
                                  <?php if(!empty($item['authore']['url'])):?>
                                        <div class="item-img">
                                            <img src="<?php echo esc_url($item['authore']['url']);?>" alt="<?php if(!empty($item['authore']['alt'])){ echo esc_attr($item['authore']['alt']);}?>">
                                        </div>
                                    <?php endif;?>
  									<div class="item-text headline-5 pera-content">
                                        <?php if(!empty($item['name'])):?>
  										 <h3><?php echo edrio_wp_kses($item['name']);?></h3>
                                        <?php endif;?>
                                        <?php if(!empty($item['designation'])):?>
  										    <span><?php echo edrio_wp_kses($item['designation']);?></span>
                                        <?php endif;?>
  									</div>
  								</div>
  							</div>
  						</div>
                        <?php endforeach;?>
  					</div>
  				</div>
  			</div>
  		</div>
  		<div class="ed-tst5-pagi text-center mt-40"></div>
  	</div>
  </div>