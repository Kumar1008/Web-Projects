<section id="ed-tst6" class="ed-tst6-sec pt-130 position-relative pb-140">
    <?php if(!empty($settings['shape']['url'])):?>
  	    <span class="ed-tst6-shape upper_view position-absolute">
            <img src="<?php echo esc_url($settings['shape']['url']);?>" alt="<?php if(!empty($settings['shape']['alt'])){ echo esc_attr($settings['shape']['alt']);}?>">
        </span>
    <?php endif;?>
  	<div class="container">
  		<div class="ed-tst6-content d-flex align-items-center">
  			<div class="ed-tst6-text-wrap">
                <?php if(!empty($settings['title'])):?>
                    <div class="ed-sec-title-6 headline-6 pera-content">
                        <h2 class="sec_title ed-sec-tt-anim ed-has-anim">
                            <?php echo edrio_wp_kses($settings['title']); ?>
                        </h2>
                    </div>
                <?php endif;?>
  				<div class="ed-ab5-client mt-50 ul-li">
                    <?php if(!empty($settings['gallery'])):?>
  					<ul>
                        <?php foreach($settings['gallery'] as $item):?>
  						    <li><img src="<?php echo esc_url($item['url']);?>" alt=""></li>
                        <?php endforeach;?>
  						<li><span>+</span></li>
  					</ul>
                    <?php endif;?>
  					<div class="ed-ab5-cl-text headline-6 pera-content">
                        <?php if($settings['count']):?>
  						    <h3><span class="counter"><?php echo esc_html($settings['count']);?></span><?php if(!empty($settings['prefix'])){echo esc_html($settings['prefix']);}?></h3>
                        <?php endif;?>
                        <?php if(!empty($settings['count_title'])):?>
  						    <p>
                                <?php echo edrio_wp_kses($settings['count_title']);?>
                            </p>
                        <?php endif;?>
  					</div>
  				</div>
  			</div>
  			<div class="ed-tst6-slider-wrap position-relative">
  				<div class="ed-tst6-slider swiper-container">
  					<div class="swiper-wrapper">
                      <?php foreach($settings['testimonials'] as $item):?>
  						<div class="swiper-slide">
  							<div class="ed-tst6-item">
  								<div class="inner-item-wrap d-flex">
  									<div class="item-img-degi d-flex justify-content-end position-relative">
                                        <?php if(!empty($item['authore']['url'])):?>
  										<div class="item-img">
                                          <img src="<?php echo esc_url($item['authore']['url']);?>" alt="<?php if(!empty($item['authore']['alt'])){ echo esc_attr($item['authore']['alt']);}?>">
  										</div>
                                        <?php endif;?>
  										<div class="item-degi d-flex align-items-center justify-content-center">
  											<div class="inner-item headline-6 pera-content text-center">
                                                <?php if(!empty($item['name'])):?>
  												    <h3><?php echo edrio_wp_kses($item['name']);?></h3>
                                                  <?php endif;?>
                                                  <?php if(!empty($item['designation'])):?>
  												    <span><?php echo edrio_wp_kses($item['designation']);?></span>
                                                  <?php endif;?>
  											</div>
  										</div>
  									</div>
  									<div class="item-text ul-li pera-content">
                                      <?php
                                        $rating = isset($item['rating']) ? floatval($item['rating']) : 0;
                                        $fullStars = floor($rating);
                                        $halfStar = ($rating - $fullStars) >= 0.5 ? 1 : 0;
                                        $emptyStars = 5 - $fullStars - $halfStar;
                                        ?>

                                        <ul>
                                            <?php for ($i = 0; $i < $fullStars; $i++): ?>
                                                <li><i class="fa-solid fa-star"></i></li>
                                            <?php endfor; ?>

                                            <?php if ($halfStar): ?>
                                                <li><i class="fa-solid fa-star-half-stroke"></i></li>
                                            <?php endif; ?>

                                            <?php for ($i = 0; $i < $emptyStars; $i++): ?>
                                                <li><i class="fa-regular fa-star"></i></li>
                                            <?php endfor; ?>
                                        </ul>
                                          <?php if(!empty($item['feedback'])):?>
                                            <p>
                                            <?php echo edrio_wp_kses($item['feedback'])?>
                                            </p>
                                          <?php endif;?>
  									</div>
  								</div>
  							</div>
  						</div>
                        <?php endforeach;?>
  					</div>
  				</div>
  				<div class="ed-tst6-nav d-flex align-items-center justify-content-center">
  					<div class="ed-tst6-next arrow-nav d-flex justify-content-center align-items-center">
  						<i class="fa-solid fa-angle-left"></i>
  					</div>
  					<div class="ed-tst6-pagi"></div>
  					<div class="ed-tst6-prev arrow-nav d-flex justify-content-center align-items-center">
  						<i class="fa-solid fa-angle-right"></i>
  					</div>
  				</div>
  			</div>
  		</div>
  	</div>
  </section>