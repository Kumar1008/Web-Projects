<?php

/**
 * Elementor Single Widget
 * @package edrio Tools
 * @since 1.0.0
 */

namespace Elementor;

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly.

class Edrio_Testimonial extends Widget_Base {

	/**
	 * Get widget name.
	 *
	 * Retrieve Elementor widget name.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget name.
	 */
	public function get_name() {
		return 'edrio-testimonial';
	}

	/**
	 * Get widget title.
	 *
	 * Retrieve Elementor widget title.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget title.
	 */
	public function get_title() {
		return esc_html__( 'Edrio Testimonial', 'edrio-plugin' );
	}

	/**
	 * Get widget icon.
	 *
	 * Retrieve Elementor widget icon.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget icon.
	 */
	public function get_icon() {
		return 'edrio-custom-icon';
	}

	/**
	 * Get widget categories.
	 *
	 * Retrieve the list of categories the Elementor widget belongs to.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return array Widget categories.
	 */
	public function get_categories() {
		return [ 'edrio_widgets' ];
	}


	protected function register_controls() {

		$this->start_controls_section(
			'int_widget_opt',
			[
				'label' => esc_html__( 'Testimonial Select', 'edrio-plugin' ),
				'tab'   => Controls_Manager::TAB_CONTENT,
			]
		);
        $this->add_control(
			'style',
			[
				'label' => esc_html__( 'Style', 'edrio-plugin' ),
				'type' => \Elementor\Controls_Manager::SELECT,
				'default' => '1',
				'options' => [
					'1'  => esc_html__( 'Style 1', 'edrio-plugin' ),
					'2'  => esc_html__( 'Style 2', 'edrio-plugin' ),
					'3'  => esc_html__( 'Style 3', 'edrio-plugin' ),
					'4'  => esc_html__( 'Style 4', 'edrio-plugin' )
				]
			]
		);
		
        $this->end_controls_section();
		
        $this->start_controls_section(
			'--testimonial-option',
			[
				'label' => esc_html__( 'Testimonial Option', 'edrio-plugin' ),
				'tab'   => Controls_Manager::TAB_CONTENT,
			]
		);
		$this->add_control(
			'title', [
				'label' => esc_html__( 'Title', 'edrio-plugin' ),
				'type' => Controls_Manager::TEXT,
                'label_block' => true,
				'condition' => [
					'style' => '4',
				],
			]
		);
        $repeater = new \Elementor\Repeater();
        $repeater->add_control(
			'style',
			[
				'label' => esc_html__( 'Layout Style', 'edrio-plugin' ),
				'type' => \Elementor\Controls_Manager::SELECT,
				'default' => '1',
				'options' => [
					'1'  => esc_html__( 'Style 1', 'edrio-plugin' ),
					'2'  => esc_html__( 'Style 2', 'edrio-plugin' ),
					'3'  => esc_html__( 'Style 3', 'edrio-plugin' ),
					'4'  => esc_html__( 'Style 4', 'edrio-plugin' )
				]
			]
		);
        
        $repeater->add_control(
			'logo', [
				'label' => esc_html__( 'Logo', 'edrio-plugin' ),
				'type' => Controls_Manager::MEDIA,
                'label_block' => true,
				'condition' => [
					'style' => '1',
				],
			]
		);
        
        $repeater->add_control(
			'authore', [
				'label' => esc_html__( 'Authore Image', 'edrio-plugin' ),
				'type' => Controls_Manager::MEDIA,
                'label_block' => true,
                'condition' => [
					'style' => ['1', '2', '3', '4'],
				],
			]
		);
       
        $repeater->add_control(
			'title', [
				'label' => esc_html__( 'Title', 'edrio-plugin' ),
				'type' => Controls_Manager::TEXT,
                'label_block' => true,
				'condition' => [
					'style' => '1',
				],
			]
		);
       
        $repeater->add_control(
			'feedback', [
				'label' => esc_html__( 'Feedback', 'edrio-plugin' ),
				'type' => Controls_Manager::TEXTAREA,
                'label_block' => true,
			]
		);
       
        $repeater->add_control(
			'name', [
				'label' => esc_html__( 'Name', 'edrio-plugin' ),
				'type' => Controls_Manager::TEXT,
                'label_block' => true,
				'condition' => [
					'style!' => '5',
				],
			]
		);
       
        $repeater->add_control(
			'designation', [
				'label' => esc_html__( 'Designation', 'edrio-plugin' ),
				'type' => Controls_Manager::TEXT,
                'label_block' => true,
				'condition' => [
					'style!' => '5',
				],
			]
		);
		$repeater->add_control(
			'rating',
			[
				'label' => esc_html__( 'Rating', 'textdomain' ),
				'type' => \Elementor\Controls_Manager::NUMBER,
				'min' => 1,
				'max' => 5,
				'step' => 1,
				'default' => 5,
				'condition' => [
					'style' => ['3', '4', '7', '5'],
				],
			]
		);
       
        $this->add_control(
			'testimonials',
			[
				'label' => esc_html__( 'Add Testimonial Item', 'goyto-plugin' ),
				'type' => \Elementor\Controls_Manager::REPEATER,
				'fields' => $repeater->get_controls(),
				'condition' => [
					'style!' => '8',
				],
			]
		);
		$this->add_control(
			'shape', [
				'label' => esc_html__( 'Shape', 'edrio-plugin' ),
				'type' => Controls_Manager::MEDIA,
                'label_block' => true,
				'condition' => [
					'style' => ['4'],
				],
			]
		);
		$this->add_control(
			'gallery',
			[
				'label' => esc_html__( 'Add Images', 'edrio-plugin' ),
				'type' => \Elementor\Controls_Manager::GALLERY,
				'show_label' => false,
				'default' => [],
				'condition' => [
					'style' => ['4'],
				],
			]
		);
		
		$this->add_control(
			'count', [
				'label' => esc_html__( 'Count', 'edrio-plugin' ),
				'type' => Controls_Manager::TEXT,
                'label_block' => true,
				'condition' => [
					'style' => ['4'],
				],
			]
		);
		
		$this->add_control(
			'prefix', [
				'label' => esc_html__( 'Prefix', 'edrio-plugin' ),
				'type' => Controls_Manager::TEXT,
                'label_block' => true,
				'condition' => [
					'style' => ['4'],
				],
			]
		);
		
		$this->add_control(
			'count_title', [
				'label' => esc_html__( 'Count Title', 'edrio-plugin' ),
				'type' => Controls_Manager::TEXT,
                'label_block' => true,
				'condition' => [
					'style' => ['4'],
				],
			]
		);
		$this->end_controls_section();

		// title style
		$this->start_controls_section(
			'abouttxt-style',
			[
				'label' => esc_html__( 'Testtimonial Text Style', 'edrio-plugin' ),
				'tab'   => Controls_Manager::TAB_STYLE,
				'condition' => [
					'style' => ['1', '3', '4', '6', '8'],
				],
			]
		);
		
		
		$this->add_control(
			'tst_text',
			[
				'label' => esc_html__( 'Text Color', 'edrio-plugin' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .arv-testimonial-1-item .client-content blockquote' => 'color: {{VALUE}}',
					'{{WRAPPER}} .arv-testimonial-1-item .client-content .client-bio .role' => 'color: {{VALUE}}',
					'{{WRAPPER}} .agt-tst-item-3 .item-text p' => 'color: {{VALUE}}',
					'{{WRAPPER}} .agt-tst-item-3 .author-name .item-name span' => 'color: {{VALUE}}',
					'{{WRAPPER}} .agt-ft-testi-item .item-rate-text p' => 'color: {{VALUE}}',
					'{{WRAPPER}} .agt-ft-testi-item .item-author .item-text span' => 'color: {{VALUE}}',
					'{{WRAPPER}} .agt-quote-content .item-text h3' => 'color: {{VALUE}}',
					'{{WRAPPER}} .agt-quote-content .item-img-name .item-name span' => 'color: {{VALUE}}',
					'{{WRAPPER}} .agt-quote-content .item-img-name .item-name p' => 'color: {{VALUE}}'
				],
			]
		);
		$this->add_control(
			'authores_box',
			[
				'label' => esc_html__( 'Authore Text Box Color', 'edrio-plugin' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .agt-quote-content .item-img-name .item-name' => 'background: {{VALUE}}'
				],
				'condition' => [
					'style' => ['8'],
				],
			]
		);
		
		
		$this->end_controls_section();
		// title style
		$this->start_controls_section(
			'aboutbox-style',
			[
				'label' => esc_html__( 'Box Style', 'edrio-plugin' ),
				'tab'   => Controls_Manager::TAB_STYLE,
				'condition' => [
					'style' => ['2', '1', '3', '4', '5', '6', '8', '7'],
				],
			]
		);
		
		
		$this->add_control(
			'box_bg',
			[
				'label' => esc_html__( 'Box BG Color', 'edrio-plugin' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .agt-tst-item .item-inner:before' => 'background: {{VALUE}}',
					'{{WRAPPER}} .arv-testimonial-1-bg' => 'background: {{VALUE}}',
					'{{WRAPPER}} .agt-tst-item-3' => 'background: {{VALUE}}',
					'{{WRAPPER}} .agn-testimonial-5-area' => 'background: {{VALUE}}',
					'{{WRAPPER}} .agt-ft-testi-item' => 'background: {{VALUE}}',
					'{{WRAPPER}} .agt-quote-section' => 'background: {{VALUE}}',
					'{{WRAPPER}} .agt-testi-item-6 .item-wrap' => 'background: {{VALUE}}'
				],
			]
		);
		$this->add_control(
			'box_border_bg',
			[
				'label' => esc_html__( 'Box Border Color', 'edrio-plugin' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .agt-ft-testi-item' => 'border-color: {{VALUE}}'
				],
			]
		);
		
		
		$this->end_controls_section();
		// Sub title style
		$this->start_controls_section(
			'slider_sub_title_style',
			[
				'label' => esc_html__( 'Sub Title Style', 'edrio-plugin' ),
				'tab'   => Controls_Manager::TAB_STYLE,
				'condition' => [
					'style' => ['1'],
				],
			]
		);
		$this->add_responsive_control(
			'margin',
			[
				'label' => esc_html__( 'Sub Title Margin', 'edrio-plugin' ),
				'type' => \Elementor\Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em', 'rem', 'custom' ],
				'selectors' => [
					'{{WRAPPER}} .elementor-edrio-sub' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
        $this->add_control(
			'sub_title_color',
			[
				'label' => esc_html__( 'Sub Title Color', 'edrio-plugin' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .elementor-edrio-sub' => 'color: {{VALUE}}'
				],
			]
		);
        $this->add_control(
			'sub_line_color',
			[
				'label' => esc_html__( 'Sub Line BG Color', 'edrio-plugin' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .arv-subtitle-1 span' => 'background: {{VALUE}}',
					'{{WRAPPER}} .agn-brand-2-sec-title .line' => 'background: {{VALUE}}'
				],
			]
		);
        
		// typography
		$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[

				'name' => 'm_s_typography',
				'selector' => '{{WRAPPER}} .elementor-edrio-sub',
			]
		);


		$this->end_controls_section();
		// title style
		$this->start_controls_section(
			'slider_title_style',
			[
				'label' => esc_html__( 'Title Style', 'edrio-plugin' ),
				'tab'   => Controls_Manager::TAB_STYLE,
				'condition' => [
					'style' => ['1'],
				],
			]
		);
        $this->add_responsive_control(
			'title_margin',
			[
				'label' => esc_html__( 'Sub Title Margin', 'edrio-plugin' ),
				'type' => \Elementor\Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em', 'rem', 'custom' ],
				'selectors' => [
					'{{WRAPPER}} .elementor-gt-heading' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[

				'name' => 'm_t_typography',
				'selector' => '{{WRAPPER}} .elementor-gt-heading',
			]
		);
		$this->add_control(
			'title_color',
			[
				'label' => esc_html__( 'Title Color', 'edrio-plugin' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .elementor-gt-heading' => 'color: {{VALUE}}',
				],
			]
		);
		
		$this->end_controls_section();
		


	}


	protected function render() {
		$settings = $this->get_settings_for_display();
		require __DIR__ . '/testimonial-template/testimonial-' . $settings['style'] . '.php';
    }


}


Plugin::instance()->widgets_manager->register( new Edrio_Testimonial() );