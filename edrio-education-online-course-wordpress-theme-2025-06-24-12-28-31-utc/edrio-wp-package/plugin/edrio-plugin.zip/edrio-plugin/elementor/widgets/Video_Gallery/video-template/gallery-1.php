<div class="ed-vc-content">
    <div class="ed-vc-slider-wrap position-relative">
        <div class="ed-vc-slider-for swiper-container">
            <div class="swiper-wrapper">
                <?php foreach ($settings['gallerys'] as $item): ?>
                <div class="swiper-slide">
                    <div class="ed-vc-play-wrap">
                        <div class="row">

                            <div class="col-md-6">
                                <div class="ed-vc-play position-relative">
                                    <?php if(!empty($item['img_1']['url'])):?>
                                        <div class="item-img">
                                            <img src="<?php echo esc_url($item['img_1']['url']);?>" alt="<?php if(!empty($item['img_1']['alt'])){ echo esc_attr($item['img_1']['alt']);}else{esc_attr_e('List', 'ftech-plugin');}?>">
                                        </div>
                                    <?php endif;?>
                                    <div class="video-play">
                                        <a class="video_box d-flex justify-content-center align-items-center" href="<?php echo esc_url($item['v_link']['url']);?>"><i class="fa-solid fa-play"></i></a>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="ed-vc-play position-relative">
                                    <?php if(!empty($item['img_2']['url'])):?>
                                        <div class="item-img">
                                            <img src="<?php echo esc_url($item['img_2']['url']);?>" alt="<?php if(!empty($item['img_2']['alt'])){ echo esc_attr($item['img_2']['alt']);}else{esc_attr_e('List', 'ftech-plugin');}?>">
                                        </div>
                                    <?php endif;?>
                                    <div class="video-play">
                                        <a class="video_box d-flex justify-content-center align-items-center" href="<?php echo esc_url($item['v_link2']['url']);?>"><i class="fa-solid fa-play"></i></a>
                                    </div>
                                </div>
                            </div>
                            
                        </div>
                    </div>
                </div>
                <?php endforeach; ?>
            </div>
        </div>
        <div class="ed-vc-nav d-flex">
            <?php if(!empty($settings['arrow_prev_img']['url'])):?>                                
            <div class="vc-button-prev arrow-nav d-flex justify-content-center align-items-center">
                <img src="<?php echo esc_url($settings['arrow_prev_img']['url']);?>" alt="<?php if(!empty($settings['arrow_prev_img']['alt'])){ echo esc_attr($settings['arrow_prev_img']['alt']);}else{esc_attr_e('List', 'ftech-plugin');}?>">
            </div>
            <?php endif;?>
            <?php if(!empty($settings['arrow_next_img']['url'])):?>  
                <div class="vc-button-next arrow-nav d-flex justify-content-center align-items-center">
                    <img src="<?php echo esc_url($settings['arrow_next_img']['url']);?>" alt="<?php if(!empty($settings['arrow_next_img']['alt'])){ echo esc_attr($settings['arrow_next_img']['alt']);}else{esc_attr_e('List', 'ftech-plugin');}?>">
                </div>
            <?php endif;?>
        </div> 
    </div>
    <div class="ed-vc-slider-nav swiper-container mt-25">
        <div class="swiper-wrapper">
            <?php foreach ($settings['gallerys'] as $item): ?>
                <div class="swiper-slide">
                    <div class="ed-vc-thumb d-flex align-items-center">
                        <div class="item-img position-relative">
                            <?php if(!empty($item['authore']['url'])):?>
                                <div class="inner-img">
                                    <img src="<?php echo esc_url($item['authore']['url']);?>" alt="<?php if(!empty($item['authore']['alt'])){ echo esc_attr($item['authore']['alt']);}else{esc_attr_e('List', 'ftech-plugin');}?>">
                                </div>
                            <?php endif;?>
                            <?php if(!empty($item['x-icon']['url'])):?>
                                <div class="inner-icon">
                                    <img src="<?php echo esc_url($item['x-icon']['url']);?>" alt="<?php if(!empty($item['x-icon']['alt'])){ echo esc_attr($item['x-icon']['alt']);}else{esc_attr_e('List', 'ftech-plugin');}?>">
                                </div>
                            <?php endif;?>
                        </div>
                        <?php if(!empty($item['title']) || !empty($item['company'])):?>
                        <div class="item-text headline-3 pera-content">
                            <h3><?php echo edrio_wp_kses($item['title'])?></h3>
                            <span><?php echo edrio_wp_kses($item['company'])?></span>
                        </div>
                        <?php endif;?>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>
    </div>
</div>