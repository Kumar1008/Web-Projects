<section id="ed-vd5" class="ed-vd5-sec position-relative">
<?php if(!empty($settings['img_1']['url'])):?>
    <div class="ed-vd5-img">
        <div class="item-img">
            <img src="<?php echo esc_url($settings['img_1']['url']);?>" alt="<?php if(!empty($settings['img_1']['alt'])){ echo esc_attr($settings['img_1']['alt']);}?>">
        </div>
    </div>
<?php endif;?>
<div class="ed-vd5-shape1 position-absolute zoom_in_2">
    <svg width="415" height="415" viewBox="0 0 415 415" fill="none" xmlns="http://www.w3.org/2000/svg">
        <g class="box_23">
            <path class="line_1" d="M415 208H208V415H415V208Z" fill="#FFDA8A"/>
            <path class="line_2" d="M415 415H208V414.901C208 300.637 300.682 208 415 208V415Z" fill="white"/>
        </g>
        <g class="box_22">
            <path class="line_3" d="M208 208V0H207.9C93.0848 0 0 93.1295 0 208H208Z" fill="white"/>
            <path class="line_4" d="M208 208V97H207.95C146.676 97 97 146.699 97 208H208Z" fill="#FFDA8A"/>
        </g>
    </svg>
</div>
<?php if(!empty($settings['video_link']['url'])):?>
<div class="ed-vd5-play">
    <div class="video-play-btn">
        <a class="agt_play_btn video_box" href="<?php echo esc_url($settings['video_link']['url']);?>">
            <i class="fa-solid fa-play"></i>
            <span class="video_btn_border border_wrap-1"></span>
            <span class="video_btn_border border_wrap-2"></span>
            <span class="video_btn_border border_wrap-3"></span>
        </a>
    </div>
</div>
<?php endif;?>
</section>  