<?php 

if(!function_exists('edrio_register_custom_icon_library')){
    add_filter('elementor/icons_manager/additional_tabs', 'edrio_register_custom_icon_library');
    function edrio_register_custom_icon_library($tabs){
        $custom_tabs = [
            'extra_icon2' => [
                'name' => 'edrio-flat-icon',
                'label' => esc_html__( 'Flaticon', 'edrio' ),
                'url' => get_template_directory_uri() . '/assets/css/flaticon_multipurpose_agency.css',
                'enqueue' => [ get_template_directory_uri() . '/assets/css/flaticon_multipurpose_agency.css' ],
                'prefix' => 'flaticon-',
                'displayPrefix' => 'flaticon',
                'labelIcon' => 'flaticon-trophy',
                'ver' => EDRIO_VERSION,
                'fetchJson' => get_template_directory_uri() . '/assets/js/flaticon.js?v='.EDRIO_VERSION,
                'native' => true,
            ]
           

        ];

        $tabs = array_merge($custom_tabs, $tabs);

        return $tabs;
    }
}