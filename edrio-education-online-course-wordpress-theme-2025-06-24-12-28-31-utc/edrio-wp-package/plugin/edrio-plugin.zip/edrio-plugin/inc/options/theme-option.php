<?php
/*
 * Theme Options
 * @package edrio
 * @since 1.0.0
 * */

if (!defined('ABSPATH')) {
    exit(); // exit if access directly
}

if (class_exists('CSF')) {

    //
    // Set a unique slug-like ID
    $prefix = 'edrio';

    //
    // Create options
    CSF::createOptions($prefix . '_theme_options', array(
        'menu_title' => 'edrio Option',
        'menu_slug' => 'edrio-theme-option',
        'menu_type' => 'menu',
        'enqueue_webfont' => true,
        'show_in_customizer' => true,
        'menu_icon' => 'dashicons-category',
        'menu_position' => 50,
        'theme' => 'dark',
        'framework_title' => wp_kses_post('Haptic Options <small>by Raziul <br/> Version: 1.0</small> '),
        'footer_text' => wp_kses_post('The Theme will Created By Themexriver '),
    ));

    // Create a top-tab
    CSF::createSection($prefix . '_theme_options', array(
        'id' => 'header_opts', // Set a unique slug-like ID
        'title' => 'Header',
    ));


    /*-------------------------------------------------------
     ** Logo Settings  Options
    --------------------------------------------------------*/

    /*-------------------------------------------------------
     ** Header  Options
    --------------------------------------------------------*/

    CSF::createSection($prefix . '_theme_options', array(
        'title' => 'General Settings',
        'id' => 'general_settings',
        'icon' => 'fa fa-refresh',
        'fields' => array(

            array(
                'id' => 'preloader_enable',
                'title' => esc_html__('Enable Preloader', 'edrio-tools'),
                'type' => 'switcher',
                'desc' => esc_html__('Enable or Disable Preloader', 'edrio-tools'),
                'default' => true,
            ),

            array(
                'id' => 'edrio_preloader_text',
                'title' => esc_html__('Preloader Text', 'edrio-tools'),
                'default' => esc_html__('edrio', 'edrio-tools'),
                'type' => 'text',
                'desc' => esc_html__('Type Custom Preloader Name Here', 'edrio-tools'),
                'dependency' => array(
                    'preloader_enable',
                    '==',
                    'true',
                ),
            ),
            array(
                'id'     => 'preloader-text-color',
                'type'   => 'color',
                'title'  => 'Preloader Text Color',
                'output'      => '.agn-loader-wrap-heading .load-text',
                'output_mode' => 'color',
                'dependency' => array(
                    'preloader_enable',
                    '==',
                    'true',
                ),
            ),
            
            array(
                'id' => 'scroll_up_btn',
                'title' => esc_html__('Scroll Up SHOW/HIDE', 'edrio-tools'),
                'type' => 'switcher',
                'desc' => esc_html__('Enable or Disable Scroll UP', 'edrio-tools'),
                'default' => true,
            ),
            array(
                'id'     => 'scroll-up-bg',
                'type'   => 'color',
                'title'  => 'Scroll Button Color',
                'output'      => '.agn-back-to-top',
                'output_mode' => 'background',
                'dependency' => array(
                    'scroll_up_btn',
                    '==',
                    'true',
                ),
            ),
            array(
                'id'     => 'scroll-up-hover-bg',
                'type'   => 'color',
                'title'  => 'Scroll Button Color',
                'output'      => '.agn-back-to-top:hover',
                'output_mode' => 'background',
                'dependency' => array(
                    'scroll_up_btn',
                    '==',
                    'true',
                ),
            ),
            

        ),
    ));

    CSF::createSection($prefix . '_theme_options', array(
        'title' => esc_html__('Header', 'edrio-tools'),
        'parent' => 'header_opts',
        'icon' => 'fa fa-header',
        'fields' => array(
            array(
                'type' => 'subheading',
                'content' => '<h3>' . esc_html__('Header Layout', 'edrio-tools') . '</h3>',
            ),

            array(
                'id' => 'header_style',
                'type' => 'select',
                'title' => __('Select Header Style', 'edrio-tools'),
                'options' => Edrio_Plugin_Helper::get_header_types(),
                'desc' => sprintf(
                    __('%sClick%s to create New Header', 'edrio-tools'),
                    '<a href="' . admin_url('edit.php?post_type=edrio_template') . '" target="_blank">',
                    '</a>'
                ),
            )

        ),
    ));


    /*-------------------------------------
     ** Typography Options
    -------------------------------------*/
    CSF::createSection($prefix . '_theme_options', array(
        'title' => esc_html__('Typography', 'edrio-tools'),
        'id' => 'typography_options',
        'icon' => 'fa fa-font',
        'fields' => array(

            array(
                'type' => 'subheading',
                'content' => '<h3>' . esc_html__('Body', 'edrio-tools') . '</h3>',
            ),

            array(
                'id' => 'body-typography',
                'type' => 'typography',
                'output' => 'body',

            ),

            array(
                'type' => 'subheading',
                'content' => '<h3>' . esc_html__('Heading', 'edrio-tools') . '</h3>',
            ),

            array(
                'id' => 'heading-gl-typo',
                'type' => 'typography',
                'output' => 'h1, h2, h3, h4, h5, h6',
            ),

        ),
    ));

    // blog optoins
    CSF::createSection($prefix . '_theme_options', array(
        'title' => esc_html__('Blog', 'edrio-tools'),
        'id' => 'blog_page',
        'icon' => 'fa fa-rss-square',
        'fields' => array(

            array(
                'type' => 'subheading',
                'content' => '<h3>' . esc_html__('Blog Options', 'edrio-tools') . '</h3>',
            ),

            array(
                'id' => 'breadcrumb_bg',
                'type' => 'media',
                'title' => esc_html__('Single Breadcrumb BG', 'edrio-tools'),
            ),

            array(
                'id' => 'blog_btn_text',
                'type' => 'text',
                'title' => esc_html__('Blog Read More Button', 'edrio-tools'),
                'default' => esc_html__('Explore More', 'edrio-tools'),
                'desc' => esc_html__('Type Blog Read More Button Text Here', 'edrio-tools'),
            ),
        ),
    ));


    // edrio Color Setting
    CSF::createSection($prefix . '_theme_options', array(
        'title' => 'Color Control',
        'id' => 'apix_color_control',
        'icon' => 'fa fa-paint-brush',
        'fields' => array(


            array(  //nav bar one start
                'type' => 'subheading',
                'content' => '<h3>' . esc_html__('Theme Global Color', 'edrio-tools') . '</h3>',
            ),
            array(
                'id' => 'theme-color-1',
                'type' => 'color',
                'title' => 'Theme Color One',
            )
            
        ),
    ));

    // Create a section
    CSF::createSection($prefix . '_theme_options', array(
        'title' => 'Error Page',
        'id' => 'error_page',
        'icon' => 'fa fa-exclamation-triangle',
        'fields' => array(

            array(
                'id' => 'breadcrumb_bg_img',
                'type' => 'media',
                'title' => esc_html__('Breadcrumb BG', 'artisticx-tools'),
            ),


            array(  //nav bar one start
                'type' => 'subheading',
                'content' => '<h3>' . esc_html__('404 Page Options', 'edrio-tools') . '</h3>',
            ),

            array(
                'id' => 'error_code_img',
                'type' => 'media',
                'title' => esc_html__('Error Code Image', 'edrio-tools'),
            ),
            array(
                'id' => 'error_title',
                'type' => 'text',
                'title' => esc_html__('404 Title', 'edrio-tools'),
                'default' => esc_html__('Oops!', 'edrio-tools'),
            ),
            array(
                'id' => 'error_code',
                'type' => 'text',
                'title' => esc_html__('404 Code', 'edrio-tools'),
                'default' => esc_html__('404 Error!', 'edrio-tools'),
            ),
            array(
                'id' => 'error_button',
                'type' => 'text',
                'title' => esc_html__('404 Button', 'edrio-tools'),
                'default' => esc_html__('back to Home page ', 'edrio-tools'),
            )


        ),
    ));


    /*-------------------------------------------------------
     ** Footer  Options
    --------------------------------------------------------*/

    CSF::createSection($prefix . '_theme_options', array(
        'title' => esc_html__('Footer Options', 'edrio-tools'),
        'icon' => 'fa fa-copyright',
        'fields' => array(

            array(
                'id' => 'footer_style',
                'type' => 'select',
                'title' => __('Select Footer Style', 'edrio-tools'),
                'desc' => sprintf(
                    __('%sClick%s to create New Footer', 'edrio-tools'),
                    '<a href="' . admin_url('edit.php?post_type=edrio_template') . '" target="_blank">',
                    '</a>'
                ),
                'options' => Edrio_Plugin_Helper::get_footer_types(),
            ),
            

        ),
    ));

    // Backup section
    CSF::createSection($prefix . '_theme_options', array(
        'title' => esc_html__('Backup Export', 'edrio-tools'),
        'id' => 'backup_options',
        'icon' => 'fa fa-window-restore',
        'fields' => array(
            array(
                'type' => 'backup',
            ),
        ),
    ));




}