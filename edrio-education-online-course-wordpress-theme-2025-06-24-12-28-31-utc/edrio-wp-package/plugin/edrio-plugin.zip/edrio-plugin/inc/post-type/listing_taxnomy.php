<?php 

if ( !function_exists( 'edrio_tour_type_tax' ) ) {
    function edrio_tour_type_tax() {
        $labels = [
            'name'          => esc_html__( 'Tour Type', 'edrio-plugin' ),
            'menu_name'     => esc_html__( 'Tour Type', 'edrio-plugin' ),
            'singular_name' => esc_html__( 'Tour Type', 'edrio-plugin' ),
            'search_items'  => esc_html__( 'Search Type', 'edrio-plugin' ),
            'all_items'     => esc_html__( 'All Type', 'edrio-plugin' ),
            'new_item_name' => esc_html__( 'New Type', 'edrio-plugin' ),
            'add_new_item'  => esc_html__( 'Add New Type', 'edrio-plugin' ),
            'edit_item'     => esc_html__( 'Edit New Type', 'edrio-plugin' ),
            'update_item'   => esc_html__( 'Update New Type', 'edrio-plugin' ),
        ];
        $args = array(
            'labels'                => $labels,
            'hierarchical'          => true,
            'show_ui'               => true,
            'show_admin_column'     => true,
            'query_var'             => true,
            'update_count_callback' => '_update_post_term_count',
        );
        register_taxonomy('tour_type', 'at_biz_dir', $args);
    }
    add_action( 'init', 'edrio_tour_type_tax' );
}