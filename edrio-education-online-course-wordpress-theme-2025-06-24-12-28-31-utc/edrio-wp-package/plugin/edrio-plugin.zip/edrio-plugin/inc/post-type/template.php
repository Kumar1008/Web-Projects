<?php
if(!function_exists('edrio_page_template_type')  ){
    function edrio_page_template_type(){
		register_post_type( 'edrio_template',
		array(
			  'labels' => array(
				'name' => __( 'Template','edrio-plugin' ),
				'singular_name' => __( 'Template','edrio-plugin' )
			  ),
			'public' => true,
			'publicly_queryable' => true,
			'show_in_menu'      => false,
			'show_in_nav_menus'   => false,
			'supports' => ['title', 'elementor']
		)
		);
	}
	add_action( 'init','edrio_page_template_type',2 );
}
