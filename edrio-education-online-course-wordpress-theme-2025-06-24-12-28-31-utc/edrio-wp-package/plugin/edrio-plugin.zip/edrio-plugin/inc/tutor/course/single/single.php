<section id="ed-breadcrumb2" class="ed-breadcrumb2-sec">
    <div class="ed-breadcrumb-content2 position-relative"  data-background="<?php echo esc_url( get_the_post_thumbnail_url( $course_id, 'full' ) ); ?>">
        <div class="container">
            <div class="ed-breadcrumb-text2  headline ul-li">
                <div class="ed-back-btn">
                    <a href="<?php echo get_post_type_archive_link('courses'); ?>">
                        <i class="fa-solid fa-chevron-left"></i> Back to Course Page
                    </a>
                </div>

                <h2 class="bread_title"><?php echo get_the_title(); ?></h2>
                <ul>
                    <li><i class="fa-regular fa-user"> </i><?php _e('By', 'edrio-plugin') ?> <?php echo esc_html($author_name); ?></li>
                    <li><i class="fa-solid fa-calendar-days"> </i><?php echo isset( $last_updated ) ? esc_html($updated): get_the_date(); ?></li>
                    <li><i class="fa-regular fa-star"> </i><?php echo esc_html( $course_rating->rating_count ); ?> <?php echo esc_html__('Reviews', 'edrio-plugin'); ?></li>
                </ul>
            </div>
        </div>
    </div>
</section>
<section id="ed-course-detail" class="ed-course-detail-sec pt-80 pb-100">
    <div class="container">
        <div class="row">
            <div class="col-lg-8">
                
            </div>
            <div class="col-lg-4">
                <div class="ed-crd-sidebar">
                    <div class="item-img">
                    <?php
                        if ( tutor_utils()->has_video_in_single() ) {
                            tutor_course_video();
                        } else {
                            the_post_thumbnail( 'full', array( 'class' => 'img-fluid' ) );
                        }
                    ?>
                    </div>
                    <div class="item-text ul-li-block">
                        <ul class="crs-info">
                            <li>
                                <span><i class="fa-regular fa-dollar-sign"></i> Price</span>
                                <span><?php get_template_part('template-parts/tutor-lms/price/price'); ?></span>
                            </li>
                            <li>
                                <span><i class="fa-regular fa-clock"></i> Duration</span>
                                <span><?php echo edrio_wp_kses($course_duration);?></span>
                            </li>
                            <li>
                                <span><i class="fa-solid fa-language"></i> Language</span>
                                <span>English</span>
                            </li>
                            <li>
                                <span><i class="fa-regular fa-user"></i> Active Students</span>
                                <span><?php edrio_wp_kses($student_count)?></span>
                            </li>
                        </ul>
                        <h4>This course includes</h4>
                        <ul class="crs-info-2">
                            <li>
                                <span><i class="fa-regular fa-file"></i> 56 Articles</span>
                            </li>
                            <li>
                                <span><i class="fa-solid fa-download"></i> 12 Downloadable resources</span>
                            </li>
                            <li>
                                <span><i class="fa-regular fa-clock"></i> Full time access</span>
                            </li>
                        </ul>
                    </div>
                    <?php if(tutor_utils()->is_course_purchasable($course_id)) : ?>
                <?php
                    if( $is_enrolled ) {
                        tutor_load_template( 'single.course.course-entry-box' );
                    } else {
                        ob_start();

                        $redirect_url = '';
                        $popup_modal_class = '';
                        $get_product_id = '0';
                        if (  is_user_logged_in() ) {
                            $redirect_url = wc_get_checkout_url();
                            $get_product_id = $course_product_id;
                            
                        } else {
                            $popup_modal_class = 'tutor-open-login-modal';
                        }
                        ?>
                        
                        <div class="buy-now-btn mt--15">
                            <button data-redirect="<?php echo esc_url( $redirect_url ); ?>" data-product_id="<?php echo esc_attr($get_product_id); ?>" class="rbt-btn ajax-buy-now-product btn-border icon-hover w-100 d-block text-center <?php echo esc_attr( $product_type ); ?> <?php echo esc_attr( $popup_modal_class ); ?>">
                                <span class="btn-text"><?php echo esc_html__('Buy Now', 'histudy'); ?></span>
                                <span class="btn-icon"><i class="feather-arrow-right"></i></span>
                            </button>
                        </div>
                    <?php } 
                ?>
            <?php else: ?>
                <div class="mt-2">
                    <?php tutor_load_template( 'single.course.course-entry-box' ); ?>
                </div>
            <?php endif; ?>
            <?php if( 1 == $rainbow_course_details_card_mony_back_badge_show ) : ?>
                <span class="subtitle"><i class="feather-rotate-ccw"></i><?php echo esc_html__(' 30-Day Money-Back Guarantee', 'histudy'); ?></span>
            <?php endif; ?>
                    <div class="ed-btn-1 mt-30 btn-spin text-center">
                        <a href="#">Enroll Now</a>
                    </div>
                    <span class="bottom-text text-center">30 day money back gurantee</span>
                </div>
            </div>
        </div>
        <div class="ed-recent-post-feed pt-80 headline-1">
            <h3>Courses You May Like</h3>
            <div class="row justify-content-center">
                <div class="col-lg-4 col-md-6">
                    <div class="ed-course5-item">
                        <div class="item-img-cate position-relative">
                            <div class="inner-img">
                                <img src="assets/img/course/pc1.jpg" alt="">
                            </div>
                            <div class="inner-cate">
                                WordPress
                            </div>
                        </div>
                        <div class="item-text headline  position-relative">
                            <div class="item-rate ul-li">
                                <ul>
                                    <li><i class="fa-solid fa-star"></i></li>
                                    <li><i class="fa-solid fa-star"></i></li>
                                    <li><i class="fa-solid fa-star"></i></li>
                                    <li><i class="fa-solid fa-star"></i></li>
                                    <li><i class="fa-solid fa-star"></i></li>
                                </ul>
                            </div>
                            <h3 class="href-underline"><a href="#">The Complete WordPress Plugin Development Course.</a></h3>
                            <div class="item-meta d-flex align-items-center justify-content-between">
                                <a href="#"><i class="fa-regular fa-circle-play"></i> <span><b>20+</b> Lessons</span> </a>
                                <a href="#"><i class="fa-solid fa-users"></i> <span><b>79+</b> Students</span></a>
                            </div>
                            <div class="item-bottom mt-20 d-flex align-items-center justify-content-between">
                                <div class="item-author d-flex align-items-center">
                                    <div class="author-img">
                                        <img src="assets/img/testimonial/tst12.png" alt="">
                                    </div>
                                    <div class="author-text">
                                        Emma Mark
                                    </div>
                                </div>
                                <div class="item-price">
                                    <span>$</span>320 USD
                                </div>
                            </div>
                            <div class="crs-btn text-center">
                                <a href="#">Course Details</a>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-lg-4 col-md-6">
                    <div class="ed-course5-item">
                        <div class="item-img-cate position-relative">
                            <div class="inner-img">
                                <img src="assets/img/course/pc2.jpg" alt="">
                            </div>
                            <div class="inner-cate">
                                WordPress
                            </div>
                        </div>
                        <div class="item-text headline  position-relative">
                            <div class="item-rate ul-li">
                                <ul>
                                    <li><i class="fa-solid fa-star"></i></li>
                                    <li><i class="fa-solid fa-star"></i></li>
                                    <li><i class="fa-solid fa-star"></i></li>
                                    <li><i class="fa-solid fa-star"></i></li>
                                    <li><i class="fa-solid fa-star"></i></li>
                                </ul>
                            </div>
                            <h3 class="href-underline"><a href="#">The Complete SEO &amp; Digital Marketing Course.</a></h3>
                            <div class="item-meta d-flex align-items-center justify-content-between">
                                <a href="#"><i class="fa-regular fa-circle-play"></i> <span><b>20+</b> Lessons</span> </a>
                                <a href="#"><i class="fa-solid fa-users"></i> <span><b>79+</b> Students</span></a>
                            </div>
                            <div class="item-bottom mt-20 d-flex align-items-center justify-content-between">
                                <div class="item-author d-flex align-items-center">
                                    <div class="author-img">
                                        <img src="assets/img/testimonial/tst12.png" alt="">
                                    </div>
                                    <div class="author-text">
                                        Emma Mark
                                    </div>
                                </div>
                                <div class="item-price">
                                    <span>$</span>320 USD
                                </div>
                            </div>
                            <div class="crs-btn text-center">
                                <a href="#">Course Details</a>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-lg-4 col-md-6">
                    <div class="ed-course5-item">
                        <div class="item-img-cate position-relative">
                            <div class="inner-img">
                                <img src="assets/img/course/pc3.jpg" alt="">
                            </div>
                            <div class="inner-cate">
                                WordPress
                            </div>
                        </div>
                        <div class="item-text headline  position-relative">
                            <div class="item-rate ul-li">
                                <ul>
                                    <li><i class="fa-solid fa-star"></i></li>
                                    <li><i class="fa-solid fa-star"></i></li>
                                    <li><i class="fa-solid fa-star"></i></li>
                                    <li><i class="fa-solid fa-star"></i></li>
                                    <li><i class="fa-solid fa-star"></i></li>
                                </ul>
                            </div>
                            <h3 class="href-underline"><a href="#">The Ultimate Data Analysis Course – Beginner.</a></h3>
                            <div class="item-meta d-flex align-items-center justify-content-between">
                                <a href="#"><i class="fa-regular fa-circle-play"></i> <span><b>20+</b> Lessons</span> </a>
                                <a href="#"><i class="fa-solid fa-users"></i> <span><b>79+</b> Students</span></a>
                            </div>
                            <div class="item-bottom mt-20 d-flex align-items-center justify-content-between">
                                <div class="item-author d-flex align-items-center">
                                    <div class="author-img">
                                        <img src="assets/img/testimonial/tst12.png" alt="">
                                    </div>
                                    <div class="author-text">
                                        Emma Mark
                                    </div>
                                </div>
                                <div class="item-price">
                                    <span>$</span>320 USD
                                </div>
                            </div>
                            <div class="crs-btn text-center">
                                <a href="#">Course Details</a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>