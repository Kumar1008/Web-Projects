<?php
/**
 * Template for displaying single course
 *
 * @package Tutor\Templates
 * @author Themeum <support@themeum.com>
 * @link https://themeum.com
 * @since 1.0.0
 */

$course_id     = get_the_ID();
$course_rating = tutor_utils()->get_course_rating( $course_id );
$is_enrolled   = tutor_utils()->is_enrolled( $course_id, get_current_user_id() );

$author_id              = get_post_field('post_author', $course_id);
$author_name      = get_the_author_meta('display_name', $author_id);

$course_duration   = get_tutor_course_duration_context( $course_id, true );
$student = function_exists('tutor') ? tutor_utils()->count_enrolled_users_by_course($course_id) : 0;
                $student_count = sprintf(_n('%s Student', '%s Students', $student, 'edrio-plugin'), $student);
// Prepare the nav items.
$course_nav_item = apply_filters( 'tutor_course/single/nav_items', tutor_utils()->course_nav_items(), $course_id );
$is_public       = \TUTOR\Course_List::is_public( $course_id );
$is_mobile       = wp_is_mobile();

$enrollment_box_position = tutor_utils()->get_option( 'enrollment_box_position_in_mobile', 'bottom' );
if ( '-1' === $enrollment_box_position ) {
	$enrollment_box_position = 'bottom';
}
$student_must_login_to_view_course = tutor_utils()->get_option( 'student_must_login_to_view_course' );

tutor_utils()->tutor_custom_header();

if ( ! is_user_logged_in() && ! $is_public && $student_must_login_to_view_course ) {
	tutor_load_template( 'login' );
	tutor_utils()->tutor_custom_footer();
	return;
}
$has_video = apply_filters( 'tutor_course_has_video', tutor_utils()->has_video_in_single(), $course_id );
?>
<section id="ed-breadcrumb2" class="ed-breadcrumb2-sec">
    <div class="ed-breadcrumb-content2 position-relative"  data-background="<?php echo esc_url( get_the_post_thumbnail_url( $course_id, 'full' ) ); ?>">
        <div class="container">
            <div class="ed-breadcrumb-text2  headline ul-li">
                <div class="ed-back-btn">
                    <a href="<?php echo get_post_type_archive_link('courses'); ?>">
                        <i class="fa-solid fa-chevron-left"></i> <?php _e('Back to Courses', 'edrio-plugin') ?>
                    </a>
                </div>

                <h2 class="bread_title"><?php echo get_the_title(); ?></h2>
                <ul>
                    <li><i class="fa-regular fa-user"> </i><?php _e('By', 'edrio-plugin') ?> <?php echo esc_html($author_name); ?></li>
                    <li><i class="fa-solid fa-calendar-days"> </i><?php echo isset( $last_updated ) ? esc_html($updated): get_the_date(); ?></li>
                    <li><i class="fa-regular fa-star"> </i><?php echo esc_html( $course_rating->rating_count ); ?> <?php echo esc_html__('Reviews', 'edrio-plugin'); ?></li>
                </ul>
            </div>
        </div>
    </div>
</section>

<?php do_action( 'tutor_course/single/before/wrap' ); ?>
<div <?php tutor_post_class( 'tutor-full-width-course-top tutor-course-top-info tutor-page-wrap tutor-wrap-parent' ); ?>>
	<div class="tutor-course-details-page tutor-container pt-100 pb-100">
		
		<div class="tutor-row tutor-gx-xl-5">
			<main class="col-lg-8">
				<?php $has_video ? tutor_course_video() : get_tutor_course_thumbnail(); ?>
				<?php do_action( 'tutor_course/single/before/inner-wrap' ); ?>

				<?php if ( $is_mobile && 'top' === $enrollment_box_position ) : ?>
					<div class="tutor-mt-32">
						<?php tutor_load_template( 'single.course.course-entry-box' ); ?>
					</div>
				<?php endif; ?>

				<div class="tutor-course-details-tab tutor-mt-32">
					<?php if ( is_array( $course_nav_item ) && count( $course_nav_item ) > 1 ) : ?>
						<div class="tutor-is-sticky">
							<?php tutor_load_template( 'single.course.enrolled.nav', array( 'course_nav_item' => $course_nav_item ) ); ?>
						</div>
					<?php endif; ?>
					<div class="tutor-tab tutor-pt-24">
						<?php foreach ( $course_nav_item as $key => $subpage ) : ?>
							<div id="tutor-course-details-tab-<?php echo esc_attr( $key ); ?>" class="tutor-tab-item<?php echo 'info' == $key ? ' is-active' : ''; ?>">
								<div class="ed-crd-text-wrap">
									<?php
										do_action( 'tutor_course/single/tab/' . $key . '/before' );

										$method = $subpage['method'];
									if ( is_string( $method ) ) {
										$method();
									} else {
										$_object = $method[0];
										$_method = $method[1];
										$_object->$_method( get_the_ID() );
									}

										do_action( 'tutor_course/single/tab/' . $key . '/after' );
									?>
								</div>
								
							</div>
						<?php endforeach; ?>
					</div>
				</div>
				<?php do_action( 'tutor_course/single/after/inner-wrap' ); ?>
			</main>
			<div class="col-lg-4">
				<div class="ed-crd-sidebar">
					<div class="item-img">
					<?php
						if ( tutor_utils()->has_video_in_single() ) {
							tutor_course_video();
						} else {
							the_post_thumbnail( 'full', array( 'class' => 'img-fluid' ) );
						}
					?>
					</div>
					<div class="item-text ul-li-block">
						<ul class="crs-info">
							<li>
								<span><i class="fa-regular fa-dollar-sign"></i> Price</span>
								<span><?php get_template_part('template-parts/tutor-lms/price/price'); ?></span>
							</li>
							<li>
								<span><i class="fa-regular fa-clock"></i> Duration</span>
								<span><?php echo edrio_wp_kses($course_duration);?></span>
							</li>
							<li>
								<span><i class="fa-solid fa-language"></i> Language</span>
								<span>English</span>
							</li>
							<li>
								<span><i class="fa-regular fa-user"></i> Active Students</span>
								<span><?php edrio_wp_kses($student_count)?></span>
							</li>
						</ul>
					</div>					
					<?php if ( ( $is_mobile && 'bottom' === $enrollment_box_position ) || ! $is_mobile ) : ?>
						<?php tutor_load_template( 'single.course.course-entry-box' ); ?>
					<?php endif ?>
					<span class="bottom-text text-center">30 day money back gurantee</span>
				</div>
			</div>
			
		</div>
	</div>
</div>

<?php do_action( 'tutor_course/single/after/wrap' ); ?>

<?php
tutor_utils()->tutor_custom_footer();
